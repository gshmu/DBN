--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : ####_########_###_#####.###
--###
--###  ####### ####       ###               ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ########           ###### #### 
--### *********************************************************************/


BEGIN
    EXECUTE IMMEDIATE '#### ####### #_########_###_##### ';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/

DECLARE
    any_204       schema_138.dataset_15.column_354%TYPE;
    any_09        VARCHAR2(30) := sys_context('#######','#######_######');

BEGIN
    
    EXECUTE IMMEDIATE '##### ###### ## ###_######_####.###_##### ## '||column_33 || ' #### ##### ######';
  
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

CREATE OR REPLACE FORCE VIEW view_43               AS 
WITH dataset_7081
  AS ( SELECT /*+ ######_##### */
            dataset_2367.*
        FROM dataset_5572 dataset_2367
  INNER JOIN dataset_360  dataset_1243 
          ON dataset_2367.column_354 IN (dataset_1243.column_354,'###_#########')
       )
SELECT
    dataset_2367.column_213,
    dataset_2367.column_354,
    dataset_2367.column_714,
    dataset_2367.column_1064,
    dataset_2367.column_532,
    dataset_2367.column_2023,
    dataset_2367.column_2710,
    dataset_2367.column_8323,
    dataset_2367.column_19189,
    dataset_2367.column_19190,
    dataset_2367.column_19191,
    dataset_2367.column_31,
    dataset_2367.column_32  
FROM dataset_7081 dataset_2367
-- ####### ########## #######
UNION ALL
SELECT
    dataset_7082.column_213,
    dataset_7082.column_354,
    dataset_7082.column_714,
    dataset_7082.column_1064,
    dataset_7082.column_532,
    dataset_7082.column_2023,
    dataset_7082.column_2710,
    dataset_7082.column_8323,
    '#######',
    ROUND ((dataset_7082.column_19190 / 12),2) AS column_19190,
    ROUND ((dataset_7082.column_19191 / 12), 2) AS column_19191,
    dataset_7082.column_31,
    dataset_7082.column_32  
FROM dataset_7081 dataset_7082
WHERE
    dataset_7082.column_19189 = '########' AND
    NOT EXISTS (SELECT 1 
                  FROM dataset_7081 dataset_7083 
                 WHERE dataset_7083.column_2710 = dataset_7082.column_2710       
                   AND dataset_7083.column_19189 = '#######'
                   AND dataset_7083.column_532    = dataset_7082.column_532   
                   AND dataset_7083.column_213          = dataset_7082.column_213
                   AND TRUNC(dataset_7083.column_31)       = TRUNC(dataset_7082.column_31)
                   AND TRUNC(dataset_7083.column_32)      = TRUNC(dataset_7082.column_32)
                   AND dataset_7083.column_2023         = dataset_7082.column_2023
                   AND dataset_7083.column_354       = dataset_7082.column_354 
                 )
-- ###### ########## #######                   
UNION ALL
SELECT
    dataset_7082.column_213,
    dataset_7082.column_354,
    dataset_7082.column_714,
    dataset_7082.column_1064,
    dataset_7082.column_532,
    dataset_7082.column_2023,
    dataset_7082.column_2710,
    dataset_7082.column_8323,
    '######',
    ROUND ((dataset_7082.column_19190 / 52),2) AS column_19190,
    ROUND ((dataset_7082.column_19191 / 52), 2) AS column_19191,
    dataset_7082.column_31,
    dataset_7082.column_32  
FROM dataset_7081 dataset_7082
WHERE
    dataset_7082.column_19189 = '########' AND
    NOT EXISTS (SELECT 1 
                  FROM dataset_7081 dataset_7083 
                 WHERE dataset_7083.column_2710 = dataset_7082.column_2710       
                   AND dataset_7083.column_19189 = '######'
                   AND dataset_7083.column_532    = dataset_7082.column_532   
                   AND dataset_7083.column_213          = dataset_7082.column_213
                   AND TRUNC(dataset_7083.column_31)       = TRUNC(dataset_7082.column_31)
                   AND TRUNC(dataset_7083.column_32)      = TRUNC(dataset_7082.column_32)
                   AND dataset_7083.column_2023         = dataset_7082.column_2023
                   AND dataset_7083.column_354       = dataset_7082.column_354
                )
-- ##_###### ########## #######                   
UNION ALL
SELECT
    dataset_7082.column_213,
    dataset_7082.column_354,
    dataset_7082.column_714,
    dataset_7082.column_1064,
    dataset_7082.column_532,
    dataset_7082.column_2023,
    dataset_7082.column_2710,
    dataset_7082.column_8323,
    '##_######',
    ROUND ((dataset_7082.column_19190 * 2 / 52),2) AS column_19190,
    ROUND ((dataset_7082.column_19191 * 2 / 52), 2) AS column_19191,
    dataset_7082.column_31,
    dataset_7082.column_32  
FROM dataset_7081 dataset_7082
WHERE
    dataset_7082.column_19189 = '########' AND
    NOT EXISTS (SELECT 1 
                  FROM dataset_7081 dataset_7083 
                 WHERE dataset_7083.column_2710 = dataset_7082.column_2710       
                   AND dataset_7083.column_19189 = '##_######'
                   AND dataset_7083.column_532    = dataset_7082.column_532   
                   AND dataset_7083.column_213          = dataset_7082.column_213
                   AND TRUNC(dataset_7083.column_31)       = TRUNC(dataset_7082.column_31)
                   AND TRUNC(dataset_7083.column_32)      = TRUNC(dataset_7082.column_32)
                   AND dataset_7083.column_2023         = dataset_7082.column_2023
                   AND dataset_7083.column_354       = dataset_7082.column_354)
-- ####_###### ########## #######                   
UNION ALL
SELECT
    dataset_7082.column_213,
    dataset_7082.column_354,
    dataset_7082.column_714,
    dataset_7082.column_1064,
    dataset_7082.column_532,
    dataset_7082.column_2023,
    dataset_7082.column_2710,
    dataset_7082.column_8323,
    '####_######',
    ROUND ((dataset_7082.column_19190 * 4 / 52),2) AS column_19190,
    ROUND ((dataset_7082.column_19191 * 4 / 52), 2) AS column_19191,
    dataset_7082.column_31,
    dataset_7082.column_32  
FROM dataset_7081 dataset_7082
WHERE
    dataset_7082.column_19189 = '########' AND
    NOT EXISTS (SELECT 1 
                  FROM dataset_7081 dataset_7083 
                 WHERE dataset_7083.column_2710 = dataset_7082.column_2710       
                   AND dataset_7083.column_19189 = '####_######'
                   AND dataset_7083.column_532    = dataset_7082.column_532   
                   AND dataset_7083.column_213          = dataset_7082.column_213
                   AND TRUNC(dataset_7083.column_31)       = TRUNC(dataset_7082.column_31)
                   AND TRUNC(dataset_7083.column_32)      = TRUNC(dataset_7082.column_32)
                   AND dataset_7083.column_2023         = dataset_7082.column_2023
                   AND dataset_7083.column_354       = dataset_7082.column_354
                 )
/                        

COMMIT
/
      





