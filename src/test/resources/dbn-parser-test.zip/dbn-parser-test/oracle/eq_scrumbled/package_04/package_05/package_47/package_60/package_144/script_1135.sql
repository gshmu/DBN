/*
   ### ### #############
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : ###### ##### ### #### ######## ### ######## ########## ####### ### ### ####
   ##.#.#   ##.##.####   ########   ###-#### : ### ############# ############ ## ######### #### #####
   ##.#.#   ##.##.####   ########   ###-#### : ### #### #######: ### ############ ## ### ### #### ######## ##### ########
	####### ##.#
  ##.#.# ##.##.####		 #######	###-#####: ########### ##. ####### ######## #### #########

   */

        select nvl(dataset_318.column_5441, dataset_1172.column_2740) as column_5441,
       DECODE(dataset_461.column_6384,
         '######_####', dataset_45.column_4126,
         '####', dataset_45.column_598,
         '#############_####', dataset_45.column_598 || to_char(dataset_268.column_973, '####'),
         '#############', null
         ) AS column_6383,
       DECODE(dataset_461.column_6384,
         '######_####', dataset_335.column_742,
         '####', dataset_45.column_742,
         '#############_####', dataset_45.column_742  || ' ' || to_char(dataset_268.column_973, '####'),
         '#############', null
         ) AS column_6558,
       dataset_318.column_04                  as column_3063,
       dataset_318.column_10,
       dataset_318.column_4358                    as column_7132,
       dataset_318.column_5434                  as column_1785,
       dataset_2397.column_2748  

  from dataset_317                  dataset_318,
       dataset_1171           dataset_1172,
       dataset_272 dataset_2397,
       dataset_270 dataset_268,
       dataset_269 dataset_45,
       dataset_269 dataset_335,
       dataset_2483      dataset_2484,
       dataset_2485 dataset_461
 where dataset_318.column_599 = dataset_268.column_599   
   and dataset_318.column_12 = dataset_1172.column_12      
   and dataset_1172.column_08 = dataset_2397.column_08  
   and dataset_268.column_598 = dataset_45.column_598
   and dataset_45.column_4126 = dataset_335.column_598
   and dataset_2484.column_598 = DECODE(dataset_461.column_6384,'######_####', dataset_335.column_598,'####',dataset_45.column_598)
   and dataset_268.column_11 = NVL(dataset_2484.column_1446, dataset_268.column_11)
   and dataset_2484.column_3118 = dataset_461.column_3118   
   and dataset_318.column_07 = 
   and dataset_2484.column_3118 = 
   and dataset_268.column_2941 = '########' -- ### ######## ############ #### ###### ###### ## ###_########
   and dataset_318.column_04 = '###########_############'
   and dataset_318.column_10 not in ('#########', '####_########')
   and dataset_318.column_4358                    is not null
UNION ALL
select
    column_5441,
    column_6383,
    column_6558,
    column_3063,
    column_10,
    SUM(column_09) as column_7132,
    column_1785,
    null as column_2748  
    FROM(
        select nvl(dataset_2397.column_9841, dataset_2397.column_2748) as column_5441,
          DECODE(dataset_461.column_6384,
         '######_####', dataset_45.column_4126,
         '####', dataset_45.column_598,
         '#############_####', dataset_45.column_598 || to_char(dataset_268.column_973, '####'),
         '#############', null
         ) AS column_6383,
       DECODE(dataset_461.column_6384,
         '######_####', dataset_335.column_742,
         '####', dataset_45.column_742,
         '#############_####', dataset_45.column_742  || ' ' || to_char(dataset_268.column_973, '####'),
         '#############', null
         ) AS column_6558,
       '########_########' as column_3063,
       '####_########' as column_10,
     dataset_1185.column_09  ,
       dataset_1185.column_532    as column_1785          

      from dataset_13                   dataset_1185,
           dataset_272 dataset_2397,
           dataset_270 dataset_268,
            dataset_269 dataset_45,
            dataset_269 dataset_335,
            dataset_2483      dataset_2484,
            dataset_2485 dataset_461
      where dataset_1185.column_08 = dataset_2397.column_08  
       and dataset_2397.column_599 = dataset_268.column_599   
       and dataset_268.column_598 = dataset_45.column_598
       and dataset_45.column_4126 = dataset_335.column_598
       and dataset_2484.column_598 = DECODE(dataset_461.column_6384,'######_####', dataset_335.column_598,'####',dataset_45.column_598)
       and dataset_268.column_11 = NVL(dataset_2484.column_1446, dataset_268.column_11)
       and dataset_2484.column_3118 = dataset_461.column_3118   
       and dataset_1185.column_07 = 
       and dataset_2484.column_3118 = 
       and dataset_268.column_2941 = '########' -- ### ######## ############ #### ###### ###### ## ###_########
       and dataset_1185.column_09 > 0
       and dataset_1185.column_4359               is null -- ######## ## ##### ###########
       and dataset_1185.column_5442          is null -- ######## #### ### ########
       and dataset_1185.column_04 = '###########_############' -- ######## #### #### #### ########### ############)
)GROUP BY
column_5441,
column_6383,
column_6558,
column_3063,
column_10,
column_1785          
ORDER BY column_5441      