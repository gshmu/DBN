--### /*******************************************************************
--### 
--###  ######### (#) ####,#### ###, ####### ##
--###
--###  #### ####     : ######_###_######_#####.###
--###
--### *******************************************************************
--### ####### ####       ###                   ########
--### *******************************************************************
--### ####### ##.#
--### ##.#.#  ##.##.#### ########             ###-#####: ##### ### ##  #_###_########_######_#######
--### *********************************************************************/
--###


alter session set current_schema=schema_107
/

DECLARE
  PROCEDURE procedure_184
      (argument_373          IN  VARCHAR2     --##
      ,argument_374          IN  VARCHAR2     --##
      ,argument_375          IN  VARCHAR2     --##
      ,argument_376          IN  VARCHAR2     --##
      ,argument_377          IN  VARCHAR2
      ,argument_378           IN  VARCHAR2     --##
      ,argument_379          IN  VARCHAR2
      ,argument_380          IN  VARCHAR2     --##
      ,argument_381          IN  VARCHAR2
      ,argument_382          IN  VARCHAR2
      ,argument_383          IN  VARCHAR2
      ,argument_384          IN  VARCHAR2
      ,argument_385          IN  VARCHAR2
      ,argument_386            IN  VARCHAR2 DEFAULT NULL
      )
  IS
    any_874    VARCHAR2(30);
    
    CURSOR cursor_215
          (parameter_58  IN  VARCHAR2) 
    IS
      SELECT column_619
        FROM dataset_670
       WHERE column_619 = column_1516
            ;
    any_875        cursor_215%ROWTYPE;
    
  BEGIN
    method_556 := column_1517;
    IF column_1518 IS NULL THEN
      method_556 := '######';
    END IF;
    
    method_557    := NULL;
    OPEN cursor_215(UPPER(column_1519));
    FETCH any_876       INTO any_875;
    CLOSE any_876;
    
    IF dataset_671.column_619 IS NULL THEN
      method_556 := '######';
    END IF;
    
    
    IF column_1518 = '######' THEN
      BEGIN
        DELETE FROM dataset_672         
         WHERE column_1520 = column_1521    
           AND column_1522 = column_1519   
           AND column_276 = column_1523  
           AND column_1524 = column_1525      
           AND column_1526 = column_1527
           AND column_1528 = column_1529
              ;
      EXCEPTION
        WHEN others THEN
          package_06.method_08('###### (######): ' || substr(replace(SQLERRM,'###-','###-#:'),1,200) );
          method_556 := NULL;
      END;
    END IF;
    
    IF column_1518 = '######' THEN
      BEGIN
        INSERT INTO dataset_672
              (column_1520
              ,column_1522
              ,column_276
              ,column_1524
              ,column_1530
              ,column_1526
              ,column_1531
              ,column_1528
              ,column_1532
              ,column_1533
              ,column_1534
              ,column_1535
              ,column_1536
              )
        VALUES
              (column_1521
              ,column_1519
              ,column_1523
              ,column_1525
              ,column_1537
              ,column_1527
              ,column_1538
              ,column_1529
              ,column_1539
              ,column_1540
              ,column_1541
              ,column_1542
              ,column_1543
              );
      EXCEPTION
        WHEN dup_val_on_index THEN
          method_556 := '######';
        WHEN others THEN
          package_06.method_08('###### (######): ' || substr(replace(SQLERRM,'###-','###-#:'),1,200) );
          method_556 := NULL;
      END;
    END IF;
    IF column_1518 = '######' THEN
      BEGIN
        UPDATE dataset_672         
           SET column_1530 = column_1537
              ,column_1531 = column_1538
              ,column_1532 = column_1539
              ,column_1533 = column_1540
              ,column_1534 = column_1541
              ,column_1535 = column_1542
              ,column_1536 = column_1543         
         WHERE column_1520 = column_1521    
           AND column_1522 = column_1519   
           AND column_276 = column_1523  
           AND column_1524 = column_1525      
           AND column_1526 = column_1527
           AND column_1528 = column_1529
              ;
      EXCEPTION
        WHEN others THEN
          package_06.method_08('###### (######): ' || substr(replace(SQLERRM,'###-','###-#:'),1,200) );
          method_556 := NULL;
      END;
    END IF;
    
  EXCEPTION
     WHEN others THEN
       package_06.method_08('###_#### (######): ' || substr(replace(SQLERRM,'###-','###-#:'),1,200) );
       
  END function_217;
  
BEGIN

  /*###_####('#######','###_######_####','#####_#####_#########','#####_###_#########_###_######','###_#######'
          ,'###_######_#####',####,'#####_###_#########_###_######','######','##','##','#######','##','######'
          );*/
  
           
   method_558('#######','###_######_####','#_###_########_######_#######','###_######_####','###_#######'
           ,'###_######_#####',NULL,'#######_##_######','######','##','##','######','##','######');
           
              
  
  COMMIT;

END;
/



BEGIN
    
    
     --#### ### ###### #####.
    package_323.method_1748 (
       argument_1425     => '###_######_####',
       argument_1426      => '#_###_########_######_#######',
       argument_1427      => '###_######_####'
    );
    
   
            
EXCEPTION
  WHEN others THEN
       IF SQLCODE ='-#####' THEN
      NULL;
     ELSE
        package_06.method_08('###_###_######_##### (######): ' || SUBSTR(REPLACE(SQLERRM,'###-','###-#:'),1,200) );
     END IF;
    
END;
/




BEGIN
    
    
    package_323.method_559
            (argument_1425   => '###_######_####'
            ,argument_1426     => '#_###_########_######_#######'
            ,argument_1427     => '###_######_####'            
            ,argument_2371   => '###_######_#####'
            ,argument_2372   => '#######_##_######'
            ,argument_2373   => '######'
            ,argument_6220   => TRUE
            ,argument_6221     => dataset_10182.column_29071
            );  
   
            
EXCEPTION
  WHEN others THEN
       IF SQLCODE ='-#####' THEN
      NULL;
     ELSE
        package_06.method_08('###_###_######_##### (######): ' || SUBSTR(REPLACE(SQLERRM,'###-','###-#:'),1,200) );
     END IF;
    
END;
/

COMMIT
/

alter session set current_schema=schema_138
/

