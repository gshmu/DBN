select column_1056      AS column_1056,
       column_5253         AS column_5253,
       column_15028          AS column_15028,
       column_6576  AS column_6576,
       column_5590     AS column_5590,
       column_2662 as column_15029,
       column_5590 * column_2662 AS column_11182     
    from
(SELECT dataset_977.column_1056      AS column_1056,
  dataset_1981.column_5253           AS column_5253,
  CASE
    WHEN dataset_977.column_1064 = '##########'
    AND dataset_977.column_6175      ='###_##_###'
    THEN '###_##_###'
    WHEN dataset_977.column_1064 = '##########'
    AND UPPER(dataset_977.column_8528) LIKE '############%'
    THEN '############_###'
    WHEN dataset_977.column_1064 = '####'
    AND dataset_977.column_8528      ='#######_#####_###_##########'
    THEN '####_###_#####_###'
    ELSE dataset_977.column_1064     
  END                       AS column_15028,
  dataset_977.column_549             AS column_5590,
  dataset_1981.column_604           AS column_6576,
  CASE
      WHEN nvl(dataset_977.column_2662,0) <> 0
      THEN dataset_977.column_2662
      WHEN nvl(dataset_1981.column_6951,0) <> 0
      THEN dataset_1981.column_6951    
      ELSE NULL
      END as column_2662
      FROM dataset_2485 dataset_461,
  dataset_2483      dataset_2484,
  dataset_1634                  dataset_1981,
  dataset_978                 dataset_977
WHERE 1                 =1
AND dataset_2484.column_3118  = 
AND dataset_461.column_3118   = dataset_2484.column_3118   
AND dataset_1981.column_07 = 
AND DECODE(dataset_461.column_6384, '######_####', dataset_1981.column_4126, '####', dataset_1981.column_598, '#############_####', dataset_1981.column_598
  || dataset_1981.column_3120, '#############', dataset_1981.column_451 )             = 
AND dataset_2484.column_598                                                                       = dataset_1981.column_598
AND dataset_1981.column_07                                                            = dataset_977.column_07     
AND dataset_1981.column_451                                                          = dataset_977.column_451      
AND dataset_1981.column_452                                                       = dataset_977.column_452         
AND DECODE(dataset_977.column_1064,'##########',NVL(dataset_977.column_8528,'$_$'),'$_$') <> '############'
AND dataset_977.column_1064                                                              <> '########'
AND dataset_977.column_1064      NOT LIKE '####_%'
AND NOT EXISTS
  (SELECT 1
  FROM dataset_978                 dataset_4865
  WHERE 1          =1
  AND dataset_977.column_3816 = dataset_4865.column_5289    
  AND dataset_4865.column_1064      LIKE '####_%'
  )
AND dataset_1981.column_11          = dataset_977.column_11
)
ORDER BY column_1056      DESC