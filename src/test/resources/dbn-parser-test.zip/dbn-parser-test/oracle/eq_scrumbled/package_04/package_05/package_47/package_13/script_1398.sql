--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_####_#######.###
--###
--###  ####### ####        ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        ########
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_####_#######';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_####_####### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_01
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_961
      ,column_962
      ,column_963
      ,column_964
      ,column_965
      ,column_966
      ,column_967
      ,column_968
      ,column_969
      ,column_970
      ,column_971
      ,column_972
      ,column_973
      ,column_974
      ,column_975
      ,column_976
      ,column_977
  FROM dataset_425@dblink_02.EQ
/

COMMIT
/

COMMENT ON MATERIALIZED VIEW materialized_view_01 IS '######## ##### ### ######## ###_#######.###_####_#######'
/
       





