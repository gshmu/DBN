/*
   #### ######## ######
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : ######## ### #### #### #######
   ##.#.#   ##.##.####   ########   ###-#### : ###### #### ###### #####
   ####### ##.#
   ##.#.#   ##.##.####   ########   ###-#### : ###### #### ########### #####
   ##.#.#   ##.##.####   ########   ###-#### : ####### ###### ##### #### ######## #############
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : ######## ###### ######### ######## ######
   ##.#.#   ##.##.####   ########   ###-#### : #### ##### ###########
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : #### ##### ########### ##### ##### ###
   ####### ##
   ##.#.#   ##.##.####   ########   ###-##### : ##### ##### ## ###### ######### ####.
   */
 select  dataset_268.column_599
        , DECODE(dataset_461.column_6384,
         '######_####', dataset_45.column_4126,
         '####', dataset_45.column_598,
         '#############_####', dataset_45.column_598 || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_598
         ) AS column_6383
        , DECODE(dataset_461.column_6384,
         '######_####', dataset_335.column_742,
         '####', dataset_45.column_742,
         '#############_####', dataset_45.column_742  || ' ' || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_742
         ) AS column_6558
        , dataset_268.column_742  column_9832
        , dataset_2397.column_08
        , dataset_2397.column_2748
        , sum(decode(dataset_318.column_04, '###########_############', dataset_318.column_4357)) column_11826
        , min(decode(dataset_318.column_04, '###########_############', dataset_318.column_1785)) column_11827
        , decode(count(distinct decode(dataset_318.column_04, '###########_############', dataset_318.column_1785)), 1, '#', '#') column_11828
        , sum(decode(dataset_318.column_04, '###########_############', dataset_318.column_4358)) column_11829
        , min(decode(dataset_318.column_04, '###########_############', dataset_318.column_5434)) column_2256

        , sum(decode(dataset_318.column_04, '#####_############', dataset_318.column_4358)) column_11830
        , min(decode(dataset_318.column_04, '#####_############', dataset_318.column_5434)) column_11831

        , count(distinct dataset_1172.column_12) column_11832
        , count(distinct dataset_318.column_12) column_7134       
     from (SELECT DISTINCT column_3118,
            column_598,
            CASE
            WHEN EXISTS
            (SELECT 1
                FROM dataset_2483      dataset_3724
                WHERE dataset_3724.column_3118    = dataset_45.column_3118   
                AND dataset_45.column_598                   = dataset_3724.column_598
                AND dataset_3724.column_1446        IS NULL )
            THEN NULL
            ELSE dataset_45.column_1446       
            END AS column_1446       
          FROM dataset_2483      dataset_45) dataset_2484
     join dataset_2485 dataset_461
       on dataset_2484.column_3118 = dataset_461.column_3118   
     join dataset_270 dataset_268
       on dataset_268.column_598 = dataset_2484.column_598
      and dataset_268.column_11 = nvl(dataset_2484.column_1446, dataset_268.column_11)
     join dataset_269 dataset_45
      on dataset_268.column_598 = dataset_45.column_598
     join dataset_269 dataset_335
      on dataset_45.column_4126 = dataset_335.column_598
     join dataset_272 dataset_2397
       on dataset_2397.column_599 = dataset_268.column_599   
      and dataset_2397.column_10 = '####'
     join dataset_1171           dataset_1172
       on dataset_1172.column_08 = dataset_2397.column_08  
     join dataset_1642                 dataset_1643
       on dataset_1643.column_1284 = dataset_1172.column_1284       
      and dataset_1643.column_07 = 
--      ### ###.###### = '######'
left join dataset_317                  dataset_318
       on dataset_318.column_07 = 
      and dataset_318.column_12 = dataset_1172.column_12      
      and dataset_318.column_10 = '####_########'     
    where dataset_2484.column_3118 = 
 group by dataset_268.column_599
        ,  DECODE(dataset_461.column_6384,
         '######_####', dataset_45.column_4126,
         '####', dataset_45.column_598,
         '#############_####', dataset_45.column_598 || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_598
         )
        , DECODE(dataset_461.column_6384,
         '######_####', dataset_335.column_742,
         '####', dataset_45.column_742,
         '#############_####', dataset_45.column_742  || ' ' || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_742
         )
        , dataset_268.column_742
        , dataset_268.column_973
        , dataset_2397.column_08
        , dataset_2397.column_2748  
  having count(distinct dataset_318.column_12) > 0
  order by dataset_268.column_973, dataset_268.column_742 