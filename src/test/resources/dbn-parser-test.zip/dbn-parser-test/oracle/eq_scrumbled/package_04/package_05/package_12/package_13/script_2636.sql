--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : ####_##_#########_##_############.###
--###
--###  ####### ####       ###               ########
--### *********************************************************************
--###  #.#     ##.##.#### ########### ########
--###  ##.#.#  ##.##.#### ###########  ###-####
--### *********************************************************************/


--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####


  CREATE OR REPLACE FORCE VIEW view_55 
  (column_22476, column_7310, column_723, column_10, column_532, column_19278, column_154,
  column_721, column_19277, column_19279, column_1716, column_1058,
  column_11365, column_19280, column_19281, column_19282, column_738,
  column_566, column_722, column_19283, column_9521, column_16498, column_19284,
  column_19286, column_19285, column_204, column_189, column_19287, column_19288
  ) AS 
  SELECT dataset_7124.column_22476, dataset_7124.column_7310,
       dataset_7124.column_723, dataset_7124.column_10, dataset_7124.column_532, dataset_7124.column_19278,
       dataset_7124.column_154, dataset_7124.column_721, dataset_7124.column_19277,
       dataset_7124.column_19279, dataset_7124.column_1716, dataset_7124.column_1058, sequence_272.column_11365,
       dataset_7124.column_19280, dataset_7124.column_19281, dataset_7124.column_19282,
       dataset_7124.column_738, dataset_7124.column_566, dataset_7124.column_722, dataset_7124.column_19283,
       dataset_7124.column_9521, dataset_7124.column_16498, dataset_7124.column_19284, dataset_7124.column_19286,
       dataset_7124.column_19285,dataset_7124.column_204, dataset_7124.column_189, dataset_7124.column_19287
       ,dataset_7124.column_19288
  FROM dataset_3896        dataset_7124
  WHERE dataset_7124.column_354 = SYS_CONTEXT('###_#######_###','#######')
/  

COMMIT
/
      





