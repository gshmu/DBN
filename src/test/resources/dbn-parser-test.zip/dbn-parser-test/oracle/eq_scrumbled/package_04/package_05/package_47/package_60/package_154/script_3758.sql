with dataset_1204 as
  (
          select
                   column_07
                 , column_1568        
          from
                   dataset_369          
          where
                  ( column_07, column_1550 ) in
                    (
                      select
                               column_07
                             , max ( column_1550 )
                      from
                               dataset_369          
                      where
                               column_780 = '##'
                      group by
                               column_07
                      )
          and column_780 = '##'
  )

, dataset_1205 as
    (
        select
            dataset_333.column_07
          , dataset_333.column_2333
          , dataset_333.column_2334
          , dataset_333.column_2335
          , dataset_333.column_963
          , dataset_333.column_2358
          , dataset_333.column_1746 as column_2829
          , dataset_333.column_213
        from
            dataset_738             dataset_335
          , dataset_736 dataset_333
          , (
                select
                    column_07
                  , min ( column_1619 ) as column_1619 
                from
                    dataset_736
                where
                    column_1619  in ( '####', '####' )
                group by
                    column_07
            )
            dataset_1206
       where
            dataset_335.column_07(+) = dataset_333.column_07     
            and dataset_333.column_1619 = nvl ( dataset_335.column_179, dataset_1206.column_1619 )
            and dataset_335.column_1622(+) = '#######'
            and dataset_333.column_07 = dataset_1206.column_07(+)
    )

 select
      dataset_104.column_2830             as column_2831
    , dataset_104.column_2830             as column_2832
    , dataset_104.column_742  as column_2833
    , package_168.package_function_168(dataset_104.column_2333,dataset_104.column_2334,dataset_104.column_2335,'####') as column_2834
    , package_168.package_function_168(dataset_104.column_2333,dataset_104.column_2334,dataset_104.column_2335,'#####') as column_2835
    , package_168.package_function_168(dataset_104.column_963,null,null,'####') as column_2836
    , package_169.package_function_169(dataset_104.column_2358) as column_2837
    , package_168.package_function_168(dataset_104.column_1746,null,null,'###')  as column_2838
    ,     case
         when function_367 ( coalesce(dataset_1207.column_1568, dataset_45.column_2839, '#/#'), '$.#######' ) then '######'
         else ( coalesce(dataset_1207.column_1568, dataset_45.column_2839, '#/#') )
         end as column_2840
    , package_170.package_function_170(dataset_45.column_74,dataset_45.column_1578,dataset_45.column_75) as column_286
    , package_168.package_function_168(dataset_1205.column_2333, dataset_1205.column_2334, dataset_1205.column_2335,'####') as column_2841
    , package_168.package_function_168(dataset_1205.column_2333, dataset_1205.column_2334, dataset_1205.column_2335,'#####') as column_2842
    , package_168.package_function_168(dataset_1205.column_963,null,null,'####') as column_963
    , decode (upper(dataset_1205.column_213),'##',package_170.package_function_171(upper(dataset_1205.column_2358)),dataset_1205.column_2358) as column_2358
    , package_168.package_function_168(dataset_1205.column_2829,null,null,'###') as column_2829
    , decode (upper(dataset_1205.column_213), '##', null , package_169.package_function_169(dataset_1205.column_213)) as column_2843
    , dataset_333.column_07      as column_2844
    , to_char ( dataset_333.column_2721, '##.##.####' ) as column_2845
    , to_char ( dataset_665.column_900, '##.##.####' ) as column_2846
    , round ( dataset_666.column_2708, 4 ) as column_13894
    , round ( dataset_314.column_2711, 4 ) as column_13895
    , dataset_665.column_2265       as column_2853
    , '' as column_13896
    , dataset_665.column_148           as column_2856
from  dataset_15 dataset_104
    , dataset_336 dataset_333
   ------------------------------------------------------------
inner join dataset_50   dataset_45
on
  dataset_45.column_07 = dataset_333.column_07     
   ------------------------------------------------------------
inner join dataset_315    dataset_1209
on
  dataset_333.column_451 = dataset_1209.column_451      
   ------------------------------------------------------------
inner join dataset_269 dataset_320
on
  dataset_1209.column_598 = dataset_320.column_598
   ------------------------------------------------------------
left outer join dataset_1204 dataset_1207
on
  dataset_45.column_07 = dataset_1207.column_07     
   ------------------------------------------------------------
left outer join  dataset_1205
on
  dataset_45.column_07 = dataset_1205.column_07     
   ------------------------------------------------------------
inner join dataset_668                 dataset_666
on
  dataset_333.column_07 = dataset_666.column_07     
  and dataset_333.column_451 = dataset_666.column_451      
  and dataset_333.column_452 = dataset_666.column_452         
   ------------------------------------------------------------
inner join dataset_667           dataset_665
on
  dataset_666.column_148 = dataset_665.column_148          
  and dataset_666.column_718 = dataset_665.column_718        
  and  dataset_665.column_1064      in ( '########', '########', '###' )
   ------------------------------------------------------------
inner join dataset_313                   dataset_314
on
  dataset_666.column_148 = dataset_314.column_148          
  and dataset_666.column_452 = dataset_314.column_452         
  and dataset_666.column_07 = dataset_314.column_07     
  and dataset_666.column_451 = dataset_314.column_451      

   ------------------------------------------------------------
where
      (( dataset_320.column_601 = '##_###' and  dataset_333.column_2710 = '#') or dataset_333.column_2710 = '##_###')
      and dataset_665.column_900     between to_date('01.01.2001','##.###.####') and to_date('01.01.2021','##.###.####')
      and dataset_665.column_1064      in ( '########', '########', '###' )
      and dataset_45.column_2860    in (
                                '#_######_#',
                                '#_######_#',
                                '############',
                                '##',
                                '##_###',
                                '##_######'
                                )

   ------------------------------------------------------------
group by
         dataset_104.column_2830
       , dataset_104.column_742
       , dataset_104.column_2333
       , dataset_104.column_2334
       , dataset_104.column_2335
       , dataset_104.column_963
       , dataset_104.column_2358
       , dataset_104.column_1746
       , dataset_1207.column_1568
       , dataset_45.column_2839
       , dataset_45.column_74
       , dataset_45.column_1578
       , dataset_45.column_75
       , dataset_1205.column_2333
       , dataset_1205.column_2334
       , dataset_1205.column_2335
       , dataset_1205.column_963
       , dataset_1205.column_2358
       , dataset_1205.column_2829
       , dataset_1205.column_213
       , dataset_333.column_07
       , dataset_333.column_2721
       , dataset_665.column_900
       , dataset_666.column_2708
       , dataset_314.column_2711
       , dataset_665.column_2265
       , dataset_665.column_148          