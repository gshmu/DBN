/******************************************************************************
    ##### #####: ########_#####_#######
    #########:   ########_#####
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### ######## ##### ##### (####### #####)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_####                      ###### ####
        - #########                        #########
        - ########_#########               ######## #########
        - ########_#########               ######## #########
        - #############_########           ############# ########
        - ###########_####                 ########### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #######                          #######
        - ####_#####                       #### #####
        - #######_####                     ####### ####
        - ####_####_#                      #### #### #
        - ####_#####                       #### #####
        - ####_#####                       #### #####
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - ########                         ######## & #### ####
        - ####_###                         #### ###
        - #####_######                     ##### ######
        - ####                             ####
        - #######                          #######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####

    ###### ## ###########:  ##(######## #####)||###(#######)||<####### ##### ##>||<#########>||<###>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ##.#.#    ##.##.####   ### #####    ###-##### ####### ####### ### ########### ########
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ######## ######## #####/#### ######
    ##.#.#    ##.##        ##           ###-##### ##### ### ####### #######
    ####### ##
    ##.#.#    ##.##.####   ### #####    ###-##### ########_##### ######## ####
    ##.#.#    ##.##.####   ### #####    ###-##### ########_##### ######## #########
    ##.#.#    ##.##.####   ### #####    ###-##### ########_##### ########### ####
    ##.#.#    ##.##.####   ### #####    ###-##### ########### #### #####
    ##.#.#    ##.##.####   ### #####    ###-##### ######## ##### (## ######)
    ##.#.#    ##.##.####   ### #####    ###-##### ######## ######### ## ##### ###### ###
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### #### ####### ##########
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ####### ###### (######## ###### ####)
*******************************************************************************/

SELECT
    column_354                    AS column_354,
    column_1117                     AS column_1117,
    column_2468                   AS column_2468,
    column_1328                   AS column_1328,
    column_1056                   AS column_1056,
    NULL                          AS column_7074,
    column_7075                     AS column_7075,
    column_7076                   AS column_7076,
    column_7077                   AS column_7077,
    column_7078                   AS column_7078,
    column_7079                   AS column_7079,
    NULL                          AS column_7080,
    NULL                          AS column_7081,
    column_5704                    AS column_5704,
    column_2329                   AS column_2329,
    column_7082                   AS column_7082,
    column_7083                   AS column_7083,
    NULL                          AS column_874,
    NULL                          AS column_7084,
    column_7085                   AS column_7085,
    column_1477                   AS column_1477,
    NULL                          AS column_549,
    column_7086                       AS column_7086,
    column_7087                    AS column_7087,
    column_563                    AS column_563,
    NULL                          AS column_7088,
    NULL                          AS column_7089,
    NULL                          AS column_7090,
    NULL                          AS column_7091,
    NULL                          AS column_7092,
    NULL                          AS column_7093,
    NULL                          AS column_7094,
    NULL                          AS column_7095,
    NULL                          AS column_7096,
    NULL                          AS column_7097,
    NULL                          AS column_7098,
    NULL                          AS column_7099,
    NULL                          AS column_7100,
    NULL                          AS column_7101,
    NULL                          AS column_7102,
    column_7103                      AS column_7103,
    NULL                          AS column_7104,
    column_753                    AS column_753,
    column_562                          AS column_562,
    column_7105                       AS column_7105,
    column_534                    AS column_534,
    NULL                          AS column_7106,
    NULL                          AS column_7107,
    NULL                          AS column_7108,
    NULL                          AS column_7109,
    NULL                          AS column_7110,
    NULL                          AS column_7111,
    NULL                          AS column_7112,
    NULL                          AS column_7113,
    NULL                          AS column_7114
FROM (
    WITH
    dataset_263 AS(
        SELECT package_11.package_function_04(
                            argument_01             => '#####',
                            argument_40             => '##############',
                            argument_18             => dataset_899.column_354,
                            argument_41             => '########_#####',
                            argument_42             => '#######_#####') as column_2343  
        FROM dataset_62, dataset_360  dataset_899),

    dataset_943   AS (
        SELECT TRIM(regexp_substr(dataset_263.column_2343,'[^,]+', 1, LEVEL)) AS column_533  
        FROM dataset_263 CONNECT BY regexp_substr(dataset_263.column_2343, '[^,]+', 1, LEVEL) IS NOT NULL),
        
     dataset_944           as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),

    dataset_227  AS (
        SELECT DISTINCT
            dataset_228.column_527                 AS column_527,
            dataset_228.column_528                 AS column_528,
            dataset_228.column_529                 AS column_529,
            dataset_228.column_530                 AS column_530,
            dataset_228.column_531                 AS column_531,
            dataset_228.column_532                 AS column_532,
            dataset_228.column_533                 AS column_533,
            dataset_228.column_534                 AS column_534,
            package_131.package_function_134(dataset_228.column_527,
                dataset_228.column_528,dataset_228.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_229                  dataset_228, dataset_944           dataset_948 where dataset_228.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_230.column_527                  AS column_527,
            dataset_230.column_528                  AS column_528,
            dataset_230.column_529                  AS column_529,
            dataset_230.column_530                  AS column_530,
            dataset_230.column_531                  AS column_531,
            dataset_230.column_532                  AS column_532,
            dataset_230.column_533                  AS column_533,
            dataset_230.column_534                  AS column_534,
            package_131.package_function_134(dataset_230.column_527,
                dataset_230.column_528,dataset_230.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_231          dataset_230,dataset_944           dataset_948 where dataset_230.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_232.column_538                 AS column_527,
            dataset_232.column_539                 AS column_528,
            dataset_232.column_540                 AS column_529,
            dataset_232.column_541                 AS column_530,
            dataset_232.column_531                 AS column_531,
            dataset_232.column_542                 AS column_532,
            '#######'                      AS column_533,
            dataset_232.column_534                 AS column_534,
            package_131.package_function_134(dataset_232.column_538,
                dataset_232.column_539,dataset_232.column_540,dataset_948.column_2344) as column_535        
        FROM dataset_233           dataset_232,dataset_944           dataset_948 where dataset_232.column_541=dataset_948.column_591),

    dataset_947       AS (
            SELECT DISTINCT dataset_102.*
              FROM dataset_227  dataset_102,
                   dataset_943   dataset_2719
             WHERE 1=1
               AND dataset_102.column_531 = '#####'
               AND dataset_102.column_533 = dataset_2719.column_533  
          ORDER BY dataset_102.column_533,
                   dataset_102.column_528),

    dataset_2720 AS (
            SELECT dataset_235.column_544,
                   dataset_235.column_545,
                   MAX(dataset_235.column_525) AS column_525
              FROM dataset_226     dataset_235
             WHERE 1=1
               AND column_525 <= 
          GROUP BY column_544,
                   column_545),

    dataset_236 AS (
            SELECT dataset_235.*
              FROM dataset_226     dataset_235,
                   dataset_2720 dataset_237
             WHERE 1=1
               AND dataset_235.column_544 = dataset_237.column_544 
               AND dataset_235.column_545 = dataset_237.column_545  
               AND dataset_235.column_525 = dataset_237.column_525
               AND dataset_235.column_545 = '##########_####'),

    dataset_238           AS (
            SELECT DISTINCT
                   dataset_235.column_548,
                   dataset_240.column_550         
              FROM dataset_236 dataset_235,
                   dataset_241              dataset_240
             WHERE 1=1
               AND dataset_240.column_548 = dataset_235.column_548
               ),

    dataset_242  AS (
            SELECT dataset_235.column_548                                   AS column_548,
                   dataset_235.column_544                                   AS column_544,
                   dataset_235.column_525                                   AS column_2353,
                   GREATEST(dataset_235.column_525, )          AS column_525,
                   dataset_235.column_545                                   AS column_545,
                   dataset_235.column_549                                     AS column_549,
                   dataset_235.column_549                                     AS column_551,
                   CASE
                       WHEN TRUNC(dataset_235.column_525) < 
                       THEN dataset_235.column_548
                       WHEN dataset_254.column_550          IS NULL THEN dataset_235.column_548
                       ELSE dataset_254.column_550         
                   END                                              AS column_550,
                   CASE
                       WHEN TRUNC(dataset_235.column_525) < 
                       THEN dataset_235.column_549
                       WHEN dataset_254.column_550          IS NULL THEN 0
                       ELSE dataset_2721.column_549
                   END                                              AS column_575     
              FROM dataset_236 dataset_235,
                   dataset_238           dataset_254,
                   dataset_226     dataset_2721,
                   dataset_247      dataset_244
             WHERE TRUNC(dataset_235.column_525) <= 
               AND dataset_235.column_545 = '##########_####'
               AND dataset_235.column_548 = dataset_254.column_548
               AND dataset_235.column_544 = dataset_244.column_544 
               AND EXISTS (SELECT NULL
                             FROM dataset_947      
                            WHERE column_535 = dataset_244.column_535)
               AND dataset_2721.column_548 = nvl(dataset_254.column_550, dataset_235.column_548)),


    dataset_952          AS (
            SELECT dataset_259.column_555,
                   dataset_953.column_2346 AS column_76,
                   dataset_953.column_2347      AS column_2348       
              FROM dataset_954             dataset_953,
                   dataset_260      dataset_259
             WHERE dataset_953.column_2349 = '###_#######'
               AND dataset_953.column_354 = '###_#########'
               AND dataset_953.column_2350 = '######+'
               AND dataset_953.column_2351 = '###_########_######'
               AND dataset_953.column_221 = '#######_######'
               AND dataset_953.column_2352 = '*'
               AND dataset_953.column_2346 = dataset_259.column_76),

    dataset_949                            as (
            SELECT  /*+ ########### */ dataset_950.column_76     
              FROM dataset_951                      dataset_950
                  ,dataset_360  dataset_104
             WHERE column_2345 = 
               AND DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),

    dataset_2722           AS (
            SELECT dataset_953.column_2346 AS column_3063,
                   dataset_953.column_2347      AS column_7115          
              FROM dataset_954             dataset_953
             WHERE dataset_953.column_2349 = '###_#######'
               AND dataset_953.column_354 = '###_#########'
               AND dataset_953.column_2350 = '######+'
               AND dataset_953.column_2351 = '###_########_######'
               AND dataset_953.column_221 = '############_####'
               AND dataset_953.column_2352 = '*'),
               
    dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),
    
   dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),
      dataset_2724 as(select /*+ ########### */  
                    * 
                from dataset_563              
                where 1=1 
                AND column_204 >  
                AND column_204 <= ),                       
   
    dataset_2725     AS (
            select column_354,
            MAX(column_1117) as column_1117,
            column_2468,
            column_1328,
            column_1056,
            column_7075,
            column_7076,
            column_7077,
            column_7079,
            column_7078,
            column_5704,
            column_2329,
            column_7082,
            column_7083,
            column_562,
            SUM(column_7085) as column_7085,
            SUM(column_1477) as column_1477,
            column_7086,
            column_7087,
            column_563,
            column_7103,
            column_753,
            column_7105,
            column_534       
          from ( SELECT  dataset_899.column_354                                                   AS column_354,
                   '#####' || dataset_899.column_122       || '#'
                           || 
                           || dataset_243.column_556                                        
                          AS column_1117,
                   '#'                                                               AS column_2468,
                    CASE WHEN dataset_899.column_753='#############_##' 
                         THEN package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354) ||'##' 
                         ELSE package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)
                           || dataset_899.column_122       || '_'
                           || dataset_259.column_2348       
                           || dataset_244.column_7116 
                           || dataset_244.column_2355                   || '_'
                           || dataset_244.column_562
                           ||'_##'
                     END                                                                AS column_1328,
                   TO_CHAR(dataset_243.column_567, '##/##/####')                        AS column_1056,
                   dataset_244.column_573                                                       AS column_7075,
                   CASE
                       WHEN dataset_243.column_565 = '###########_####_####_#####'
                       THEN NVL(dataset_243.column_568,dataset_243.column_569)
                       ||'#'
                       WHEN dataset_243.column_565   IN
                                ('#####_############.#####.########',
                                 '##########_############.#####_############.########_############_#####')
                       THEN (SELECT dataset_312.column_583          
                               FROM dataset_311        dataset_312
                              WHERE dataset_312.column_148 = dataset_243.column_568)

                       WHEN dataset_243.column_565 = '#####_############.####.########'
                       THEN (SELECT dataset_256.column_3619        
                               FROM dataset_311        dataset_312,
                                    dataset_257  dataset_256
                               WHERE dataset_312.column_148 = dataset_243.column_568            
                                 AND dataset_256.column_583 = dataset_312.column_583)

                       ELSE NVL(dataset_243.column_568,dataset_243.column_569)
                   END  
                   ||
                   CASE
                           WHEN dataset_250.column_561  IS NOT NULL
                            AND dataset_250.column_561  IN ('#########_###########', '#######_######')
                            AND (dataset_243.column_549) < 1
                           THEN '#'
                           ELSE ''
                   END                                                                 AS column_7076,
                   NULL                                                              AS column_7077,
                   CASE
                       WHEN dataset_243.column_564 = '###'
                        AND dataset_243.column_565 = '###########_#######_#########.########_############_#####'
                       THEN '###:########'

                       WHEN dataset_243.column_564 = '###'
                        AND dataset_243.column_565   <> '###########_####_####_#####'
                       THEN '###:####'

                       ELSE dataset_243.column_564            
                   END                                                               AS column_7079,
                   NULL                                                              AS column_7078,
                   DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558)                         AS column_5704,
                   dataset_899.column_122                                                   AS column_2329,
                   NVL(dataset_243.column_568,dataset_243.column_569)       AS column_7082,
                   '#####'                                                           AS column_7083,
                   dataset_244.column_562                                                           AS column_562,
                   DECODE(dataset_243.column_552, '#', (dataset_243.column_549), NULL)            AS column_7085,
                  DECODE(dataset_243.column_552, '#', (dataset_243.column_549), NULL)            AS column_1477,
                   NULL                                                              AS column_7086,
                   NULL                                                              AS column_7087,
                   TO_CHAR(dataset_243.column_566, '##/##/####')                             AS column_563,
                   dataset_244.column_532    || DECODE(
                            dataset_244.column_606, '*', NULL,
                            ' '||dataset_2727.column_7115 )                        AS column_7103,
                   dataset_259.column_2348                                                    AS column_753,
                   dataset_244.column_7116                                                    AS column_7105,
                   dataset_244.column_2355                                                    AS column_534,
                   dataset_243.column_552                                                    AS column_552       
              FROM dataset_242  dataset_253,
                   dataset_241              dataset_240,
                   dataset_246                 dataset_243,
                   dataset_247      dataset_244,
                   dataset_360  dataset_899,
                   dataset_952          dataset_259,
                   dataset_949                            dataset_964,
                   dataset_2722           dataset_2727,
                   dataset_252       dataset_250
                   ,dataset_2723      dataset_2726
                   ,dataset_959        dataset_962
             WHERE 1=1
               AND dataset_253.column_2353 = dataset_253.column_525
               AND dataset_240.column_548 = dataset_253.column_548
               AND dataset_243.column_556 = dataset_240.column_556            
               AND dataset_244.column_544 = dataset_243.column_544 
               AND dataset_244.column_531 = '#####'
               AND dataset_259.column_555 = dataset_244.column_555       
               AND dataset_964.column_76 = dataset_259.column_76     
               AND dataset_244.column_573 = dataset_250.column_560(+)
               AND dataset_244.column_606 = dataset_2727.column_3063 (+)
               and dataset_244.column_2356=dataset_2726.column_591
               and dataset_244.column_2356=dataset_962.column_591)
               group by column_354,
                        column_2468,
                        column_1056,
                        column_1328,
                        column_7075,
                        column_7076,
                        column_7079,
                        column_7078,
                        column_5704,
                        column_2329,
                        column_7082,
                        column_7083,
                        column_562,
                        column_7086,
                        column_7087,
                        column_563,
                        column_7103,
                        column_753,
                        column_7105,
                        column_534,
                        column_552
               ),

    dataset_2728    AS (
            SELECT dataset_899.column_354                                                  AS column_354,
                   '#####' || dataset_899.column_122       || '#'
                           || 
                           || dataset_259.column_2348       
                           || dataset_244.column_535        
                           || dataset_244.column_562
                           || dataset_244.column_532   
                           || dataset_244.column_7116 
                           || dataset_244.column_2355                                        AS column_1117,
                   '#'                                                              AS column_2468,
                   CASE WHEN dataset_899.column_753='#############_##' 
                        THEN package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354) ||'##'
                        ELSE package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)
                           || dataset_899.column_122       || '_'
                           || dataset_259.column_2348       
                           || dataset_244.column_7116 
                           || dataset_244.column_2355                   || '_'
                           || dataset_244.column_562
                           ||'_##' 
                    END                                                             AS column_1328,
                   TO_CHAR(dataset_253.column_525, '##/##/####')                             AS column_1056,
                   '##### #####: ####### #######'                                   AS column_7075,
                   '####### '||dataset_244.column_532   ||' '
                             ||DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558||' ')
                             ||DECODE(dataset_244.column_606, '*', NULL,
                                      dataset_2727.column_7115          ||' ')
                             ||TO_CHAR(dataset_253.column_525, '######')                     AS column_7076,
                   NULL                                                             AS column_7077,
                   NULL                                                             AS column_7079,
                   NULL                                                             AS column_7078,
                   DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558)                        AS column_5704,
                   dataset_899.column_122                                                  AS column_2329,
                   NULL                                                             AS column_7082,
                   '#####'                                                          AS column_7083,
                   dataset_244.column_562                                                          AS column_562,
                   NULL                                                             AS column_7085,
                   SUM(dataset_253.column_549)                                                 AS column_1477,
                   NULL                                                             AS column_7086,
                   NULL                                                             AS column_7087,
                   NULL                                                             AS column_563,
                   dataset_244.column_532    || DECODE(
                            dataset_244.column_606, '*', NULL,
                            ' '||dataset_2727.column_7115 )                       AS column_7103,
                   dataset_259.column_2348                                                   AS column_753,
                   dataset_244.column_7116                                                   AS column_7105,
                   dataset_244.column_2355                                                   AS column_534       
              FROM dataset_242  dataset_253,
                   dataset_247      dataset_244,
                   dataset_360  dataset_899,
                   dataset_952          dataset_259,
                   dataset_949                            dataset_964,
                   dataset_2722           dataset_2727
                   ,dataset_2723      dataset_2726
                   ,dataset_959        dataset_962
             WHERE 1=1
               AND dataset_244.column_544 = dataset_253.column_544 
               AND dataset_244.column_531 = '#####'
               AND dataset_259.column_555 = dataset_244.column_555       
               AND dataset_964.column_76 = dataset_259.column_76     
               AND dataset_244.column_606 = dataset_2727.column_3063 (+)
               AND (dataset_253.column_551      <> 0 OR dataset_253.column_575      <> 0)
               and dataset_244.column_2356=dataset_2726.column_591
               and dataset_244.column_2356=dataset_962.column_591
          GROUP BY dataset_899.column_354,
                   dataset_899.column_122,
                   dataset_253.column_525,
                   dataset_259.column_2348,
                   dataset_244.column_562,
                   dataset_244.column_532,
                   dataset_244.column_7116,
                   dataset_244.column_535,
                   dataset_2726.column_2344,
                   dataset_962.column_2354,
                   dataset_244.column_2355,
                   dataset_244.column_558,
                   dataset_244.column_606,
                   dataset_2727.column_7115,dataset_899.column_753),

    dataset_2729    AS (
            SELECT dataset_899.column_354                                               AS column_354,
                   '#####' || dataset_899.column_122       || '#'
                           || 
                           || dataset_259.column_2348       
                           || dataset_244.column_535        
                           || dataset_244.column_562
                           || dataset_244.column_532   
                           || dataset_244.column_7116 
                           || dataset_244.column_2355                                     AS column_1117,
                   '#'                                                           AS column_2468,
                     CASE WHEN dataset_899.column_753='#############_##' 
                          THEN package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354) ||'##'
                          ELSE package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)
                           || dataset_899.column_122       || '_'
                           || dataset_259.column_2348       
                           || dataset_244.column_7116 
                           || dataset_244.column_2355                   || '_'
                           || dataset_244.column_562
                           ||'_##' 
                     END                                                         AS column_1328,
                   TO_CHAR(dataset_253.column_525, '##/##/####')                          AS column_1056,
                   '##### #####: ####### #######'                                AS column_7075,
                   '####### '||dataset_244.column_532   ||' '
                             ||DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558||' ')
                             ||DECODE(dataset_244.column_606, '*', NULL,
                                      dataset_2727.column_7115          ||' ')
                             ||TO_CHAR(dataset_253.column_525-1, '######')               AS column_7076,
                   NULL                                                          AS column_7077,
                   NULL                                                          AS column_7079,
                   NULL                                                          AS column_7078,
                   DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558)                     AS column_5704,
                   dataset_899.column_122                                               AS column_2329,
                   NULL                                                          AS column_7082,
                   '#####'                                                       AS column_7083,
                   dataset_244.column_562                                                       AS column_562,
                   SUM(dataset_253.column_575)                                       AS column_7085,
                   NULL                                                          AS column_1477,
                   NULL                                                          AS column_7086,
                   NULL                                                          AS column_7087,
                   NULL                                                          AS column_563,
                   dataset_244.column_532    || DECODE(
                            dataset_244.column_606, '*', NULL,
                            ' '||dataset_2727.column_7115 )                    AS column_7103,
                   dataset_259.column_2348                                                AS column_753,
                   dataset_244.column_7116                                                AS column_7105,
                   dataset_244.column_2355                                                AS column_534       
              FROM dataset_242  dataset_253,
                   dataset_226     dataset_235,
                   dataset_247      dataset_244,
                   dataset_360  dataset_899,
                   dataset_952          dataset_259,
                   dataset_949                            dataset_964,
                   dataset_2722           dataset_2727
                   ,dataset_2723      dataset_2726
                   ,dataset_959        dataset_962
             WHERE 1=1
               AND dataset_235.column_548 = dataset_253.column_550         
               AND dataset_244.column_544 = dataset_235.column_544 
               AND dataset_244.column_531 = '#####'
               AND dataset_259.column_555 = dataset_244.column_555       
               AND dataset_964.column_76 = dataset_259.column_76     
               AND dataset_244.column_606 = dataset_2727.column_3063 (+)
               AND (dataset_253.column_551      <> 0 OR dataset_253.column_575      <> 0)
                and dataset_244.column_2356=dataset_2726.column_591
            and dataset_244.column_2356=dataset_962.column_591
          GROUP BY dataset_899.column_354,
                   dataset_899.column_122,
                   dataset_253.column_525,
                   dataset_259.column_2348,
                   dataset_244.column_562,
                   dataset_244.column_532,
                   dataset_244.column_7116,
                   dataset_244.column_535,
                   dataset_2726.column_2344,
                   dataset_962.column_2354,
                   dataset_244.column_2355,
                   dataset_244.column_558,
                   dataset_244.column_606,
                   dataset_2727.column_7115,dataset_899.column_753)

    SELECT dataset_2730.*, 1 AS column_500 FROM dataset_2725     dataset_2730 UNION ALL
    SELECT dataset_2731.*, 2 AS column_500 FROM dataset_2729    dataset_2731 UNION ALL
    SELECT dataset_969.*, 3 AS column_500 FROM dataset_2728    dataset_969


    UNION ALL
    SELECT
        column_354,
        column_1117,
        column_2468,
         CASE WHEN column_7117='#############_##' THEN column_1328    ||'##'  
         ELSE column_1328           ||
             column_2329      ||'_'||
             column_753       ||
             column_7105          ||
             column_534       ||'_'||
             column_562||'_##' 
         END           AS column_1328,
        column_1056,
        column_7075,
        column_7076,
        column_7077,
        column_7079,
        column_7078,
        column_5704,
        column_2329,
        column_7082,
        column_7083,
        column_562,
        column_7085,
        column_1477,
        column_7086,
        column_7087,
        column_563,
        column_7103,
        column_753,
        column_7105,
        column_534,
        4 as column_500
    FROM (
        SELECT
            dataset_104.column_354                                                         AS column_354,
            '#####' || dataset_104.column_122       || '#' || dataset_937.column_7118               AS column_1117,
            '#'                                                                  AS column_2468,
         package_131.package_function_134(  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1318               
                 ELSE dataset_503.column_2400                 
            END    ,
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1319           
                 ELSE dataset_503.column_2401             
            END     ,  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1320          
                 ELSE dataset_503.column_2396            
            END    ,dataset_2726.column_2344)                                               AS column_1328,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_1056,
            '### - ########## ## ######'                                         AS column_7075,
            dataset_503.column_148                                                        AS column_7076,
            dataset_343.column_3620                                                      AS column_7077,
            NULL                                                                 AS column_7079,
            dataset_937.column_532                                                        AS column_7078,
            NULL                                                                 AS column_5704,
            dataset_104.column_122                                                         AS column_2329,
            dataset_503.column_148                                                        AS column_7082,
            '#####'                                                              AS column_7083,
            dataset_937.column_562                                                              AS column_562,
            DECODE(dataset_937.column_3916, '###', dataset_937.column_3920, NULL)            AS column_7085,
            DECODE(dataset_937.column_3916, '####', dataset_937.column_3920, NULL)           AS column_1477,
            package_131.package_function_140(
                        '#####',
                         dataset_747.column_532,
                         dataset_747.column_735)                                              AS column_7086,
            dataset_937.column_7119                                                        AS column_7087,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_563,
            dataset_503.column_11                                                           AS column_7103,
            dataset_259.column_2348                                                       AS column_753,
            package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_503.column_1065,
                            argument_73             => dataset_503.column_76,
                            argument_252            => dataset_104.column_753,
                            argument_672            => dataset_503.column_534)     AS column_7105,
            dataset_503.column_534                                                        AS column_534,
            dataset_104.column_753                                                         AS column_7117            
        FROM dataset_1519       dataset_937,
             dataset_2724 dataset_503,
             dataset_1369      dataset_747,
             dataset_257  dataset_256,
             dataset_342              dataset_343,
             dataset_265           dataset_2732,
             dataset_952          dataset_259,
             dataset_949                            dataset_964,
             dataset_360  dataset_104,
             dataset_2723      dataset_2726  
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_937.column_1061 = '##'
            AND dataset_937.column_1071               <> '###'
            AND dataset_256.column_583 = dataset_937.column_148          
            AND dataset_256.column_3619         IS NULL
            AND dataset_503.column_148 = dataset_256.column_583          
            AND dataset_503.column_1065 = '######-#########-#####'
            AND dataset_747.column_148 = dataset_937.column_148          
            AND dataset_747.column_1065 = '######-#########-####-##'
            AND dataset_503.column_76 = dataset_259.column_76 (+)
            AND dataset_503.column_76 = dataset_964.column_76     
            AND dataset_2732.column_76 = dataset_503.column_76     
            AND dataset_343.column_725 = dataset_2732.column_724            
            AND  CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_2440           
                 ELSE dataset_503.column_3753             
            END    =dataset_2726.column_591

        -- ######## ######## #####_#### #####
        UNION ALL
        SELECT
            dataset_104.column_354                                                         AS column_354,
            '#####' || dataset_104.column_122       || '#' || dataset_937.column_7118               AS column_1117,
            '#'                                                                  AS column_2468,
            package_131.package_function_134(  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1318               
                 ELSE dataset_503.column_2400                 
            END    ,
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1319           
                 ELSE dataset_503.column_2401             
            END     ,  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_1320          
                 ELSE dataset_503.column_2396            
            END    ,dataset_2726.column_2344)                                               AS column_1328,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_1056,
            '### - ########## ## ######'                                         AS column_7075,
            dataset_503.column_148                                                        AS column_7076,
            dataset_343.column_3620                                                      AS column_7077,
            NULL                                                                 AS column_7079,
            dataset_937.column_532                                                        AS column_7078,
            NULL                                                                 AS column_5704,
            dataset_104.column_122                                                         AS column_2329,
            dataset_503.column_148                                                        AS column_7082,
            '#####'                                                              AS column_7083,
            dataset_937.column_562                                                              AS column_562,
            DECODE(dataset_937.column_3916, '###', dataset_937.column_3920, NULL)            AS column_7085,
            DECODE(dataset_937.column_3916, '####', dataset_937.column_3920, NULL)           AS column_1477,
            package_131.package_function_140(
                        '#####',
                         dataset_747.column_532,
                         dataset_747.column_735)                                              AS column_7086,
            dataset_937.column_7119                                                        AS column_7087,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_563,
            dataset_503.column_11                                                           AS column_7103,
            dataset_259.column_2348                                                       AS column_753,
            package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_503.column_1065,
                            argument_73             => dataset_503.column_76,
                            argument_252            => dataset_104.column_753,
                            argument_672            => dataset_503.column_534)     AS column_7105,
            dataset_503.column_534                                                        AS column_534,
            dataset_104.column_753                                                         AS column_7117            
        FROM dataset_1519       dataset_937,
             dataset_2724 dataset_503,
             dataset_1369      dataset_747,
             dataset_2425      dataset_256,
             dataset_342              dataset_343,
             dataset_265           dataset_2732,
             dataset_952          dataset_259,
             dataset_949                            dataset_964,
             dataset_360  dataset_104,
             dataset_2723      dataset_2726  
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_937.column_1061 = '##'
            AND dataset_937.column_1071               <> '###'
            AND dataset_256.column_3619 = dataset_937.column_148          
            AND dataset_503.column_148 = dataset_256.column_3619        
            AND dataset_503.column_1065 = '######-#########-#####'
            AND dataset_503.column_76 = dataset_259.column_76 (+)
            AND dataset_503.column_76 = dataset_964.column_76     
            AND dataset_747.column_148 = dataset_937.column_148          
            AND dataset_747.column_1065 = '######-#########-####-##'
            AND dataset_2732.column_76 = dataset_503.column_76     
            AND dataset_343.column_725 = dataset_2732.column_724            
            AND  CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_2440           
                 ELSE dataset_503.column_3753             
                        END     =dataset_2726.column_591

        -- ##### ### ###### ### ####_##
        UNION ALL
        SELECT
                dataset_104.column_354                                                         AS column_354,
            '#####' || dataset_104.column_122       || '#' || dataset_503.column_1321               AS column_1117,
            '#'                                                                  AS column_2468,
            package_131.package_function_134(  
            CASE WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2400                 
                ELSE dataset_503.column_1318               
            END    ,
               CASE
                WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2401             
                ELSE dataset_503.column_1319           
            END ,  
            CASE WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2396            
                ELSE dataset_503.column_1320          
            END    ,dataset_2726.column_2344)                                               AS column_1328,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_1056,
               CASE WHEN dataset_503.column_1065   LIKE '%###%'
                   THEN '####-##: ' || dataset_259.column_2348        
                                    || ' ####### ## ' 
                                    || dataset_2733.column_2348        
                                    || ' #######'
                   ELSE '####-##: ' || dataset_259.column_2348        
                                    || ' ####### #### ' 
                                    || dataset_2733.column_2348        
                                    || ' #######'
            END                                                                  AS column_7075,
            dataset_503.column_148                                                        AS column_7076,
            CASE
                WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_1319           
            ELSE dataset_503.column_2401             
            END                                                                  AS column_7077,
            NULL                                                                 AS column_7079,
            NULL                                                                 AS column_7078,
            NULL                                                                 AS column_5704,
            dataset_104.column_122                                                         AS column_2329,
            TO_CHAR(dataset_503.column_749)                                                 AS column_7082,
            '#####'                                                              AS column_7083,
            dataset_503.column_562                                                              AS column_562,
            CASE
                WHEN dataset_503.column_1065   LIKE '%###%'
            THEN dataset_503.column_549
            ELSE NULL
            END                                                                  AS column_7085,
            CASE
                WHEN dataset_503.column_1065   LIKE '%###%'
            THEN dataset_503.column_549
            ELSE NULL
            END                                                                  AS column_1477,
            NULL                                                                 AS column_7086,
            NULL                                                                 AS column_7087,
            TO_CHAR(dataset_503.column_899, '##/##/####')                                 AS column_563,
            dataset_503.column_11                                                           AS column_7103,
            dataset_259.column_2348                                                       AS column_753,
            
            package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_503.column_1065,
                            argument_161            => dataset_503.column_1064,
                            argument_73             => dataset_503.column_76)        AS column_7105,
            dataset_503.column_534                                                        AS column_534,
            dataset_104.column_753                                                         AS column_7117            
        FROM 
            dataset_2724 dataset_503,
             dataset_360  dataset_104,
             dataset_952          dataset_259,
             dataset_952          dataset_2733,
             dataset_2723      dataset_2726  
        WHERE 1 = 1
        -- ##### ##### / ##########
            AND dataset_259.column_76 = dataset_503.column_76     
            AND dataset_2733.column_76 = dataset_503.column_3756           
            AND dataset_503.column_1065   IN ('###-####-##','###-####-##')
            AND '#' = package_141.package_function_141
                                     ( argument_01                            =>   '#####'
                                      ,argument_660                           =>   dataset_503.column_2401
                                      ,argument_661                           =>   dataset_503.column_1319
                                      ,argument_662                           =>   dataset_503.column_1071
                                      )
            AND  CASE WHEN dataset_503.column_1065   LIKE '%###%'
                 THEN dataset_503.column_3753             
                 ELSE dataset_503.column_2440           
            END    =dataset_2726.column_591                        
            
        --###### ### ###### ### ####_##    
        UNION ALL
        SELECT
         dataset_104.column_354                                                   AS column_354,
        '#####'||dataset_104.column_122      
               ||CASE
                    WHEN dataset_503.column_1065   LIKE '%###%'
                    THEN '#'
                    ELSE '#'
                 END
               ||dataset_503.column_1321                                        AS column_1117,
        
        '#'                                                            AS column_2468,
        package_131.package_function_134(
            CASE WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2400                 
                ELSE dataset_503.column_1318               
            END    ,
               CASE
                WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2401             
                ELSE dataset_503.column_1319           
            END,  
            CASE WHEN dataset_503.column_1065   LIKE '%###%'
                THEN dataset_503.column_2396            
                ELSE dataset_503.column_1320          
            END    
            ,dataset_2726.column_2344)                                         AS column_1328,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_1056,
        CASE
            WHEN dataset_503.column_1065   LIKE '%###%'
            THEN '####-##: ######'
            ELSE '####-##: ######' 
        END                                                            AS column_7075,
        dataset_503.column_148                                                  AS column_7076,
        null                                                           AS column_7077,
        CASE
            WHEN dataset_503.column_1065   LIKE '%###%'
            THEN '######'
            ELSE '######'
        END                                                            AS column_7079,
        NULL                                                           AS column_7078,
        NULL                                                           AS column_5704,
        dataset_104.column_122                                                   AS column_2329,
        TO_CHAR(dataset_503.column_749)                                           AS column_7082,
        '#####'                                                        AS column_7083,
        dataset_503.column_562                                                        AS column_562,
        CASE
            WHEN dataset_503.column_1065   LIKE '%###%'
            THEN dataset_503.column_549
            ELSE NULL
        END                                                            AS column_7085,
        CASE
            WHEN dataset_503.column_1065   LIKE '%###%'
            THEN dataset_503.column_549
            ELSE NULL
        END                                                            AS column_1477,
        NULL                                                           AS column_7086,
        NULL                                                           AS column_7087,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_563,
        dataset_503.column_11                                                     AS column_7103,
        dataset_259.column_2348                                                 AS column_753,
        package_381.package_function_413(
                        argument_01             => '#####',
                        argument_650            => dataset_503.column_1065,
                        argument_161            => dataset_503.column_1064,
                        argument_73             => dataset_503.column_76)  AS column_7105,
        dataset_503.column_534                                                  AS column_534,
        dataset_104.column_753                                                   AS column_7117        
    FROM
        dataset_2724 dataset_503,
        dataset_952          dataset_259,
        dataset_949                            dataset_964,
        dataset_2723      dataset_2726,
        dataset_360  dataset_104
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_259.column_76 = dataset_503.column_76     
        AND dataset_964.column_76 = dataset_503.column_76     
        AND dataset_503.column_1065   IN ('###-####-##-###########',
                                 '###-####-##-###########',
                                 '###-####-##-########',
                                 '###-####-##-########'
                                 )
        AND '#' = package_141.package_function_141
                                     ( argument_01                            =>   '#####'
                                      ,argument_660                           =>   dataset_503.column_2401
                                      ,argument_661                           =>   dataset_503.column_1319
                                      ,argument_662                           =>   dataset_503.column_1071
                                      )
        AND dataset_503.column_3753=dataset_2726.column_591  
        AND dataset_503.column_749 IN (
                    SELECT
                        dataset_2734.column_749
                    FROM
                        dataset_2724 dataset_2734
                    WHERE
                        1 = 1
                        AND dataset_2734.column_1065   IN ('###-####-##', '###-####-##')
                        AND dataset_2734.column_749 IS NOT NULL
                        AND dataset_503.column_749 = dataset_2734.column_749
                    )
        AND dataset_503.column_1065   NOT IN ('###-####-##', '###-####-##')
    )
 )
ORDER BY
    column_753,
    column_1328,
    column_874,
    column_534,
    column_7105,
    column_500

