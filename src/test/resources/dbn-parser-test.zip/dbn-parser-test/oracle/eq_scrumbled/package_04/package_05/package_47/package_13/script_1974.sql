--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_##########_#####.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        #######
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_##########_#####';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_##########_##### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_02
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_2327
  FROM dataset_941@dblink_02.EQ
/


COMMIT
/
       





