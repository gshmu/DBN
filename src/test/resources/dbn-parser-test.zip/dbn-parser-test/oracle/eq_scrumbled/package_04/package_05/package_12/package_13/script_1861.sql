--### /********************************************************************
--###  #### ####   : ####_#_##_#####_#######.###.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ##### ####### (##### ##### #### ###### ### #######)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_36           
AS
    SELECT dataset_1272.column_904,
           dataset_665.column_17703,
           dataset_665.column_17704,
           dataset_665.column_17705,
           dataset_1272.column_17706,
           dataset_1272.column_17707,
           dataset_1272.column_17708,
           dataset_46.column_17709,
           dataset_46.column_17710,
           dataset_46.column_17711    AS column_17712,
           dataset_271.column_17711    AS column_17713,
           dataset_6604.column_5451,
           dataset_6604.column_17714,
           dataset_6604.column_17715,
           dataset_3359.column_17716,
           dataset_3359.column_17717                
      FROM dataset_6605   dataset_1272
           INNER JOIN dataset_6606  dataset_665 ON dataset_665.column_17718 = dataset_1272.column_17718 
            LEFT JOIN dataset_6607           dataset_271 ON dataset_271.column_17718 = dataset_665.column_17718 
            LEFT JOIN dataset_6608                  dataset_46 ON dataset_46.column_17719 = dataset_271.column_17720      
            LEFT JOIN dataset_6609               dataset_6604
                   ON dataset_6604.column_904 = dataset_1272.column_904    
                  AND dataset_6604.column_17721 = dataset_271.column_17721          
            LEFT JOIN dataset_6610                dataset_3359 ON dataset_3359.column_17722 = dataset_6604.column_17722              




