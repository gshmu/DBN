create or replace PACKAGE   package_809           
    AUTHID CURRENT_USER
IS
    -- %#####(#### ##### #### ## #### ####### ### #### ##########)
    -- %###########(######## ## ####### ## ####### ###########)

    -- %####(####### #### ## ### ## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2119;

    -- %####(####### #### ## ### ###-## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2120;


    -- %####(####### #### #### ### ## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2121;


    -- %####(####### #### #### ### ###-## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2122;
    
    -- %####(####### #### ## ### ## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2123;
    
    -- %####(####### #### ## ### ###-## ##### #######)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2124;
    
    -- %####(####### #### #### ### ## ##### #######  ####### + ## -)
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2125;
    
    -- %####(####### #### #### ###  ####### ## ##### ###### (##### ##### #### #### ##))
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2126;
    
    -- %####(####### #### #### ### ## ##### ####### (##### ##### ###### #### ####### #####))
    -- %###########(########_#####_######_#)
    PROCEDURE procedure_2127;
    
    -- %####(####### #### #### ### ## ##### ####### (##### ###### #### ###-## #### ####))
    -- %###########(########_#####_######_##)
    PROCEDURE procedure_2128;

END package_809;
/

create or replace PACKAGE  BODY package_809           
IS
--
any_26     PLS_INTEGER :=0;
--
    FUNCTION function_2846(
                      argument_647      IN  schema_111.dataset_766%TYPE
                     ,argument_54       IN  schema_111.dataset_914%TYPE
    )
    RETURN PLS_INTEGER
    IS
       any_4187                           PLS_INTEGER :=0;
       any_1272                           schema_111.dataset_05%TYPE;
       any_11425                          schema_111.dataset_765%TYPE;
    BEGIN
        SELECT column_07      
          INTO any_1272        
          FROM dataset_746         dataset_745
          WHERE  NOT EXISTS  (SELECT 1
                                FROM  dataset_381              
                               WHERE 1=1 
                                 AND column_07 = dataset_745.column_07     
                                 AND column_221 = '#####_##_#######' 
                                 AND column_176 = '#####_##_#######'
                                 AND column_812 = '#'
                             )
          ORDER BY column_204 DESC
          FETCH FIRST ROW ONLY;
          
        SELECT column_1323  
          INTO any_11425     
          FROM dataset_564  
         WHERE column_1322 ='#####'
           AND ROWNUM=1;
        --####_######.###_####('#_###########_##: '|| #_###########_## || '   #_#######_####: '|| #_#######_#### );
        package_810.method_4188
              (argument_01            => '#####'
              ,argument_05            => column_3430
              ,argument_646           => column_14073
              ,argument_2086             => '#/#'
              ,argument_647           => column_11015
              ,argument_54            => column_3359
              );
        
       --###########
         SELECT COUNT(*)
           INTO any_4187        
           FROM  dataset_381              
          WHERE 1=1 
            AND column_07 = column_3430     
            AND column_221 = '#####_##_#######' 
            AND column_176 = '#####_##_#######'
            AND column_812 = '#'
        ;             

       -- #######.##.######(#).##_##### (#_########_#####);  
       RETURN column_8439;
    
    END function_2846;
    
------------------------------------------------
    
    PROCEDURE procedure_2119         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '#-#####-#####'
                    ,argument_54            => '##'
                );
     schema_442.package_428.method_2199(1).any_4188 (column_48); 
    
    END function_2847;
    ---
    PROCEDURE procedure_2120         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '##-#####-#####'
                    ,argument_54            => '##'
                );
     schema_442.package_428.method_2199(1).any_4188 (column_48); 
    
    END function_2848;  

    ---
    PROCEDURE procedure_2121         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '+#-#####-#####'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(1).any_4188 (column_48); 
    
    END function_2849;
    
    ---
    PROCEDURE procedure_2122         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '## ##### ####'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(0).any_4188 (column_48); 
    
    END function_2850;
    
    ---
    PROCEDURE procedure_2123         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '+#-#####-#####'
                    ,argument_54            => '##'
                );
     schema_442.package_428.method_2199(0).any_4188 (column_48); 
    
    END function_2851;
    
    ---
    PROCEDURE procedure_2124         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '+##-#####-####'
                    ,argument_54            => '##'
                );
     schema_442.package_428.method_2199(0).any_4188 (column_48); 
    
    END function_2852;
    
        ---
    PROCEDURE procedure_2125         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '###########'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(1).any_4188 (column_48); 
    
    END function_2853;
    
        ---
    PROCEDURE procedure_2126         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '+#-#####-######'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(0).any_4188 (column_48); 
    
    END function_2854;
    
        ---
    PROCEDURE procedure_2127         
    IS
    BEGIN
     method_59 := package_function_1017(
                     argument_647           => '####-#####-#####'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(1).any_4188 (column_48); 
    
    END function_2855;
    
        ---
    PROCEDURE procedure_2128          
    IS
      any_11426          schema_709.dataset_5333%TYPE; 
    BEGIN
     SELECT column_14074
       INTO any_11426  
       FROM dataset_5334            
      WHERE column_14074 > 100
        AND ROWNUM=1;
     method_59 := package_function_1017(
                     argument_647           => '+#-'|| column_14075 ||'-#######'
                    ,argument_54            => NULL
                );
     schema_442.package_428.method_2199(0).any_4188 (column_48); 
    
    END function_2856;
    
END package_809;
/