 /*  ### #### #######
        ####### #######:
      ####### ##
      ##.##.####   ########   ###-##### : ### #### ####### ##### ########
      ##.##.####   ########   ###-##### : #######_########### #####
	  ##.##.####   ########   ###-##### : ########## ####### ### #### #######
      ####### ##
      ##.##.####   ########   ###-##### :## ### ####### ##### ####### ### ##### #### ####### ########
*/
    SELECT dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714) AS column_6557,
  dataset_333.column_6383,
  dataset_333.column_6558,
  dataset_333.column_24467,
  dataset_333.column_6555,
  dataset_333.column_714,
  dataset_333.column_1446,
  dataset_333.column_6576,
  dataset_333.column_5253,
  dataset_333.column_4129,
  dataset_333.column_6620,
  dataset_333.column_6623,
  dataset_333.column_5518,
  SUM (column_6087)                                                  AS column_6087,
  SUM (dataset_333.column_6087 * dataset_333.column_6561 * dataset_333.column_6562) AS column_5007,
  SUM(column_2726)                                        AS column_2726,
  SUM(column_4132)                                      AS column_4132,
  MAX(dataset_333.column_6577) column_6577,
  dataset_333.column_76,
  dataset_333.column_962,
  dataset_333.column_3154          
  FROM
  (SELECT '####' column_714,
    DECODE(dataset_461.column_6384,
    '######_####', dataset_1981.column_4126,
    '####', dataset_1981.column_598,
    '#############_####', dataset_1981.column_598 || dataset_1981.column_3120,
    '#############', dataset_1981.column_451
    ) column_6383,
    DECODE(dataset_461.column_6384,
    '######_####', NVL(dataset_2538.column_742, dataset_1981.column_4126),
    '####', NVL(dataset_1981.column_4127, dataset_1981.column_598),
    '#############_####', NVL(dataset_2539.column_742, NVL(dataset_1981.column_4127, dataset_1981.column_598) || ' ' || dataset_1981.column_3120),
    '#############',  dataset_1981.column_5252
    ) column_6558,
    DECODE(column_6384,
    '######_####', dataset_2538.column_500,
    '####', dataset_1981.column_6637,
    '#############_####', dataset_1981.column_3120,
    '#############', dataset_1981.column_3120
    ) column_24467,
    dataset_1981.column_1446,
    dataset_1981.column_6381            AS column_6562,
    dataset_1981.column_4129,
    dataset_1981.column_604         AS column_6576,
    dataset_1981.column_4134        AS column_6577,
    CASE
      WHEN dataset_1981.column_986 = '######'
      THEN GREATEST ( dataset_1981.column_4129 - dataset_1981.column_4128, 0)
      ELSE dataset_1981.column_4129  
    END AS column_6561,
    CASE
      WHEN dataset_1981.column_2726 - dataset_1981.column_2725 = 0
      THEN NVL2(dataset_1981.column_6375, '###_####','###')
      ELSE
        /*### ###, ###-######## ### ###### ######*/
        '######'
    END AS column_6555,
    dataset_1981.column_2726 - dataset_1981.column_2725        AS column_6087,
    dataset_1981.column_2726,
    dataset_1981.column_4132,
    dataset_1981.column_5253,
    dataset_1981.column_6620,
    ROUND(((dataset_1981.column_4129 / DECODE(dataset_2540.column_2662,0,NULL,dataset_2540.column_2662)) * 100 - 100),2) column_6623,
    dataset_1981.column_5518,
    dataset_1981.column_76,
    dataset_259.column_962,
    dataset_460.column_3154          
  FROM dataset_1634                  dataset_1981,
    dataset_2483      dataset_2484,
    dataset_2485 dataset_461,
    dataset_2544        dataset_2539,
    dataset_269 dataset_2538,
    (SELECT /*+ ###_####(#### ###_###) ##_####_#### */ dataset_1982.column_11,
      dataset_1982.column_2662,
      dataset_1982.column_3064
    FROM dataset_1266        dataset_1982
    WHERE 1            =1
    AND dataset_1982.column_2736 = '#####'
    AND dataset_1982.column_3064 =
      (SELECT MAX(column_3064)
      FROM dataset_1266        dataset_2545
      WHERE dataset_2545.column_11  = dataset_1982.column_11
      AND dataset_1982.column_2736  = dataset_2545.column_2736
      AND dataset_2545.column_3064 < TRUNC(SYSDATE,'####')
      )
    ) dataset_2540,
    dataset_260      dataset_259,
    dataset_459                    dataset_460
  WHERE dataset_1981.column_07                                 = 
  AND dataset_2484.column_598                                              = dataset_1981.column_598
  AND NVL (dataset_2484.column_714, dataset_1981.column_714)             = dataset_1981.column_714  
  AND NVL (dataset_2484.column_1446, dataset_1981.column_1446) = dataset_1981.column_1446       
  AND dataset_2484.column_3118                                    = 
  AND dataset_461.column_3118                                     = dataset_2484.column_3118   
  AND dataset_461.column_3119                                       != '########'
  AND dataset_1981.column_598                                             = dataset_2539.column_598
  AND dataset_1981.column_3120                               = dataset_2539.column_3120       
  AND dataset_1981.column_4126                                      = dataset_2538.column_598 (+)
  AND dataset_1981.column_11                                          = dataset_2540.column_11 (+)
  AND ( (dataset_461.column_6385                        = '#'
  AND dataset_1981.column_2726 - dataset_1981.column_2725   = 0)
  OR (dataset_1981.column_2726 - dataset_1981.column_2725   > 0) )
  AND dataset_1981.column_76 = dataset_259.column_76     
  AND dataset_1981.column_451 = dataset_460.column_451(+)
  AND dataset_1981.column_11 = dataset_460.column_11(+)
  AND dataset_1981.column_3063 = dataset_460.column_3063(+)
  )dataset_333
GROUP BY dataset_333.column_6383,
  dataset_333.column_6558,
  dataset_333.column_24467,
  dataset_333.column_6555,
  dataset_333.column_714,
  dataset_333.column_1446,
  dataset_333.column_6576,
  dataset_333.column_5253,
  dataset_333.column_4129,
  dataset_333.column_6620,
  dataset_333.column_6623,
  dataset_333.column_5518,
  dataset_333.column_76,
  dataset_333.column_962,
  dataset_333.column_3154          
ORDER BY column_24467,
  column_6558,
  column_6555,
  column_714,
  column_1446       