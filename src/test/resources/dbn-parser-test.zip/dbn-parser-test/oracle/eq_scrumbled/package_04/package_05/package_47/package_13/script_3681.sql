--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_####_#########_####.###
--###
--###  ####### ####        ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        ########
--###  ##.#.#  ##.##.####  ########        ####### ##### ## ### #####
--###  ##.#.#  ##.##.####  ########        ####### ##### ## ### #####
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_####_#########_####';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_####_#########_#### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_06   
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_6873
      ,column_6874
      ,column_6875
      ,column_6876
      ,column_6877
      ,column_6878
      ,column_6879
      ,column_6880
      ,column_6881
      ,column_6882
      ,column_6883
      ,column_6884
      ,column_961
      ,column_6885
      ,column_2171
      ,column_6886
      ,column_962
      ,column_6887
      ,column_6888
      ,column_6889
      ,column_6890
      ,column_6891
      ,column_6892
      ,column_963
      ,column_6893
      ,column_6894
      ,column_4142
      ,column_964
      ,column_6758
      ,column_6895
      ,column_6896
      ,column_6897
      ,column_6898
      ,column_6899
      ,column_6900
      ,column_976
      ,column_977
  FROM dataset_1363@dblink_02.EQ
/

COMMIT
/

COMMENT ON MATERIALIZED VIEW materialized_view_06    IS '######## ##### ### ######## ###_#######.###_####_#########_####'
/

CREATE INDEX index_30                  
  ON table_249 (UPPER(column_962))
  TABLESPACE tablespace_03
/

CREATE INDEX index_31                     
  ON table_249 (column_964)
  TABLESPACE tablespace_03
/
  
CREATE INDEX index_32                     
  ON table_249 (UPPER(column_2171))
  TABLESPACE tablespace_03
/

CREATE INDEX index_33                     
  ON table_249 (UPPER(column_963))
  TABLESPACE tablespace_03
/

CREATE INDEX index_34                     
  ON table_249 (column_961)
  TABLESPACE tablespace_03
/

CREATE INDEX index_35                     
  ON table_249 (UPPER(column_6889))
  TABLESPACE tablespace_03
/

CREATE INDEX index_36                     
  ON table_249 (UPPER(column_6894))
  TABLESPACE tablespace_03
/
  





