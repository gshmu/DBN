SELECT /*######## ######## */
                    CASE
     WHEN column_8210 = '##########' THEN
                            dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, dataset_333.column_1446)
                     WHEN column_3119 = '####' THEN
                            dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714,CASE WHEN dataset_333.column_714   != '#######' THEN dataset_333.column_1446        END, column_6556)
     WHEN column_3119 = '####' THEN
                           row_number() over (order by dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, CASE WHEN dataset_333.column_714   != '#######' THEN dataset_333.column_1446        END)
                                   WHEN column_3119 = '###' THEN
                            dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, dataset_333.column_6596)
     WHEN column_3119 = '##_####' THEN
                            dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, dataset_333.column_6596)
     ELSE
                          dense_rank() over (ORDER By dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, CASE WHEN dataset_333.column_714   != '#######' THEN dataset_333.column_1446        END)
                    END as column_6557,
                     dataset_333.column_6383,
                     dataset_333.column_500,
                     dataset_333.column_6558,
                     dataset_333.column_6555,
     dataset_333.column_2055,
                     dataset_333.column_714,
                     dataset_333.column_1446,
                     DECODE(dataset_333.column_6556, '######',NULL,dataset_333.column_6556) column_6556,
                     dataset_333.column_3119,
     dataset_333.column_8210,
                     NVL(dataset_333.column_6559, dataset_333.column_714) as column_6560,
                     dataset_333.column_2721,
                     dataset_333.column_3759,
                     TRUNC(dataset_333.column_2560) column_2560,
                     dataset_333.column_3063,
                     dataset_333.column_2723,
                     dataset_333.column_5500,
                     dataset_333.column_5245,
                     CASE WHEN dataset_333.column_6555 = '######_####' THEN
                     package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                     ELSE
                     dataset_333.column_6087 END AS column_6087,
                     CASE WHEN dataset_333.column_6555 = '######_####' THEN
                     package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                     ELSE
                     dataset_333.column_6087 END * dataset_333.column_6561 * dataset_333.column_6562        
                        AS column_5007,
                     dataset_333.column_6563,
                     dataset_333.column_6563 * dataset_333.column_2723  AS column_23655,
                     dataset_333.column_6565 * dataset_333.column_2723  AS column_23656,
                     dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562        
                        AS column_6564,
                     dataset_333.column_6565,
                     dataset_333.column_6565 * dataset_333.column_6561 * dataset_333.column_6562        
                        AS column_6566,
                     CASE
                        WHEN dataset_333.column_6377 = '#'
                        THEN NVL(dataset_333.column_6567, 100)
                        END 
                        AS column_6567,
                     CASE
                        WHEN dataset_333.column_6377 = '#'
                        THEN
                         package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                        END
                        AS column_6570,
                       CASE
                          WHEN dataset_333.column_6377 = '#'
                          THEN
                           package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                       END
                     * dataset_333.column_6561
                     * dataset_333.column_6562        
                        AS column_6571,
                     dataset_333.column_6572,
                      CASE
                        WHEN dataset_333.column_6377 = '#'
                         AND dataset_333.column_6573         IS NOT NULL
                        THEN
                            package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6573,dataset_333.column_11)
                        END
                        AS column_6574,
                       CASE
                          WHEN dataset_333.column_6377 = '#'
                            AND dataset_333.column_6573         IS NOT NULL
                          THEN
                           package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6573,dataset_333.column_11)
                        END
                     * dataset_333.column_6561
                     * dataset_333.column_6562        
                        AS column_6575,
                     dataset_333.column_6576,
                     dataset_333.column_6577,
                     dataset_333.column_4127,
                     dataset_333.column_5253,
                     dataset_333.column_5252,
                     dataset_333.column_644,
                     dataset_333.column_2729,
                     dataset_333.column_2728,
                     CASE WHEN dataset_333.column_6563 > 0 AND dataset_333.column_6555 = '#####' THEN
                      '#'
                     ELSE '#'
                     END AS column_6578,
                     dataset_333.column_708,
                     dataset_333.column_2710,
                     dataset_333.column_5569,
                     dataset_333.column_5284,
                     dataset_333.column_6579,
                     dataset_333.column_6579 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6580,
                     dataset_333.column_6581,
                     dataset_333.column_6581 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6582,
                     dataset_333.column_6583,
                     dataset_333.column_6583 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6584,
                     dataset_333.column_6585,
                     dataset_333.column_6585 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6586,
                     dataset_333.column_6587,
                     dataset_333.column_6587 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6588,
                     dataset_333.column_6589,
                     dataset_333.column_6589 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6590,
                     dataset_333.column_6563 * dataset_333.column_5245 * dataset_333.column_6562         column_6591,
                     dataset_333.column_6563 * dataset_333.column_2723 * dataset_333.column_6562         column_6592,
                     dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562         column_6593,
                     dataset_333.column_6565 * dataset_333.column_6561 * dataset_333.column_6562         column_6594,
                     DECODE(dataset_333.column_6555, '#####', dataset_333.column_6563, '######', dataset_333.column_6565, NULL) * GREATEST(dataset_333.column_5245, 0) * dataset_333.column_6562         column_6595,
                     dataset_333.column_2985,
                     DECODE(dataset_333.column_6596,'#',dataset_333.column_6563,NULL) AS column_6597,
                     DECODE(dataset_333.column_6596,'#',dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_6598,
                     DECODE(dataset_333.column_6596,'#',dataset_333.column_6563,NULL) AS column_6599,
                     DECODE(dataset_333.column_6596,'#',dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_6600,
                                    DECODE(dataset_333.column_3063, '#####', '####_######', '########','###########_######', '#####','#####_######','########','########_######',NULL)
                                               AS column_18144,
                                   DECODE(dataset_333.column_3063, '#####', dataset_333.column_6563,NULL) AS column_23657,
                     DECODE(dataset_333.column_3063, '#####', dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_23658,
                     DECODE(dataset_333.column_3063, '########', dataset_333.column_6563,NULL) AS column_23659,
                     DECODE(dataset_333.column_3063, '########', dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_23660,
                     DECODE(dataset_333.column_3063, '#####', dataset_333.column_6563,NULL) AS column_23661,
                     DECODE(dataset_333.column_3063, '#####', dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_23662,
                     DECODE(dataset_333.column_3063, '########', dataset_333.column_6563,NULL) AS column_23663,
                     DECODE(dataset_333.column_3063, '########', dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_23664,
                                   DECODE(dataset_333.column_3063, '########', dataset_333.column_6087 - dataset_333.column_6563, NULL) AS column_23665,
                                   DECODE(dataset_333.column_3063, '########', (dataset_333.column_6087 - dataset_333.column_6563) * dataset_333.column_6561 * dataset_333.column_6562 , NULL) AS column_23666,
                                   DECODE(dataset_333.column_3063, '########', dataset_333.column_6087 - dataset_333.column_6563, NULL) AS column_23667,
                                   DECODE(dataset_333.column_3063, '########', (dataset_333.column_6087 - dataset_333.column_6563) * dataset_333.column_6561 * dataset_333.column_6562 , NULL) AS column_23668,
                                   DECODE(dataset_333.column_3063, '#####', dataset_333.column_6087 - dataset_333.column_6563, NULL) AS column_23669,
                                   DECODE(dataset_333.column_3063, '#####', (dataset_333.column_6087 - dataset_333.column_6563) * dataset_333.column_6561 * dataset_333.column_6562 , NULL) AS column_23670,
                                   CASE WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '######' THEN dataset_333.column_6087-dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '######_####' THEN 
                                   package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '#####' THEN dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555    IN ('###','###_####') THEN dataset_333.column_708    
                                   ELSE NULL END AS column_23671,
                                   CASE WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '######' THEN dataset_333.column_6087-dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '######_####' THEN 
                                   package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555 = '#####' THEN dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '########_########' AND dataset_333.column_6555    IN ('###','###_####') THEN 0
                                   ELSE NULL END * dataset_333.column_6561 * dataset_333.column_6562         AS column_23672,
                                   CASE WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '######' THEN dataset_333.column_6087-dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '######_####' THEN 
                                   package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '#####' THEN dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555    IN ('###','###_####') THEN dataset_333.column_708    
                                   ELSE NULL END AS column_23673,
                                   CASE WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '######' THEN dataset_333.column_6087-dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '######_####' THEN 
                                   package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11)
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555 = '#####' THEN dataset_333.column_6563
                                   WHEN dataset_333.column_3063 = '#####' AND dataset_333.column_6555    IN ('###','###_####') THEN 0
                                   ELSE NULL END * dataset_333.column_6561 * dataset_333.column_6562         AS column_23674,
                     DECODE(dataset_333.column_3063, '#####', dataset_333.column_6087 - dataset_333.column_6563, NULL) AS column_23675,
                                   DECODE(dataset_333.column_3063, '#####', (dataset_333.column_6087 - dataset_333.column_6563) * dataset_333.column_6561 * dataset_333.column_6562 , NULL) AS column_23676,
                     dataset_333.column_6596,
                                   dataset_333.column_2726,
                     dataset_333.column_4132,
                     dataset_333.column_6601,
                     DECODE(dataset_333.column_6602,0,NULL,dataset_333.column_6602)AS column_6602,
                                    DECODE(dataset_333.column_23677,0,NULL,dataset_333.column_23677)AS column_23677,
                     DECODE(dataset_333.column_6603,0,NULL,dataset_333.column_6603)AS column_6603,
                     DECODE(dataset_333.column_6603,0,NULL,dataset_333.column_6603)AS column_6604, -- ### ######### ####### #####, ## #### # ######### #####
                     DECODE(dataset_333.column_6204,0,NULL,dataset_333.column_6204) AS column_6204,
                     DECODE(dataset_333.column_6605,0,NULL,dataset_333.column_6605) AS column_6605,
                     DECODE(dataset_333.column_6606,0,NULL,dataset_333.column_6606) AS column_6606,
                     DECODE(dataset_333.column_6607,0,NULL,dataset_333.column_6607) AS column_6607,
                     DECODE(dataset_333.column_6601 * dataset_333.column_6561,0,NULL,dataset_333.column_6601 * dataset_333.column_6561) AS  column_6608,
                     DECODE(dataset_333.column_6602 * dataset_333.column_6561,0,NULL,dataset_333.column_6602 * dataset_333.column_6561) AS column_6609,
                     DECODE(dataset_333.column_6603 * dataset_333.column_6561,0,NULL,dataset_333.column_6603 * dataset_333.column_6561) AS column_6610,
                     DECODE(dataset_333.column_6204 * dataset_333.column_6561,0,NULL,dataset_333.column_6204 * dataset_333.column_6561) AS column_6611,
                     dataset_333.column_6612,
                     dataset_333.column_6612 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6613,
                     dataset_333.column_6614                column_6615,
                     dataset_333.column_6614 * dataset_333.column_6561 * dataset_333.column_6562         AS column_6616,
                     dataset_333.column_6617,
                     DECODE(dataset_333.column_6618,0,NULL,dataset_333.column_6618) AS column_6618,
                     DECODE(dataset_333.column_708 * dataset_333.column_6561,0,NULL,dataset_333.column_708 * dataset_333.column_6561) AS  column_6619,
                     dataset_333.column_4129,
                     dataset_333.column_6620,
                     dataset_333.column_6620        as column_6621,
                     dataset_333.column_6622      ||' )' as column_6622,
                     dataset_333.column_6623,
                     dataset_333.column_5518,
                                     --- ##### ######
                     DECODE(dataset_333.column_6624,'#',dataset_333.column_6563,NULL) AS column_6625,
                     DECODE(dataset_333.column_6624,'#',dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_6626,
                     DECODE(dataset_333.column_6624,'#',dataset_333.column_6563,NULL) AS column_6627,
                     DECODE(dataset_333.column_6624,'#',dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562,NULL) AS column_6628,
                     NVL(dataset_333.column_3116,dataset_333.column_2721) AS column_3116,
                     dataset_333.column_6629 + 1 AS column_6629,
                     dataset_333.column_6630,
                                   dataset_333.column_6631,
                                   dataset_333.column_76,
                                   dataset_333.column_962,
                                   dataset_333.column_6951,
                     dataset_333.column_3154,
                                   dataset_333.column_3120        as column_3120,
                            CASE WHEN dataset_333.column_3119= '###########'
                              THEN dataset_333.column_23678      
                              ELSE
                              NULL END as column_23678,
                                   CASE WHEN dataset_333.column_3119= '###########'
                              THEN dataset_333.column_12070          
                              ELSE
                              NULL END as column_12070,
                       sysdate AS column_23679,
                                               CASE WHEN  dataset_333.column_6596 = '#'
                                                           THEN dataset_333.column_23680 
                         ELSE
                                    NULL
                         END AS column_23680,
                                   CASE WHEN dataset_333.column_3063 = '########'
                        THEN dataset_333.column_23681   
                        ELSE
                        NULL
                        END AS column_23681,
                                   CASE WHEN dataset_333.column_6596 = '#'
                                                           AND dataset_333.column_3063 = '########'
                                                           AND dataset_333.column_3158 IS NOT NULL
                                                           AND dataset_333.column_3160 > dataset_333.column_6382      
                                                           AND dataset_333.column_23681    >= 0 THEN
                                                           '#######_##########'
                                               WHEN dataset_333.column_6596 = '#' THEN
                                                           '#######_############'
                                               ELSE
                                                           NULL
                                   END AS column_23682
                        ,dataset_333.column_656          

                       FROM (SELECT dataset_333.*,
                             CASE
                             WHEN dataset_333.column_6632 = '#####'
                               AND dataset_333.column_3084 = '#'
                               AND dataset_333.column_6555    IN ('###', '###_####')
                              THEN
                               '#####_###'
                              ELSE dataset_333.column_6632        
                             END AS column_714,
                             CASE
                                WHEN dataset_333.column_6377 = '#'
                                THEN
                                   dataset_333.column_6087 - dataset_333.column_6563
                             END
                                AS column_6565,
                             CASE
                                WHEN dataset_333.column_6377 = '#'
                                THEN
                                     (dataset_333.column_6087 - dataset_333.column_6563)
                                   * NVL (dataset_333.column_6567, 100)
                                   / dataset_333.column_6633    
                             END
                                AS column_6569,
                            CASE
                                WHEN dataset_333.column_6377 = '#'
                                 AND dataset_333.column_6572   IS NOT NULL
                                THEN
                                     (dataset_333.column_6087 - dataset_333.column_6563)
                                   * NVL (dataset_333.column_6572, 100)
                                   / dataset_333.column_6633    
                             END
                                AS column_6573
                          , CASE WHEN dataset_333.column_3063 = '########'
                              OR (dataset_333.column_3063 = '########' and dataset_333.column_2723 > 0) THEN
                                dataset_333.column_6087 - dataset_333.column_6563
                            END as column_6579

                          , CASE WHEN NOT (dataset_333.column_3063 = '########'
                              OR (dataset_333.column_3063 = '########' and dataset_333.column_2723 > 0)) THEN
                                dataset_333.column_6087 - dataset_333.column_6563
                            END as column_6581

                         , CASE WHEN dataset_333.column_3063 = '########'
                              OR (dataset_333.column_3063 = '########' and dataset_333.column_2723 > 0) THEN
                                dataset_333.column_6563
                            END as column_6587

                         , CASE WHEN NOT (dataset_333.column_3063 = '########'
                              OR (dataset_333.column_3063 = '########' and dataset_333.column_2723 > 0)) THEN
                                dataset_333.column_6563
                            END as column_6589

                          , CASE WHEN dataset_333.column_6563 > 0
                              AND dataset_333.column_3160           IS NOT NULL
                              AND dataset_333.column_3160 > dataset_333.column_6382      
                             THEN dataset_333.column_6563
                            END as column_6583

                          ,CASE WHEN dataset_333.column_6563 > 0
                              AND dataset_333.column_3160           IS NULL
                              OR
                              (dataset_333.column_3160           IS NOT NULL
                              AND dataset_333.column_3160           <= dataset_333.column_6382
                              )
                             THEN dataset_333.column_6563
                           END as column_6585

                          /*###### #### ### ########*/
                          ,CASE WHEN dataset_333.column_6555 = '#####' THEN
                              CASE WHEN dataset_333.column_3160           IS NULL
                                 OR TRUNC(dataset_333.column_3160) <= dataset_333.column_6382      
                                THEN '####_###_#######'
                              ELSE
                                 '#########_####_############'
                              END
                           ELSE '######'
                          END AS column_6556,

                          /* ##### ######## ######### ######## ##### ## ### ######## ###### (########## ## ##########) */
                          CASE WHEN dataset_333.column_6633     IS NOT NULL
                              THEN
                              package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6634 * 100 / dataset_333.column_6633,dataset_333.column_11)
                               ELSE dataset_333.column_6634        
                          END AS column_6601,

                          CASE WHEN dataset_333.column_6633     IS NOT NULL
                              THEN

                               package_180.package_function_394(,dataset_333.column_6568,(dataset_333.column_712 + dataset_333.column_711) * 100 / dataset_333.column_6633,dataset_333.column_11)
                               ELSE dataset_333.column_712 + dataset_333.column_711        
                          END AS column_6602,
                                               CASE WHEN dataset_333.column_6633     IS NOT NULL
                              THEN

                               package_180.package_function_394(,dataset_333.column_6568,(dataset_333.column_711) * 100 / dataset_333.column_6633,dataset_333.column_11)
                               ELSE  dataset_333.column_711        
                          END AS column_23677,


                          CASE WHEN dataset_333.column_6605 > 0
                                THEN '#######'
                              WHEN column_6204 > 0
                                THEN '###########'
                              WHEN column_6603 > 0
                                THEN
                                  CASE WHEN column_6635 > 0  -- ## #### ########### ### ########, #### ### ###### ## ########_####
                                        THEN '########_####'
                                        ELSE '########'
                                  END
                              WHEN dataset_333.column_711 > 0
                                THEN '#########'
                              WHEN dataset_333.column_712 > 0
                                THEN '#########'
                              ELSE '########'
                          END AS column_6617,

                          /* ########## ######-######## ######*/
                          CASE WHEN dataset_333.column_6633     IS NOT NULL
                              THEN
                              package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_708 * NVL(dataset_333.column_6567, 100) / dataset_333.column_6633,dataset_333.column_11)
                               ELSE NULL
                          END AS column_6612,

                          CASE WHEN dataset_333.column_6633     IS NOT NULL
                              THEN
                               package_180.package_function_394(,dataset_333.column_6636,dataset_333.column_6615,dataset_333.column_11)
                               ELSE NULL
                          END AS column_6614,
                          DECODE(dataset_333.column_6555, '#####',DECODE(dataset_333.column_3119,'###',dataset_333.column_8861,'##_####',dataset_333.column_8861,NULL), NULL) as column_6596,
          CASE WHEN dataset_333.column_6555 = '#####' AND dataset_333.column_8861 = '#' THEN
                package_363.package_function_1743(
                    ,
                    dataset_333.column_07,
                    dataset_333.column_451,
                    dataset_333.column_452
                    )    ELSE NULL
          END AS column_23680  FROM (SELECT dataset_1981.column_714   column_6632,
                                       DECODE(dataset_461.column_6384,
                                       '######_####', dataset_1981.column_4126,
                                       '####', dataset_1981.column_598,
                                       '#############_####', dataset_1981.column_598 || dataset_1981.column_3120,
                                       '#############', dataset_1981.column_451,
                       '#########_####', dataset_647.column_2055
                                       ) column_6383,
                                       DECODE(dataset_461.column_6384,
                                       '######_####', NVL(dataset_2538.column_742, dataset_1981.column_4126),
                                       '####', NVL(dataset_1981.column_4127, dataset_1981.column_598),
                                       '#############_####', NVL(dataset_2539.column_742, nvl(dataset_1981.column_4127, dataset_1981.column_598) || ' ' || dataset_1981.column_3120),
                                       '#############', NVL(dataset_86.column_742, dataset_1981.column_451),
                                                                                     '#########_####', dataset_268.column_18072
                                       ) column_6558,
                                       dataset_2538.column_500 as column_500,
                                       dataset_1981.column_1446,
                                       dataset_1981.column_6381            AS column_6562,
                                       dataset_1981.column_4128       AS column_2723,
                                       dataset_1981.column_4128       AS column_5500,
                                       dataset_1981.column_4129 - dataset_1981.column_4128       AS column_5245,
                                       dataset_1981.column_4129,
                                       dataset_1981.column_604       AS column_6576,
                                       dataset_1981.column_4134        AS column_6577,
                                       dataset_1981.column_2721,
                                       dataset_1981.column_3759,
                                       dataset_1981.column_2560,
                                       dataset_461.column_3119,
                                       dataset_461.column_6559,
                                       dataset_461.column_6384,
                       dataset_461.column_8210,
                       dataset_647.column_2055,
                                       CASE
                                          WHEN dataset_1981.column_601 in ('##_####', '##_####')
                                          THEN 
                                               greatest(dataset_1981.column_4129, dataset_1981.column_4128)
                                          WHEN dataset_1981.column_986 = '######'
                                          THEN
                                             GREATEST (
                                                dataset_1981.column_4129 - dataset_1981.column_4128,
                                                0)
                                          ELSE
                                             dataset_1981.column_4129  
                                       END
                                          AS column_6561,
                                          /* ####### ###### ## ###### ## ### ########## #### ## ### */
                                         /* + ### ########### ### ###### #### ########## #### ## ########## #### ### ### ##### */
                                        CASE

                                                                                              WHEN  dataset_461.column_3119 = '####' AND dataset_1981.column_2726- dataset_1981.column_2725=0 AND
                                                                                                          dataset_1981.column_709+ dataset_1981.column_2725 > 0 THEN
                                                                                                          '######'
                                                                                                /* ####### ###### ## ####### ## ########## ####### ### ###### ####
                                          ### #### ###### ## #### ######*/
                                                                         WHEN dataset_461.column_3119 = '####' AND (dataset_8358.column_2985   IS NOT NULL OR  (dataset_8359.column_2985   IS NOT NULL AND dataset_8359.column_1028='####_######_########') OR  (dataset_8359.column_2985   IS NOT NULL AND dataset_8359.column_1028='###_##########')) THEN
                                                             '######'
                                                                                              WHEN dataset_1981.column_6382 > dataset_1981.column_2560 AND dataset_461.column_3119 = '####' THEN
                                                   '#######'
                                                                         /* ####### ###### ## ###/###_#### #### ### ########### ######## ####### # */

                                                                                              WHEN dataset_1981.column_2726 - dataset_1981.column_2725 = 0 THEN
                                            NVL2(dataset_1981.column_6375, '###_####','###')
                                        ELSE
                                        /* ####### ###### ## ###### ## ######_#### ## ##### ####
                                          - ########## ########## #### ## ## ######
                                          - ### ########## #### ########## #### ## #### ## ##### ## ###########
                                          - ### ########## #### ########## #### ## #### ### #### ########## ######## ## ##### ## ##### */
                                           CASE WHEN dataset_1981.column_6382 < dataset_1981.column_3759     THEN
                                                        DECODE (dataset_1981.column_6377, '#', '######', '######_####')
                                                ELSE
                                                  CASE WHEN dataset_1981.column_3084 = '#' AND  = '#' THEN
                                                              DECODE (dataset_1981.column_6377, '#', '######', '######_####')
                                                       ELSE '#####'
                                                  END
                                            END
                                        END
                                        AS
                                          column_6555  /* ######### #### ###### ## ######## #### ### ########### ######## */
                                                           ,
                                       dataset_1981.column_2726 - dataset_1981.column_2725       
                                          AS column_6087,
                                       CASE
                                          WHEN  = '#' AND dataset_1981.column_3084 = '#'
                                          THEN
                                             0
                                          ELSE
                                             dataset_1981.column_2730        
                                       END AS column_6563,
                                      dataset_1981.column_6377,
                                      dataset_1981.column_6375            AS column_6633,
                                      dataset_1981.column_6376          AS column_6572,

                                      /*####### ########### ####*/
                                      CASE
                                          WHEN dataset_1981.column_6377 = '#'
                                          THEN
                                             schema_384.package_180.package_function_396 (
                                                dataset_1981.column_07,
                                                dataset_1981.column_451,
                                                dataset_1981.column_452)
                                      END
                                          AS column_6567,

                                      /*######## ##### ### ### ########### ####*/
                                      CASE WHEN dataset_1981.column_6376 < 100
                                         THEN dataset_1981.column_6379               
                                         ELSE dataset_1981.column_6380              
                                      END AS column_6636,

                                      /*######## ##### ### ####### ########### ####*/
                                      CASE WHEN
                                              (CASE WHEN dataset_1981.column_6377 = '#'
                                                  THEN
                                                     schema_384.package_180.package_function_396 (
                                                        dataset_1981.column_07,
                                                        dataset_1981.column_451,
                                                        dataset_1981.column_452)
                                              END) < 100
                                          THEN dataset_1981.column_6379               
                                          ELSE dataset_1981.column_6380              
                                      END AS column_6568,
                                      dataset_1981.column_4127,
                                      dataset_1981.column_5253,
                                      dataset_86.column_742  column_5252,
                                      dataset_1981.column_644,
                                      dataset_1981.column_2729,
                                      dataset_1981.column_2728,
                                      dataset_1981.column_708,
                                      dataset_1981.column_2710,
                                      dataset_1981.column_5569,
                                      dataset_1981.column_5284,
                                      CASE WHEN dataset_1632.column_1028 IS NOT NULL AND dataset_1981.column_3063 = '########' THEN
                                      '########_########'
                                      ELSE
                                      dataset_1981.column_3063       
                                      END AS column_3063,
                                      dataset_1981.column_3160,
                                      dataset_1981.column_6382,
                                      dataset_1981.column_2985,
                                      dataset_1981.column_3120,
                                      dataset_1981.column_6637,
                                      package_363.package_function_1499(
                                                ,
                                                dataset_1981.column_07,
                                                dataset_1981.column_451,
                                                dataset_1981.column_452
                                                ) column_8861,
                                      dataset_1981.column_2726,
                                      dataset_1981.column_712,
                                      dataset_1981.column_711,
                                      dataset_1981.column_4132,
                                      dataset_977.column_549 column_6634,
                                      dataset_666.column_6635,

                                      /* #### #### ### ########### #### ###-##### ####### ######: ########## #####, ####### ###. */
                                      CASE WHEN dataset_1981.column_2721 <= dataset_1981.column_3759    
                                            THEN dataset_1981.column_708 - (dataset_1981.column_712 + dataset_1981.column_711)
                                           ELSE null
                                      END AS column_6603,

                                      /* ##### ### #### ########### ##########, #### ### #### ### ############ */
                                      CASE WHEN dataset_1981.column_3084 = '#'
                                            THEN dataset_1981.column_709 + dataset_1981.column_2725       
                                           ELSE NULL
                                      END AS column_6204,

                                      dataset_1981.column_710       AS column_6605,

                                      /* ##### ### #### ### #### ## ##### ##### ### ### */
                                      CASE WHEN dataset_1981.column_3084 = '#'
                                            THEN dataset_666.column_6638         
                                           ELSE NULL
                                      END AS column_6606,

                                      /* ##### ### #### ### #### ##### ###, ### ########## ## #### */
                                      CASE WHEN dataset_1981.column_3084 = '#'
                                            THEN dataset_666.column_6639         
                                           ELSE NULL
                                      END AS column_6607,
                                      (dataset_1981.column_708 * NVL(dataset_1981.column_6376, 100) / dataset_1981.column_6375) column_6615,
                                      dataset_1981.column_3084,
                                      dataset_1981.column_6640              as column_6618,
                                      dataset_1981.column_6620,
                                      ROUND(((dataset_1981.column_4129 / DECODE(dataset_2540.column_2662,0,NULL,dataset_2540.column_2662)) * 100 - 100),2) column_6623,
                                      dataset_1981.column_5518,
                                                                                    -- ##### #### ######
                                      dataset_2541.column_973 AS column_3116,
                                      dataset_2541.column_6641                AS column_6629,
                                      dataset_2541.column_6642   AS column_6630,
                                      CASE WHEN (dataset_1981.column_2710='##_###' OR dataset_1981.column_601='##_###' ) AND (
                                       ((months_between(sysdate,dataset_2541.column_973))/12) > 2
                                          AND ((months_between(sysdate,dataset_2541.column_2748))/12) > 1 ) THEN
                                         '#'
                                                                                     WHEN dataset_1981.column_2710       <> '##_###' AND dataset_1981.column_601 <> '##_###' THEN
                                         '#'
                                       ELSE '#' END AS column_6624,
                                                                                     CASE WHEN dataset_1981.column_2710       <> '##_###' AND dataset_1981.column_601 <> '##_###' THEN '#' ELSE '#' END AS column_6631,
                                                                                     dataset_1981.column_76,
                                                                                    dataset_259.column_962,
                                                                                     dataset_1981.column_6951,dataset_460.column_3154,
                                                                                              dataset_2542.column_742  as column_6622,
                                                                dataset_8051.column_1028 as column_23678,
                                                                                              dataset_4561.column_1028 as column_12070,
                                        package_921.package_function_1744
                                                 ( argument_01                  => 
                                                  ,argument_05                  => dataset_1981.column_07
                                                  ,argument_1988                =>dataset_1981.column_2985
                                                  ,argument_1636                   => dataset_1981.column_3158
                                                 )
                                          AS column_23681,
                                                                                              dataset_1981.column_3158,
                        dataset_1981.column_07,
                                        dataset_1981.column_451,
                                        dataset_1981.column_452,
                        dataset_1981.column_11,
                        CASE WHEN dataset_1632.column_1028 IS NULL AND dataset_1981.column_3063 = '#####' THEN
                                      dataset_1981.column_451       || '|' || dataset_1981.column_452         
                                      ELSE
                                      dataset_1632.column_1028 
                                      END AS column_656          
                        FROM dataset_1634                  dataset_1981,
                                     (SELECT column_07,
                                             column_451,
                                             column_452,
                                             column_549
                                       FROM dataset_978                 dataset_977
                                        WHERE dataset_977.column_1064 = '##########' ) dataset_977,
                                      (WITH dataset_2543 AS
                                        (SELECT dataset_666.column_07,
                                          dataset_666.column_451,
                                          dataset_666.column_452,
                                          dataset_665.column_1064      column_6643,
                                          dataset_665.column_1064,
                                          dataset_666.column_1483,
                                          dataset_666.column_1482         
                                        FROM
                                          (SELECT column_148,
                                            DECODE(dataset_665.column_1064, '####', '####', '#####') AS column_1064     
                                          FROM dataset_667           dataset_665
                                          ) dataset_665,
                                          dataset_668                 dataset_666
                                        WHERE dataset_665.column_148 = dataset_666.column_148
                                        )
                                      SELECT *
                                      FROM dataset_2543
                                        PIVOT (
                                              SUM (column_1483) column_6644,
                                              SUM (column_1482) column_6645,
                                              COUNT(column_6643) column_6646
                                              FOR column_1064      IN (
                                                      '####' column_6647 ,
                                                      '#####' column_6648)
                                               )
                                      ) dataset_666,
                                     dataset_2483      dataset_2484,
                                     dataset_2485 dataset_461,
                                     dataset_315    dataset_86,
                                     dataset_2544        dataset_2539,
                                     dataset_269 dataset_2538,
                     dataset_646        dataset_647,
                                                                                  dataset_6746     dataset_268,
                                     (SELECT
                                        dataset_1982.column_11,
                                        dataset_1982.column_2662,
                                        dataset_1982.column_3064
                                      FROM dataset_1266        dataset_1982
                                      WHERE 1=1
                                      AND dataset_1982.column_2736 = '#####'
                                      AND dataset_1982.column_3064 =
                                        (SELECT MAX(column_3064)
                                        FROM dataset_1266        dataset_2545
                                        WHERE dataset_2545.column_11  = dataset_1982.column_11
                                        AND dataset_1982.column_2736  = dataset_2545.column_2736
                                        AND dataset_2545.column_3064 < TRUNC(SYSDATE,'####')
                                        )
                                      ) dataset_2540,
                                                                                    -- ##### ####
                                      (
                                        SELECT
                                          dataset_2546.column_2858,
                                          dataset_2547.column_2859,
                                          dataset_2547.column_973,
                                          dataset_2546.column_2748,
                                          GREATEST(dataset_2547.column_973 + INTERVAL '#' YEAR, dataset_2546.column_2748 + INTERVAL '#' YEAR)  AS column_6641,
                                          dataset_2546.column_6642  
                                       FROM
                                          dataset_1210           dataset_2546,
                                          dataset_1211           dataset_2547
                                       WHERE
                                          dataset_2547.column_2859 = dataset_2546.column_2859
                                      ) dataset_2541,
                                      --###### #### ###########
                                      (
                                      select
                                        dataset_657.column_742,
                                        dataset_275.column_11
                                        from dataset_1303 dataset_657,dataset_276 dataset_275
                                        where dataset_275.column_2955 = dataset_657.column_2955
                                      )dataset_2542,
                                                                                    dataset_260      dataset_259,dataset_459                    dataset_460,
                                                             (
                                                                                     select
                                                                                               column_1028 ,column_2985  
                                                                                               from dataset_1299         
                                                                                               where column_3466='###########_######'
                                                                                      ) dataset_8051,
                                                                                      (
                                                                                     select
                                                                                               column_1028 ,column_2985  
                                                                                               from dataset_1299         
                                                                                               where column_3466='###########_##########'
                                                                                      ) dataset_4561,
                                                                                       (
                                                                                     select
                                                                                               column_1028 ,column_2985  
                                                                                               from dataset_1299         
                                                                                               where column_3466='######_##########_##'
                                                                                      ) dataset_1632,
                                                                                     (SELECT dataset_8360.column_2985,dataset_1271.column_07       FROM dataset_2748                dataset_1271,dataset_1299          dataset_8360 where

                               dataset_8360.column_1028=dataset_1271.column_599   
                              AND dataset_1271.column_7147='#########'
                                                                                                                                  AND dataset_8360.column_3466='####_#####_##'
                             AND dataset_1271.column_1868   in ('####_######','####_##########','####_########') ) dataset_8358,
                            (  SELECT dataset_8361.column_2985,dataset_8361.column_1028  FROM
                                                                                                                                  dataset_1299          dataset_8361
                                                                                                                      WHERE
                                                                                                                                  dataset_8361.column_3466='##########_######') dataset_8359
                               WHERE     dataset_1981.column_07 =
                                     AND dataset_2484.column_598 = dataset_1981.column_598
                                     AND NVL (dataset_2484.column_714, dataset_1981.column_714) =
                                            dataset_1981.column_714  
                                     AND NVL (dataset_2484.column_1446,
                                              dataset_1981.column_1446) =
                                            dataset_1981.column_1446       
                                     AND dataset_2484.column_3118 = 
                                     AND dataset_461.column_3118 = dataset_2484.column_3118   
                                     AND dataset_461 .column_3119   != '########'
                     AND dataset_1981.column_2031 = dataset_647.column_2031         
                                                                            AND dataset_647.column_2055 = dataset_268.column_2055   
                                     AND dataset_1981.column_451 = dataset_86.column_451      
                                     AND dataset_1981.column_598 = dataset_2539.column_598
                                     AND dataset_1981.column_3120 = dataset_2539.column_3120       
                                     AND dataset_1981.column_4126 = dataset_2538.column_598 (+)
                                     AND dataset_1981.column_07 = dataset_977.column_07 (+)
                                     AND dataset_1981.column_451 = dataset_977.column_451 (+)
                                     AND dataset_1981.column_452 = dataset_977.column_452 (+)
                                     AND dataset_1981.column_07 = dataset_666.column_07 (+)
                                     AND dataset_1981.column_451 = dataset_666.column_451 (+)
                                     AND dataset_1981.column_452 = dataset_666.column_452 (+)
                                     AND dataset_1981.column_11 = dataset_2540.column_11 (+)
                                     AND (  (dataset_461.column_3119 = '####'
                                                                                                          AND (dataset_1981.column_710 > 0
                                                                                                          OR (dataset_1981.column_711>0
                                                                                                                                  AND (dataset_8358.column_2985   IS NOT NULL OR dataset_8359.column_2985   is not null))
                                                                                                          OR (dataset_1981.column_2726 - dataset_1981.column_2725=0 AND  dataset_1981.column_709 + dataset_1981.column_2725 > 0)
                                                                                                          )
                                                                                                          )
                                            OR (dataset_461.column_6385 = '#' AND dataset_1981.column_2726 - dataset_1981.column_2725 = 0)
                                            OR (dataset_1981.column_2726 - dataset_1981.column_2725 > 0)
                                          )
                     AND (CASE
                            WHEN dataset_461.column_8210           != '##########' THEN 1
                            WHEN dataset_461.column_8210 = '##########' AND dataset_1981.column_714   != '#####' THEN 1
                            ELSE 0
                          END ) = 1
                     -- ##### ####
                                     AND dataset_1981.column_2857 = dataset_2541.column_2858 (+)
                                                                                  AND dataset_1981.column_76 = dataset_259.column_76     
                                     AND dataset_1981.column_451 = dataset_460.column_451(+)
                                     AND dataset_1981.column_11 = dataset_460.column_11(+)
                                     AND dataset_1981.column_3063 = dataset_460.column_3063(+)
                                     AND dataset_1981.column_11 = dataset_2542.column_11(+)
                                      AND dataset_1981.column_2985 = dataset_8051.column_2985(+)
                                     AND dataset_1981.column_2985 = dataset_4561.column_2985(+)
                                     AND dataset_1981.column_2985 = dataset_1632.column_2985(+)
                                                                                    AND dataset_1981.column_2985 = dataset_8358.column_2985(+)
                                                                                  AND dataset_1981.column_07 = dataset_8358.column_07(+)
                                     AND dataset_1981.column_2985 = dataset_8359.column_2985(+)
                                   ) dataset_333) dataset_333
                      ORDER BY
                      DECODE(column_6384,
                       '######_####', column_500,
                       '####', column_6637,
                       '#############_####', DECODE(column_3119, '####', -column_3120, column_3120),
                       '#############', DECODE(column_3119, '####', -column_3120, column_3120),
                       '#########_####', column_2055
                       ),
                      column_6558,
                      column_6555,
                      column_6596,
                      column_714,
                      column_1446,
                      DECODE (column_3119, '####', -column_3120, column_3120),
                      column_656,
                      column_3063      