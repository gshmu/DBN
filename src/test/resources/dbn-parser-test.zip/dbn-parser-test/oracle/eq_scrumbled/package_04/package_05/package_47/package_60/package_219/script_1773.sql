/******************************************************************************
    ##### #####: #########_########_########
    #########:   #########
    ########:    #######
    ######## ######## ##### ### ####### ######
    
    #######:
      (####)                           (####)
    - #######_######_##
    - ###########_##          
    - #########_######_##     
    - ###_#######_######      
    - ###_#######_###_######  
    - ###_#######_####_###### 
    - #######_######_####     
    - ####                    
    - ########                
    - #####_####              
    - ##########_####         
    - ######_#####_####       
    - ########                
    - #####_######            
    - #####_######_######_##  
    - #####_######_#########  
    - #####_###########_####  
    - ########                
    - #######_####

    ####### ##.#
    ##.#.#    ##.##.####   ##### ######    ####### ####, ###-#####
    ##.#.#    ##.##.####   ##### ########   ### ####### ####### ######### ###-#####
*******************************************************************************/
WITH     
dataset_6462 AS (
    SELECT 
    CASE
        WHEN column_07  IS NULL THEN
            dataset_899.column_6838     
        ELSE           
            to_DATE(column_07, '##.###.#### ####:##:##')
        END  AS column_17275 
    FROM dataset_360  dataset_899
),
dataset_2723      as( SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                       FROM dataset_360  dataset_899,dataset_946  dataset_945),
    
dataset_6487 AS (
    SELECT 
        '#####'                                                AS column_1350,
        dataset_333.column_76                                         AS column_76,
        dataset_259.column_555                                          AS column_555,
        dataset_333.column_07                                            AS column_07,
        dataset_45.column_165                                           AS column_165,
        NULL                                                   AS column_560,
        (select  package_131.package_function_134(dataset_232.column_538,dataset_232.column_539,dataset_232.column_540,dataset_2726.column_2344) FROM dataset_62)    AS column_535,
        dataset_232.column_534                                         AS column_2355,
        dataset_232.column_541                                         AS column_2356,
        dataset_232.column_531                                        AS column_531,
        dataset_275.column_562                                                 AS column_562,
        dataset_275.column_604                                           AS column_532,
        dataset_86.column_598                                                AS column_558,
        dataset_333.column_3063                                          AS column_3063,
        TRUNC(dataset_899.column_17275)                                     AS column_566,
        TRUNC(dataset_899.column_17275)                                     AS column_567,
        '#'                                                    AS column_552,
        (
             dataset_333.column_708
             - dataset_333.column_709
             - dataset_333.column_711
             - dataset_333.column_712
             - dataset_333.column_710)
             
                                                            AS column_549,
        '###########'                                         AS column_565,
        dataset_333.column_2985                                       AS column_569,
        '######### #### ###########'                        AS column_568,
        '#########'                                            AS column_564,
        '######### #### ###########'                        AS column_189,
        package_381.package_function_413(
                argument_01            => '#####',
                argument_650           => '##########',
                argument_73            => dataset_259.column_76,
                argument_252           => dataset_104.column_753,
                argument_672           => dataset_232.column_534) AS column_7116 
    FROM dataset_336                   dataset_333,
         dataset_315                   dataset_86,
         dataset_269                         dataset_320,
         dataset_459                    dataset_460,
         dataset_276                      dataset_275,
         dataset_260                   dataset_259,
         dataset_674                    dataset_3243,
         dataset_233                   dataset_232,
         dataset_6462                        dataset_899,
         dataset_50                    dataset_45,
         dataset_360                   dataset_104,
         dataset_2723                  dataset_2726
    WHERE 1 = 1
        AND dataset_333.column_451 = dataset_86.column_451      
        AND dataset_86.column_598 = dataset_320.column_598
        AND dataset_460.column_451 = dataset_333.column_451      
        AND dataset_460.column_3063 = dataset_333.column_3063      
        AND dataset_460.column_11 = dataset_333.column_11
        AND dataset_333.column_11 = dataset_275.column_11
        AND dataset_333.column_07 = dataset_45.column_07     
        AND dataset_333.column_76 = dataset_259.column_76     
        AND dataset_333.column_451 = dataset_3243.column_451      
        AND dataset_333.column_07 = dataset_3243.column_07     
        AND dataset_3243.column_8429 = dataset_232.column_1327            
        AND dataset_333.column_3048 != '###_##_####'
        AND dataset_3243.column_2260 = '#####'
        AND dataset_232.column_531 = '#####'              -- ######### #####
        AND dataset_275.column_714 = '#####'
        AND dataset_460.column_3154           IN ('######', '###########')
        AND dataset_320.column_2983 = '####_#######'
        AND dataset_333.column_644   <= TRUNC(dataset_899.column_17275)
        and dataset_232.column_541=dataset_2726.column_591
        AND dataset_333.column_189 = '#########'
        AND dataset_333.column_204 >= dataset_899.column_17275
        AND   dataset_333.column_708
             - dataset_333.column_709
             - dataset_333.column_711
             - dataset_333.column_712
             - dataset_333.column_710 >
             0                                           -- #### # ###########
 UNION ALL
     SELECT 
        '#####'                                                AS column_1350,
        dataset_333.column_76                                         AS column_76,
        dataset_259.column_555                                          AS column_555,
        dataset_333.column_07                                            AS column_07,
        dataset_45.column_165                                           AS column_165,
        NULL                                                   AS column_560,
        (select  package_131.package_function_134(dataset_232.column_538,dataset_232.column_539,dataset_232.column_540,dataset_2726.column_2344) FROM dataset_62) AS column_535,
        dataset_232.column_534                                         AS column_2355,
        dataset_232.column_541                                         AS column_2356,
        dataset_232.column_531                                        AS column_531,
        dataset_275.column_562                                                 AS column_562,
        dataset_275.column_604                                           AS column_532,
        dataset_86.column_598                                                AS column_558,
        dataset_333.column_3063                                          AS column_3063,
        TRUNC(dataset_899.column_17275)                                  AS column_566,
        TRUNC(dataset_899.column_17275)                                  AS column_567,
        '#'                                                    AS column_552,
        (
             dataset_333.column_708
             - dataset_333.column_709
             - dataset_333.column_711
             - dataset_333.column_712
             - dataset_333.column_710)
             
                                                            AS column_549,
        '###########'                                         AS column_565,
        dataset_333.column_2985                                       AS column_569,
        '######### #### ###########'                        AS column_568,
        '#########'                                            AS column_564,
        '######### #### ###########'                        AS column_189,
        package_381.package_function_413(
                argument_01            => '#####',
                argument_650           => '##########',
                argument_73            => dataset_259.column_76,
                argument_252           => dataset_104.column_753,
                argument_672           => dataset_232.column_534) AS column_7116 
    FROM dataset_336                   dataset_333,
         dataset_315                   dataset_86,
         dataset_269                         dataset_320,
         dataset_459                    dataset_460,
         dataset_276                      dataset_275,
         dataset_260                   dataset_259,
         dataset_674                    dataset_3243,
         dataset_233                   dataset_232,
         dataset_6462                        dataset_899,
         dataset_50                    dataset_45,
         dataset_360                   dataset_104,
         dataset_2723                  dataset_2726
    WHERE 1 = 1
        AND dataset_333.column_451 = dataset_86.column_451      
        AND dataset_86.column_598 = dataset_320.column_598
        AND dataset_460.column_451 = dataset_333.column_451      
        AND dataset_460.column_3063 = dataset_333.column_3063      
        AND dataset_460.column_11 = dataset_333.column_11
        AND dataset_333.column_11 = dataset_275.column_11
        AND dataset_333.column_07 = dataset_45.column_07     
        AND dataset_333.column_76 = dataset_259.column_76     
        AND dataset_333.column_451 = dataset_3243.column_451      
        AND dataset_333.column_07 = dataset_3243.column_07     
        AND dataset_3243.column_8429 = dataset_232.column_1327            
        AND dataset_3243.column_2260 = '#####'
        AND dataset_232.column_531 = '#####'            
        AND dataset_275.column_714 = '###'
        AND dataset_460.column_3154           IN ('######', '###########')
        AND dataset_320.column_2983 = '####_#######'
        AND dataset_333.column_2721 <=  TRUNC(dataset_899.column_17275)  
        and dataset_232.column_541=dataset_2726.column_591
        AND dataset_333.column_189 = '#########'
        AND dataset_333.column_204 >= dataset_899.column_17275
        AND   dataset_333.column_708
             - dataset_333.column_709
             - dataset_333.column_711
             - dataset_333.column_712
             - dataset_333.column_710 >
             0  
)
    
SELECT 
    NULL as column_4785,--### ## ### ### ######_####
    dataset_45.column_555,
    dataset_45.column_07,
    dataset_45.column_165,
    dataset_45.column_560,
    dataset_45.column_535,
    dataset_45.column_2355,
    dataset_45.column_2356,
    dataset_45.column_531,
    dataset_45.column_562,
    dataset_45.column_532,
    dataset_45.column_558,
    dataset_45.column_3063,
    dataset_45.column_566,
    dataset_45.column_567,
    dataset_45.column_552,
    dataset_45.column_549,
    0 as column_6332,--### ## ### ### ######_####
    dataset_45.column_565,
    dataset_45.column_569,
    dataset_45.column_568,
    dataset_45.column_564,
    dataset_45.column_189,
    dataset_45.column_7116 
FROM
    dataset_6487 dataset_45