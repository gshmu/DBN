--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : #_########_###_######.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ### ####### (##### ############ #####)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_15                   
AS
    SELECT dataset_647.column_2031,
           dataset_647.column_1443,
           dataset_647.column_2057,
           dataset_647.column_742 
      FROM dataset_646        dataset_647
     WHERE dataset_647.column_1443 = '#####'
     UNION ALL
     SELECT dataset_649.column_2031,
            dataset_649.column_1443,
            dataset_649.column_2057,
            dataset_649.column_742 
       FROM dataset_648                  dataset_649
      WHERE dataset_649.column_73        IS NULL
        AND dataset_649.column_1443 = '#####'
        AND NOT EXISTS (SELECT NULL
                          FROM dataset_646        dataset_1327
                         WHERE dataset_1327.column_2031 = dataset_649.column_2031         
                           AND dataset_1327.column_1443 = '#####')
/
