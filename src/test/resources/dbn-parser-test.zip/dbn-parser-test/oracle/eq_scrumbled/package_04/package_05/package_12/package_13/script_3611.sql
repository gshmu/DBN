--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   :####_#_###########_####_####_######.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.# ##.##.####  ###########       ####
--###  ##.#.# ##.##.####  ###########       #### ### : ####
--###  ####### ##.#
--###  ##.#.# ##.##.####  ###########       #### ### : ####
--###  ##.#.# ##.##.####  ###########       #### ###### #### ###### #### ####  
--###  ####### ##
--###  ##.#.# ##-##-####  ###########       ### ###;
--###  ####### ##
--###  ##.#.# ##.##.####  ########	      ###-##### - ####### ########_########## #### ########_######_######
--###  ####### ##.#
--###  ##.#.# ##.##.####  ######            ###-#####
--###  ##.#.# ##.##.####  ######            ###-#####     
--###  ##.#.# ##.##.####  #######           ###-#####   
--###  ##.#.# ##.##.####  ######            ###-#####                                
--### *********************************************************************/


--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

DECLARE
    any_204       schema_138.dataset_15.column_354%TYPE;
    any_09        VARCHAR2(30) := sys_context('#######','#######_######');

BEGIN
    
    EXECUTE IMMEDIATE '##### ###### ## ###_######_####.#######_######### ## '||column_33 || ' #### ##### ######';
  
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

CREATE OR REPLACE FORCE VIEW view_79
(
   column_07,
   column_451,
   column_452,
   column_2985,
   column_599,
   column_3112,
   column_12491,
   column_5660,
   column_7136,
   column_12493,
   column_28341,
   column_1785,
   column_28342,
   column_28343,
   column_28344,
   column_3116,
   column_28345,
   column_6482,
   column_24870,
   column_28346,
   column_6779,
   column_7140
)
AS
   SELECT dataset_102.column_07,
          dataset_102.column_451,
          dataset_102.column_452,
          dataset_102.column_2985,
          dataset_1300.column_1028 AS column_599,
          dataset_102.column_708     AS column_3112,
          dataset_102.column_2681 AS column_12491,
          (SELECT dataset_1643.column_10
             FROM dataset_1642                 dataset_1643
            WHERE     dataset_1643.column_599 = dataset_1300.column_1028
                  AND dataset_102.column_07 = dataset_1643.column_07     
                  AND ROWNUM = 1)
             AS column_5660,
          (SELECT dataset_790.column_6166
             FROM dataset_791              dataset_790
            WHERE     dataset_790.column_07 = dataset_102.column_07     
                  AND dataset_790.column_599 = dataset_1300.column_1028
                  AND ROWNUM = 1)
             AS column_7136,
          (SELECT NVL (SUM (dataset_318.column_4357), 0)
             FROM dataset_317                  dataset_318
            WHERE     dataset_318.column_599 = dataset_1300.column_1028
                  AND dataset_318.column_07 = dataset_102.column_07     
                  AND dataset_318.column_10 IN
                         ('####_########',
                          '#########',
                          '####_########',
                          '########',
                          '#########',
                          '####_##_##_########'))
             AS column_12493,
          (SELECT NVL (SUM (dataset_318.column_4357), 0)
             FROM dataset_317                  dataset_318
            WHERE     dataset_318.column_599 = dataset_1300.column_1028
                  AND dataset_318.column_07 = dataset_102.column_07     
                  AND dataset_318.column_10 IN
                         ('####_########',
                          '#########',
                          '####_########',
                          '########',
                          '#########',
                          '####_##_##_########')
                  AND dataset_318.column_04 =
                         '###########_############')
             AS column_28341,
          (SELECT dataset_790.column_1785          
             FROM dataset_791              dataset_790
            WHERE     dataset_790.column_07 = dataset_102.column_07     
                  AND dataset_790.column_599 = dataset_1300.column_1028
                  AND ROWNUM = 1)
             AS column_1785,
          (  (SELECT COUNT (*)
                FROM dataset_2748                dataset_1271
               WHERE     dataset_1271.column_1868 = '####_########'
                     AND column_07 = dataset_102.column_07     
                     AND column_599 = dataset_1300.column_1028)
           + (SELECT CASE
                        WHEN EXISTS
                                (SELECT 1
                                   FROM dataset_1299         
                                  WHERE     column_2985 = dataset_1300.column_2985  
                                        AND column_3466 =
                                               '###_####_####_#########')
                        THEN
                           (SELECT TO_NUMBER (column_1028)
                              FROM dataset_1299         
                             WHERE     column_2985 = dataset_1300.column_2985  
                                   AND column_3466 = '###_####_####_#########')
                        ELSE
                           0
                     END
                        AS column_1028
                FROM dataset_62))
             AS column_28342,
          (  (SELECT COUNT (*)
                FROM dataset_2748                dataset_1271
               WHERE     dataset_1271.column_1868 = '####_########'
                     AND column_07 = dataset_102.column_07     
                     AND column_7147 = '#########'
                     AND column_599 = dataset_1300.column_1028)
           + (SELECT CASE
                        WHEN EXISTS
                                (SELECT 1
                                   FROM dataset_1299         
                                  WHERE     column_2985 = dataset_1300.column_2985  
                                        AND column_3466 =
                                               '###_####_####_#########')
                        THEN
                           (SELECT TO_NUMBER (column_1028)
                              FROM dataset_1299         
                             WHERE     column_2985 = dataset_1300.column_2985  
                                   AND column_3466 = '###_####_####_#########')
                        ELSE
                           0
                     END
                        AS column_1028
                FROM dataset_62))
             AS column_28343,
          (  (SELECT COUNT (*)
                FROM dataset_2748                dataset_1271
               WHERE     dataset_1271.column_1868 = '####_########'
                     AND column_07 = dataset_102.column_07     
                     AND column_7147     IN
                            ('########', '#########', '#####')
                     AND column_599 = dataset_1300.column_1028)
           + (SELECT CASE
                        WHEN EXISTS
                                (SELECT 1
                                   FROM dataset_1299         
                                  WHERE     column_2985 = dataset_1300.column_2985  
                                        AND column_3466 =
                                               '###_####_####_#########')
                        THEN
                           (SELECT TO_NUMBER (column_1028)
                              FROM dataset_1299         
                             WHERE     column_2985 = dataset_1300.column_2985  
                                   AND column_3466 = '###_####_####_#########')
                        ELSE
                           0
                     END
                        AS column_1028
                FROM dataset_62))
             AS column_28344,
          dataset_102.column_2721 AS column_3116,
          TO_DATE (
             (SELECT dataset_1645.column_3499      
                FROM dataset_3110           dataset_1645
               WHERE     dataset_1645.column_8029 = '########_#####_####'
                     -- ### ##.#########_#### = '########'
                      AND dataset_1645.column_8027='#######'
                     AND dataset_1645.column_1284 =
                            (SELECT dataset_795.column_1284       
                               FROM dataset_794      dataset_795
                              WHERE     dataset_795.column_599 = dataset_1300.column_1028
                                    AND ROWNUM = 1)),
             '##-##-####')
             AS column_28345,
          ADD_MONTHS(dataset_102.column_3056,
          NVL(
            (SELECT COUNT (*)
                FROM dataset_2748                dataset_1271
               WHERE     dataset_1271.column_1868 = '####_########'
                     AND column_07 = dataset_102.column_07     
                     AND column_7147 = '#########'
                     AND column_599 = dataset_1300.column_1028)
           + (SELECT CASE
                        WHEN EXISTS
                                (SELECT 1
                                   FROM dataset_1299         
                                  WHERE     column_2985 = dataset_1300.column_2985  
                                        AND column_3466 =
                                               '###_####_####_#########')
                        THEN
                           (SELECT TO_NUMBER (column_1028)
                              FROM dataset_1299         
                             WHERE     column_2985 = dataset_1300.column_2985  
                                   AND column_3466 = '###_####_####_#########')
                        ELSE
                           0
                     END
                        AS column_1028
                FROM dataset_62),0)
          ) AS column_6482,
          (SELECT dataset_1645.column_3499      
             FROM dataset_3110           dataset_1645
            WHERE     dataset_1645.column_8029 =
                         CASE (SELECT dataset_790.column_6779      
                                 FROM dataset_791              dataset_790
                                WHERE     dataset_790.column_07 =
                                             dataset_102.column_07     
                                      AND dataset_790.column_599 = dataset_1300.column_1028
                                      AND ROWNUM = 1)
                            WHEN 3
                            THEN
                               '#_####_#####_##########'
                            WHEN 5
                            THEN
                               '#_####_#####_##########'
                         END
                  -- ### ##.#########_#### = '########'
                  AND dataset_1645.column_8027='#######'
                  AND dataset_1645.column_1284 =
                         (SELECT dataset_795.column_1284       
                            FROM dataset_794      dataset_795
                           WHERE     dataset_795.column_599 = dataset_1300.column_1028
                                 AND ROWNUM = 1))
             AS column_24870,
          (SELECT dataset_1645.column_3499      
             FROM dataset_3110           dataset_1645
            WHERE     dataset_1645.column_8029 = '########_####'
                  -- ### ##.#########_#### = '########'
                    AND dataset_1645.column_8027='#######'
                  AND dataset_1645.column_1284 =
                         (SELECT dataset_795.column_1284       
                            FROM dataset_794      dataset_795
                           WHERE     dataset_795.column_599 = dataset_1300.column_1028
                                 AND ROWNUM = 1))
             AS column_28346,
          (SELECT dataset_790.column_6779      
             FROM dataset_791              dataset_790
            WHERE     dataset_790.column_07 = dataset_102.column_07     
                  AND dataset_790.column_599 = dataset_1300.column_1028
                  AND ROWNUM = 1)
             AS column_6779,
             dataset_1841.column_7145           as column_7140         
     FROM dataset_336 dataset_102,
          dataset_269 dataset_45,
          dataset_315    dataset_86,
          dataset_50   dataset_45,
          dataset_1299          dataset_1300,
          dataset_270 dataset_268,
          dataset_2740      dataset_1841
    WHERE     dataset_45.column_07 = dataset_102.column_07     
          AND dataset_86.column_451 = dataset_102.column_451      
          AND dataset_45.column_598 = dataset_86.column_598
          AND dataset_45.column_601 = '##_####'
          AND dataset_102.column_2985 = dataset_1300.column_2985  
          AND dataset_1300.column_3466 = '####_#####_##'
          AND dataset_1300.column_1028 IS NOT NULL
          AND dataset_268.column_7146 = dataset_1841.column_7123        
          AND dataset_268.column_599 = dataset_1300.column_1028
/                         


COMMIT
/