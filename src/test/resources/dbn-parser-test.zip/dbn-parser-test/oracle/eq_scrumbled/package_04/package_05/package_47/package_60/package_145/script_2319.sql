/******************************************************************************
    ##### #####: #######_#####_#######
    #########:   #######_#####
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### ####### ##### ##### (####### #####)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_####                      ###### ####
        - #########                        #########
        - ########_#########               ######## #########
        - ########_#########               ######## #########
        - #############_########           ############# ########
        - ###########_####                 ########### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #######                          #######
        - ####_#####                       #### #####
        - #######_####                     ####### ####
        - ####_####_#                      #### #### #
        - ####_#####                       #### #####
        - ####_#####                       #### #####
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - ########                         ######## (& #### ####)
        - ####_###                         #### ###
        - #####_######                     ##### ######
        - ####                             ####
        - #######                          #######
        - ##########_######                ########## ######

    ###### ## ###########:  ##(####### #####)||###(#######)||<####### ##### ##>||<#########>||<##.##########_###########_##>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
*******************************************************************************/
SELECT
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_1056,
    column_7074,
    column_7075,
    column_7076,
    column_7077,
    column_7078,
    column_7079,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    column_7084,
    DECODE(SUM(column_7085), 0, NULL, SUM(column_7085)) AS column_7085,
    DECODE(SUM(column_1477), 0, NULL, SUM(column_1477)) AS column_1477,
    column_549,
    column_7086,
    column_7087,
    column_563,
    NULL AS column_7088,
    NULL AS column_7089,
    NULL AS column_7090,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    column_7103,
    NULL AS column_7104,
    column_753,
    column_562,
    column_7105,
    column_534       
FROM (
    WITH 
    dataset_949                            as (
            select /*+ ########### */ column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_360  dataset_104
                WHERE column_2345 = 
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),  
    dataset_260      AS (
        SELECT column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
            dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_946  dataset_945, dataset_360  dataset_899)
        -- ######## ######## ##### #####                    
        SELECT
        dataset_104.column_354                                                              AS column_354,
        '#####' || dataset_104.column_122       || '#' || dataset_937.column_7118                          AS column_1117,       
        '#'                                                                       AS column_2468,     
        package_131.package_function_134( 
           dataset_503.column_2400, 
           dataset_503.column_2401,
           dataset_503.column_2396
          ,dataset_2726.column_2344
        )                                                                                               AS column_1328,
        TO_CHAR(dataset_937.column_567, '##/##/####')                                    AS column_1056,
        NULL                                                                      AS column_7074,
                '### - ########## ## ######'                                       AS column_7075,
        dataset_256.column_583                                                                AS column_7076,
        dataset_343.column_3620                                                             AS column_7077,
        dataset_937.column_532                                                             AS column_7078,
        '###'                                                                     AS column_7079,
        dataset_104.column_122                                                              AS column_2329,
        dataset_256.column_583                                                              AS column_7082,
        '#####'                                                                   AS column_7083,
        NULL                                                                      AS column_874,
        NULL                                                                      AS column_7084,
        NULL                                                                      AS column_7085,
        dataset_937.column_3920                                                            AS column_1477,
        NULL                                                                      AS column_549,
        package_131.package_function_140(
                    '#####',
                     dataset_747.column_532,
                     dataset_747.column_735)                                                     AS column_7086,
        dataset_937.column_7119                                                               AS column_7087,        
        TO_CHAR(dataset_937.column_567, '##/##/####')                                   AS column_563,
        dataset_503.column_11                                                                  AS column_7103,
        dataset_259.column_2348                                                                 AS column_753,
        dataset_937.column_562                                                                   AS column_562,
        package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_503.column_1065,
                            argument_73             => dataset_503.column_76)         AS column_7105,
        dataset_503.column_534                                                                  AS column_534              
        FROM dataset_1519       dataset_937,
             dataset_563             dataset_503,
             dataset_1369      dataset_747,
             dataset_257  dataset_256,
             dataset_342              dataset_343,
             dataset_265           dataset_2732,
             dataset_260      dataset_259,
             dataset_360  dataset_104,
             dataset_2723      dataset_2726 ,
             dataset_949                             dataset_964            
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_937.column_1061 = '##'
            AND dataset_937.column_1071               <> '###'
            AND dataset_256.column_583 = dataset_937.column_148          
            AND dataset_256.column_3619         IS NULL
            AND dataset_503.column_148 = dataset_256.column_583          
            AND dataset_503.column_1065 = '######-#########-#####'
            AND dataset_747.column_148 = dataset_937.column_148          
            AND dataset_747.column_1065 = '######-#########-####-##'
            AND dataset_503.column_76 = dataset_259.column_76 (+)
            AND dataset_503.column_76 = dataset_964.column_76     
            AND dataset_2732.column_76 = dataset_503.column_76     
            AND dataset_343.column_725 = dataset_2732.column_724            
            AND 
            (            
                (SELECT nvl( package_11.package_function_04(
                                argument_01             => '#####',
                                argument_40             => '##########',
                                argument_18             => dataset_104.column_354,
                                argument_41             => dataset_343.column_3620,
                                argument_42             => '######_###########_##########'), '#') 
                FROM dataset_62) = '#'
            )
            AND  CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_2440           
                 ELSE dataset_503.column_3753             
            END    =dataset_2726.column_591
            -- ###### ###### / ####### ######
            AND dataset_104.column_354 = 
            AND dataset_503.column_204 >  
            AND dataset_503.column_204 <= 

        -- ######## ######## #####_#### #####
        UNION ALL
        SELECT
        dataset_104.column_354                                                               AS column_354,
        '#####' || dataset_104.column_122       || '#' || dataset_937.column_7118                       AS column_1117,
        '#'                                                                          AS column_2468,
        package_131.package_function_134( 
           dataset_503.column_2400, 
           dataset_503.column_2401,
           dataset_503.column_2396
          ,dataset_2726.column_2344
        )                                                                            AS column_1328,            
        TO_CHAR(dataset_937.column_567, '##/##/####')                                    AS column_1056,
        NULL                                                                      AS column_7074,
        '### - ########## ## ######'                                                 AS column_7075,
        dataset_256.column_3619                                                             AS column_7076,
        dataset_343.column_3620                                                             AS column_7077,
        dataset_937.column_532                                                             AS column_7078,
        '###'                                                                     AS column_7079,
        dataset_104.column_122                                                              AS column_2329,
        dataset_256.column_3619                                                            AS column_7082,
        '#####'                                                                   AS column_7083,
        NULL                                                                      AS column_874,
        NULL                                                                      AS column_7084,
        NULL                                                                      AS column_7085,
        dataset_937.column_3920                                                            AS column_1477,
        NULL                                                                      AS column_549,
        package_131.package_function_140(
                    '#####',
                     dataset_747.column_532,
                     dataset_747.column_735)                                                   AS column_7086,
        dataset_937.column_7119                                                             AS column_7087,  
        TO_CHAR(dataset_503.column_899, '##/##/####')                                       AS column_563,
        dataset_503.column_11                                                                  AS column_7103,
        dataset_259.column_2348                                                               AS column_753,
        dataset_937.column_562                                                                   AS column_562,
        package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_503.column_1065,
                            argument_73             => dataset_503.column_76)         AS column_7105,
        dataset_503.column_534                                                             AS column_534                   
        FROM dataset_1519       dataset_937,
             dataset_563             dataset_503,
             dataset_1369      dataset_747,
             dataset_2425      dataset_256,
             dataset_342              dataset_343,
             dataset_265           dataset_2732,
             dataset_260      dataset_259,
             dataset_360  dataset_104,
             dataset_2723      dataset_2726,
             dataset_949                            dataset_964            
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_937.column_1061 = '##'
            AND dataset_937.column_1071               <> '###'
            AND dataset_256.column_3619 = dataset_937.column_148          
            AND dataset_503.column_148 = dataset_256.column_3619        
            AND dataset_503.column_1065 = '######-#########-#####'
            AND dataset_503.column_76 = dataset_259.column_76 (+)
            AND dataset_503.column_76 = dataset_964.column_76      
            AND dataset_747.column_148 = dataset_937.column_148          
            AND dataset_747.column_1065 = '######-#########-####-##'
            AND dataset_2732.column_76 = dataset_503.column_76     
            AND dataset_343.column_725 = dataset_2732.column_724            
            AND 
            (            
                (SELECT nvl( package_11.package_function_04(
                                argument_01             => '#####',
                                argument_40             => '##########',
                                argument_18             => dataset_104.column_354,
                                argument_41             => dataset_343.column_3620,
                                argument_42             => '######_###########_##########'), '#') 
                FROM dataset_62) = '#'
            )
            AND  CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_503.column_2440           
                 ELSE dataset_503.column_3753             
                        END     =dataset_2726.column_591
            -- ###### ###### / ####### ######
            AND dataset_104.column_354 = 
            AND dataset_503.column_204 >  
            AND dataset_503.column_204 <=  )

GROUP BY
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_1056,
    column_7074,
    column_7075,
    column_7076,
    column_7077,
    column_7078,
    column_7079,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    column_7084,
    column_549,
    column_7086,
    column_7087,
    column_563,
    column_7103,
    column_753,
    column_562,
    column_7105,
    column_534       