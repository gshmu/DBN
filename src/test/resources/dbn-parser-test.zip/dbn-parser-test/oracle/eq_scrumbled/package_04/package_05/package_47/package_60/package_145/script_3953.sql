/******************************************************************************
    ##### #####: ########_#####_#######
    #########:   ########_#####
    ########:    ####### (###_#######)
    ######### #### ####### ##### ### ######## ##### ##### (####### ##### - ##### #########)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_####                      ###### ####
        - #########                        #########
        - ########_#########               ######## #########
        - ########_#########               ######## #########
        - #############_########           ############# ########
        - ###########_####                 ########### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #######                          #######
        - ####_#####                       #### #####
        - #######_####                     ####### ####
        - ####_####_#                      #### #### #
        - ####_#####                       #### #####
        - ####_#####                       #### #####
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - ########                         ######## & #### ####
        - ####_###                         #### ###
        - #####_######                     ##### ######
        - ####                             ####
        - #######                          #######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####

    ###### ## ###########:  ##(######## #####)||###(#######)||<####### ##### ##>||<#########>||<###.#########_########_########_##>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##.#
    ##.#.#      ##.##.####   ### #####    ###-##### ### ###### ######
    ##.#.#      ##.##.####   ### #####    ###-##### / ###-##### ######-#########-##### ###### ## #####
    ####### ##
    ##.#.#      ##.##.####   ### #####    ###-##### ########### #### #####
    ##.#.#      ##.##.####   ### #####    ###-##### ######## ##### (## ######)
    ##.#.#      ##.##.####   ### #####    ###-##### ###### ######## ## ### #####
    ##.#.#      ##.##.####   ### #####    ###-##### ####### #### ## ###### ########## #######
    ##.#.#      ##.##.####   ##### #####  ###-##### ###### ###### ###### #### ############# ########
    ####### ##.#
    ##.#.#      ##.##.####   ### #####    ###-##### ####### #### ### ####
    ##.#.#      ##.##.####   ##### #####  ###-##### #####-########-####: ## ## ######## #### ######## ##### ###### ########
    ##.#.#      ##.##.####   ##### #####  ###-##### #### ######### ## ## ######## #### ######## ##### ######
    ####### ##.#
    ##.#.#      ##.##.####   ##### #####  ###-#####:###### ######## ###### ### ########## #######
*******************************************************************************/
SELECT
    column_354,
    column_1117,
    column_2468,
    CASE WHEN column_7117='#############_##' THEN column_1328    ||'##'  
         ELSE column_1328            ||
         column_2329      ||'_'||
         column_753       ||
         column_7105          ||
         column_534       ||'_'||
         column_562||'_##'  
     END    AS column_1328,
    column_1056,
    NULL AS column_7074,
    column_7075,
    column_7076,
    column_7077,
    column_7078,
    NULL AS column_7079,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    NULL AS column_7084,
    DECODE(SUM(column_7085), 0, NULL, SUM(column_7085)) AS column_7085,
    DECODE(SUM(column_1477), 0, NULL, SUM(column_1477)) AS column_1477,
    column_549,
    column_7086,
    TO_CHAR(column_7087) AS column_7087,
    column_563,
    NULL AS column_7088,
    NULL AS column_7089,
    NULL AS column_7090,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    column_7103,
    NULL AS column_7104,
    column_753,
    column_562,
    column_7105,
    column_534,
    NULL AS column_7106,
    NULL AS column_7107,
    NULL AS column_7108,
    NULL AS column_7109,
    NULL AS column_7110,
    NULL AS column_7111,
    NULL AS column_7112,
    NULL AS column_7113,
    NULL AS column_7114
FROM (
    WITH dataset_260      AS (
        SELECT column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
      dataset_949                            as (
        SELECT  /*+ ########### */ dataset_950.column_76     
          FROM dataset_951                      dataset_950
              ,dataset_15 dataset_104
         WHERE column_2345 = 
           AND dataset_104.column_354 = 
           AND DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),
      dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = ),
      dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = )
    --######### ######## (### ######### #)
    SELECT
        dataset_104.column_354                                                                AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_493.column_1059                           AS column_1117,
        '#'                                                                         AS column_2468,
        package_131.package_function_134(  
            CASE WHEN dataset_495.column_1065   LIKE '%###%'
                 THEN dataset_495.column_2400                 
                 ELSE dataset_495.column_1318               
            END    ,
           CASE
                WHEN dataset_495.column_1065   LIKE '%###%'
                THEN dataset_495.column_2401             
                ELSE dataset_495.column_1319           
            END ,  
            CASE WHEN dataset_495.column_1065   LIKE '%###%'
                 THEN dataset_495.column_2396            
                 ELSE dataset_495.column_1320          
            END    ,dataset_2726.column_2344)                                                 AS column_1328,
        TO_CHAR(dataset_495.column_899, '##/##/####')                                       AS column_1056,
        DECODE(dataset_493.column_1058,'###-####-####',
        '####: ####### ## ########## - '||dataset_495.column_07,
        '###-####-####','####: ####### ## ########## - '||dataset_495.column_07,
        '###-##-####','########: ### ##### ## ####### - '||dataset_495.column_07,
        '#####-###-##-####','########: ### ##### ## ####### (#######)',
        '#####-###-####-####','####: ####### ## ########## (#######)',
        '#####-###-####-####','####: ####### ## ########## (#######)',
        '#####-###-####-####','########: ####### #### ########## (#######)',
        '###-####-####','########: ########## ## ####### '||dataset_495.column_07,
        '#####-###-####-####','########: ########## ## ####### (#######)',
        '#####-####-########','####: ######## (#######)',
        '###-####-####','########: ####### #### ##########',
        dataset_493.column_1058)                                                             AS column_7075,
        CASE
            WHEN dataset_495.column_1065   IN ('#####-####-########','#####-########-####')
            THEN TO_CHAR(dataset_493.column_148) || '#'
            ELSE TO_CHAR(dataset_493.column_1059)
        END                                                                            AS column_7076,
        CASE
            WHEN dataset_495.column_1065   LIKE '%###%'
             AND dataset_495.column_1065   != '###-####-####'
            THEN dataset_495.column_1319           
            ELSE dataset_495.column_2401             
        END                                                                         AS column_7077,
        NULL                                                                        AS column_7078,
        dataset_104.column_122                                                                AS column_2329,
        NULL                                                                         AS column_7082,
        '#####'                                                                     AS column_7083,
        NULL                                                                        AS column_874,
        CASE
            WHEN dataset_495.column_1065   LIKE '%###%' OR dataset_495.column_1065   IN ('#####-########-####')
            THEN dataset_495.column_549
            ELSE 0
        END                                                                         AS column_7085,
        CASE
            WHEN dataset_495.column_1065   LIKE '%###%' OR dataset_495.column_1065   IN ( '#####-####-########', '####-########')
            THEN dataset_495.column_549
            ELSE 0
        END                                                                         AS column_1477,
        NULL                                                                        AS column_549,
        NULL                                                                        AS column_7086,
        NULL                                                                        AS column_7087,
        TO_CHAR(dataset_495.column_899, '##/##/####')                                       AS column_563,
        dataset_495.column_11                                                                 AS column_7103,
        dataset_259.column_2348                                                              AS column_753,
        dataset_495.column_562                                                                    AS column_562,
        package_381.package_function_413(
                            argument_01             => '#####',
                            argument_650            => dataset_493.column_1058,
                            argument_73             => dataset_259.column_76,
                            argument_252            => dataset_104.column_753,
                            argument_672            => dataset_493.column_534)       AS column_7105,
        dataset_493.column_534                                                              AS column_534,
        dataset_104.column_753                                                                AS column_7117        
    FROM dataset_494                   dataset_493,
         dataset_496                 dataset_495,
         dataset_15 dataset_104,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_2723      dataset_2726  
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_493.column_354                     = dataset_104.column_354
        AND dataset_493.column_1059 = dataset_495.column_1059                   
        AND dataset_493.column_76                 = dataset_259.column_76 (+)
        AND dataset_493.column_76                 = dataset_964.column_76     
        AND dataset_493.column_1061              ='###'
        AND dataset_493.column_1058  NOT IN (
                    '######-#########-#####',
                    '###-####-##',
                    '###-####-##',
                    '###-####-####',
                    '###-####-####',
                    '###-####-####',
                    '###-####-####','###-####-####')
         AND  CASE WHEN dataset_495.column_1065   LIKE '%###%'
                 THEN dataset_495.column_3753             
                 ELSE dataset_495.column_2440           
            END    =dataset_2726.column_591            
        AND dataset_104.column_354 = dataset_2726.column_354
        -- ###### ###### / ####### ######
        AND dataset_493.column_354 = 
        AND dataset_493.column_204 >   
        AND dataset_493.column_204 <=  

    --######### ###### #### ######## (### ######### #)
    UNION ALL
    SELECT
        dataset_104.column_354                                                                AS column_354,
        '#####'||dataset_104.column_122      ||'#'
               ||dataset_493.column_1059                   
               ||ROW_NUMBER() OVER (
                    PARTITION BY dataset_1578.column_148,
                                 dataset_1578.column_567,
                                 dataset_1578.column_3917  
                        ORDER BY dataset_1578.column_567)                               AS column_1117,
        '#'                                                                         AS column_2468,
        package_131.package_function_134(  
            DECODE(dataset_493.column_1061, '###',
                  dataset_495.column_2400,
                  dataset_495.column_1318)    ,
           DECODE(dataset_493.column_1061, '###',
                        dataset_495.column_2401,
                        dataset_495.column_1319) ,  
           DECODE(dataset_493.column_1061, '###',
                  dataset_495.column_2396,
                  dataset_495.column_1320),
          dataset_2726.column_2344)                                                         AS column_1328,
        TO_CHAR(dataset_1578.column_567, '##/##/####')                                  AS column_1056,
        '### - ########## ## ######'                                                AS column_7075,
        dataset_493.column_148                                                              AS column_7076,
        dataset_1578.column_3929                                                                  AS column_7077,
        dataset_1578.column_532                                                              AS column_7078,
        dataset_104.column_122                                                                AS column_2329,
        dataset_493.column_148                                                              AS column_7082,
        '#####'                                                                     AS column_7083,
        NULL                                                                        AS column_874,
        CASE
            WHEN dataset_493.column_1061 = '##'
            THEN dataset_1578.column_3917  
            ELSE 0
        END                                                                         AS column_7085,
        CASE
            WHEN dataset_493.column_1061 = '###'
            THEN dataset_1578.column_3917  
            ELSE 0
        END                                                                         AS column_1477,
        NULL                                                                        AS column_549,
        package_131.package_function_140(
                        '#####',
                         dataset_1585.column_532 ,
                         dataset_1585.column_735 )                                               AS column_7086,
        dataset_1578.column_1479                                                             AS column_7087,
        TO_CHAR(dataset_1578.column_567, '##/##/####')                                  AS column_563,
        dataset_495.column_11                                                                 AS column_7103,
        dataset_259.column_2348                                                              AS column_753,
        dataset_1578.column_562                                                                    AS column_562,
        package_381.package_function_413(
                                argument_01             => '#####',
                                argument_650            => dataset_493.column_1058,
                                argument_73             => dataset_259.column_76,
                                argument_252            => dataset_104.column_753,
                                argument_672            => dataset_493.column_534)   AS column_7105,
        dataset_493.column_534                                                              AS column_534,
        dataset_104.column_753                                                                AS column_7117        
    FROM dataset_494                   dataset_493,
         dataset_1060          dataset_1585,
         dataset_496                 dataset_495,
         dataset_1579              dataset_1578,
         dataset_15 dataset_104,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_2723      dataset_2726  
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_493.column_354                     = dataset_104.column_354
        AND dataset_493.column_1058                   = '######-#########-#####'
        AND dataset_493.column_1059 = dataset_495.column_1059                   
        AND dataset_493.column_76                 = dataset_259.column_76 (+)
        AND dataset_493.column_76                 = dataset_964.column_76     
        AND dataset_1578.column_148           = dataset_493.column_148          
        AND dataset_1578.column_567                = dataset_495.column_899
        AND dataset_1578.column_3917                  = dataset_495.column_549
        AND dataset_1578.column_1058                   = '##########'
        AND dataset_1578.column_684               IN ('####', '####', '####')
        AND dataset_1578.column_10                         = '####'
        
        AND dataset_1585.column_1065 = '######-#########-####-##'
        AND dataset_1585.column_148 = dataset_1578.column_148          
        AND dataset_1585.column_899 = dataset_1578.column_567     
         AND  CASE WHEN dataset_493.column_1061='###'
                 THEN dataset_495.column_3753             
                 ELSE dataset_495.column_2440           
            END    =dataset_2726.column_591
        AND dataset_104.column_354 =dataset_2726.column_354
        -- ###### ###### / ####### ######
        AND dataset_493.column_354 = 
        AND dataset_493.column_204 >   
        AND dataset_493.column_204 <=  

       --###### ######## (### ######### #)
    UNION ALL
    SELECT
        dataset_104.column_354                                                                AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_4218.column_8819                          AS column_1117,
        '#'                                                                         AS column_2468,
         package_131.package_function_135(dataset_4218.column_1328,dataset_2726.column_2344,dataset_962.column_2354)     AS column_1328,
        TO_CHAR(dataset_4218.column_899, '##/##/####')                                      AS column_1056,
        DECODE(dataset_4218.column_1064,'########','###: ######## - ######',
                                     '####','###: #### - ######',
                                      dataset_4218.column_1064)                        AS column_7075,
        dataset_4218.column_4019                                                            AS column_7076,
        NULL                                                                        AS column_7077,
        dataset_4218.column_532                                                             AS column_7078,
        dataset_104.column_122                                                                AS column_2329,
        NULL                                                                        AS column_7082,
        '#####'                                                                     AS column_7083,
        dataset_4218.column_532                                                             AS column_874,
        DECODE(dataset_4218.column_552, '#', dataset_4218.column_549, NULL)                    AS column_7085,
        DECODE(dataset_4218.column_552, '#', dataset_4218.column_549, NULL)                    AS column_1477,
        NULL                                                                        AS column_549,
        TO_CHAR(dataset_4218.column_8820)                                                  AS column_7086,
        dataset_4218.column_2662                                                                  AS column_7087,
        TO_CHAR(dataset_4218.column_899, '##/##/####')                                      AS column_563,
        dataset_4218.column_532                                                             AS column_7103,
        dataset_259.column_2348                                                              AS column_753,
        dataset_4218.column_562                                                                   AS column_562,
        dataset_4218.column_189                                                               AS column_7105,
        dataset_4218.column_534                                                             AS column_534,
        dataset_104.column_753                                                                AS column_7117
    FROM dataset_3435              dataset_4218,
         dataset_15 dataset_104,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_2723      dataset_2726,
         dataset_959        dataset_962
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_4218.column_354                     = dataset_104.column_354
        AND dataset_4218.column_76                 = dataset_259.column_76 (+)
        AND dataset_4218.column_76                 = dataset_964.column_76     
        and dataset_4218.column_530=dataset_2726.column_591
        and dataset_4218.column_530=dataset_962.column_591
        and dataset_104.column_354 =dataset_2726.column_354
        and dataset_104.column_354 =dataset_962.column_354
        -- ###### ###### / ####### ######
        AND dataset_4218.column_354 = 
        AND dataset_4218.column_204 >   
        AND dataset_4218.column_204 <=  

) GROUP BY
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_1056,
    column_7075,
    column_7076,
    column_7077,
    column_7078,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    column_549,
    column_7086,
    column_7087,
    column_563,
    column_7103,
    column_753,
    column_562,
    column_7105,
    column_534,
    column_7117
    
--######/###### ######## (### ######### #)
UNION ALL
SELECT
    column_354,
    column_1117,
    column_2468,
     CASE WHEN column_7117='#############_##' THEN column_1328   ||'##'   
          ELSE column_1328           ||
         column_2329      ||'_'||
         column_753       ||
         column_7105          ||
         column_534       ||'_'||
         column_562||'_##'    
      END  AS column_1328,
    column_1056,
    NULL AS column_7074,
    column_7075,
    column_7076,
    column_7077,
    column_7078,
    column_7079,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    NULL AS column_7084,
    TO_CHAR(column_7085) AS column_7085,
    TO_CHAR(column_1477) AS column_1477,
    column_549,
    column_7086,
    TO_CHAR(column_7087) AS column_7087,
    column_563,
    NULL AS column_7088,
    NULL AS column_7089,
    NULL AS column_7090,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    column_7103,
    NULL AS column_7104,
    column_753,
    column_562,
    column_7105,
    column_534,
    NULL AS column_7106,
    NULL AS column_7107,
    NULL AS column_7108,
    NULL AS column_7109,
    NULL AS column_7110,
    NULL AS column_7111,
    NULL AS column_7112,
    NULL AS column_7113,
    NULL AS column_7114
 FROM (
    WITH
        dataset_260      AS (
            SELECT column_2346 AS column_76,
                   column_2347      AS column_2348       
              FROM dataset_954            
              WHERE column_2349 = '###_#######'
                AND column_354 = '###_#########'
                AND column_2350 = '######+'
                AND column_2351 = '###_########_######'
                AND column_221 = '#######_######'
                AND column_2352 = '*'),
        dataset_949                            as (
            SELECT  /*+ ########### */ dataset_950.column_76, dataset_950.column_14850, dataset_104.column_753  
              FROM dataset_951                      dataset_950
                  ,dataset_15 dataset_104
             WHERE column_2345 = 
               AND dataset_104.column_354 = 
               AND DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),
        dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = ),
      dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = ),
        dataset_10418         as (
            SELECT dataset_104.column_354,
                   dataset_104.column_122,
                   dataset_495.column_1065,
                   dataset_495.column_1064,
                   dataset_495.column_2400,
                   dataset_495.column_2401,
                   dataset_495.column_2396,
                   dataset_495.column_1318,
                   dataset_495.column_1319,
                   dataset_495.column_1320,
                   dataset_495.column_562,
                   dataset_495.column_11,
                   dataset_495.column_76,
                   dataset_495.column_899,
                   CASE WHEN dataset_495.column_1065   IN ('#####-###-####-####')
                   THEN dataset_495.column_549 + NVL( (SELECT DECODE(dataset_10419.column_1065,'#####-####-########',dataset_10419.column_549 ,'#####-########-####',dataset_10419.column_549*-1)
                                               FROM dataset_496                 dataset_10419 
                                              WHERE dataset_495.column_148=dataset_10419.column_148           
                                                AND dataset_10419.column_1065   IN ('#####-####-########','#####-########-####')),0)
                   ELSE dataset_495.column_549
                   END column_549,                
                   dataset_495.column_148,
                   dataset_495.column_718,
                   dataset_495.column_1321,
                   dataset_495.column_1059,
                   dataset_495.column_534,
                   dataset_495.column_07,
                   dataset_495.column_3753,
                   dataset_495.column_2440,
                   dataset_104.column_753     
              FROM dataset_494                   dataset_493,
                   dataset_496                 dataset_495,
                   dataset_15 dataset_104
             WHERE 1 = 1
               AND dataset_493.column_354 = dataset_104.column_354
               AND dataset_493.column_1059 = dataset_495.column_1059                   
               AND dataset_493.column_1058  IN (
                        '###-####-####',
                        '#####-###-####-####',
                        '###-##-####',
                        '#####-###-##-####',
                        '###-####-####',
                        '#####-###-####-####',
                        '#####-###-####-####',
                        '###-####-####',
                        '#####-###-####-####',
                        '#####-###-####-####'
)

               -- ###### ###### / ####### ######
               AND dataset_493.column_354 = 
               AND dataset_493.column_204 >   
               AND dataset_493.column_204 <=  )
    SELECT
        '#####'||dataset_503.column_122      ||'#'
               ||dataset_503.column_1321                                        AS column_1117,
        dataset_503.column_354                                                  AS column_354,
        '#'                                                            AS column_2468,
        package_131.package_function_134(dataset_503.column_2400,dataset_503.column_2401,dataset_503.column_2396,dataset_2726.column_2344)  AS column_1328,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_1056,
        DECODE(dataset_503.column_1065 ,
               '###-####-####','######: #### - '||dataset_503.column_07,
               '#####-###-####-####','######: #### - #####',
               '#####-###-####-####','######: ####### #### ########## #### (#######)',
               '#####-###-####-####','######: ####### #### ########## (#######)',
               '###-####-####','######: ####### #### ##########',
               dataset_503.column_1065)                                       AS column_7075,
        dataset_503.column_148                                                  AS column_7076,
        null                                                           AS column_7077,
        NULL                                                           AS column_7078,
        '######'                                                       AS column_7079,
        dataset_503.column_122                                                  AS column_2329,
        TO_CHAR(dataset_503.column_1059)                     AS column_7082,
        '#####'                                                        AS column_7083,
        NULL                                                           AS column_874,
        dataset_503.column_549                                                    AS column_7085,
        NULL                                                           AS column_1477,
        NULL                                                           AS column_549,
        NULL                                                           AS column_7086,
        NULL                                                           AS column_7087,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_563,
        dataset_503.column_11                                                     AS column_7103,
        dataset_259.column_2348                                                 AS column_753,
        dataset_503.column_562                                                        AS column_562,
        package_381.package_function_413(
                        argument_01             => '#####',
                        argument_650            => dataset_503.column_1065,
                        argument_73             => dataset_503.column_76,
                        argument_252            => dataset_503.column_753,
                        argument_672            => dataset_503.column_534)  AS column_7105,
        dataset_503.column_534                                                  AS column_534,
        dataset_503.column_753                                                  AS column_7117        
    FROM
        dataset_10418         dataset_503,
        dataset_260      dataset_259,
        dataset_949                            dataset_964,
        dataset_2723      dataset_2726  
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_259.column_76 = dataset_503.column_76     
        AND dataset_964.column_76 = dataset_503.column_76     
        AND dataset_503.column_1065   IN (
                    '###-####-####',
                    '#####-###-####-####',
                    '###-####-####',
                    '#####-###-####-####',
                    '#####-###-####-####')
        AND dataset_503.column_3753=dataset_2726.column_591  
        and dataset_503.column_354 =dataset_2726.column_354    
        AND NOT EXISTS (SELECT 1
                          FROM dataset_10418         dataset_10420
                         WHERE dataset_10420.column_1065   IN (
                                            '###-##-####',
                                            '#####-###-##-####')
                           AND dataset_10420.column_148 = dataset_503.column_148          
                           AND dataset_10420.column_718 = dataset_503.column_718)
   UNION ALL
    SELECT
        '#####'||dataset_104.column_122      ||'#'||dataset_4218.column_8819                          AS column_1117,
        dataset_104.column_354                                                                AS column_354,        
        '#'                                                                         AS column_2468,
        package_131.package_function_135(dataset_4218.column_1328,dataset_2726.column_2344,dataset_962.column_2354) AS column_1328,
        TO_CHAR(dataset_4218.column_899, '##/##/####')                                      AS column_1056,
        DECODE(dataset_4218.column_1064,'########','###: ######## - ######',
                                     '####','###: #### - ######',
                                     dataset_4218.column_1064)                         AS column_7075,
        dataset_4218.column_4019                                                            AS column_7076,
        NULL                                                                        AS column_7077,
        dataset_4218.column_532                                                             AS column_7078,
        '######'                                                                    AS column_7079,        
        dataset_104.column_122                                                                AS column_2329,
        NULL                                                                        AS column_7082,
        '#####'                                                                     AS column_7083,
        dataset_4218.column_532                                                             AS column_874,
        DECODE(dataset_4218.column_552, '#', dataset_4218.column_549, NULL)                    AS column_7085,
        DECODE(dataset_4218.column_552, '#', dataset_4218.column_549, NULL)                    AS column_1477,
        NULL                                                                        AS column_549,
        TO_CHAR(dataset_4218.column_8820)                                                  AS column_7086,
        dataset_4218.column_2662                                                                  AS column_7087,
        TO_CHAR(dataset_4218.column_899, '##/##/####')                                      AS column_563,
        dataset_4218.column_532                                                             AS column_7103,
        dataset_259.column_2348                                                              AS column_753,
        dataset_4218.column_562                                                                   AS column_562,
        dataset_4218.column_189                                                               AS column_7105,
        dataset_4218.column_534                                                             AS column_534,
        dataset_104.column_753                                                                AS column_7117
    FROM dataset_3435              dataset_4218,
         dataset_15 dataset_104,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_2723      dataset_2726,
         dataset_959        dataset_962
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_4218.column_354                     = dataset_104.column_354
        AND dataset_4218.column_76                 = dataset_259.column_76 (+)
        AND dataset_4218.column_76                 = dataset_964.column_76     
        and dataset_4218.column_530=dataset_2726.column_591
        and dataset_4218.column_530=dataset_962.column_591
        and dataset_104.column_354 =dataset_2726.column_354
        and dataset_104.column_354 =dataset_962.column_354
        -- ###### ###### / ####### ######
        AND dataset_4218.column_354 = 
        AND dataset_4218.column_204 >   
        AND dataset_4218.column_204 <=  
        
    --###### ######## 
    UNION ALL
    SELECT
        '#####'||dataset_503.column_122      ||'#' 
               ||dataset_503.column_1321                                        AS column_1117,
        dataset_503.column_354                                                  AS column_354,
        '#'                                                            AS column_2468,
        package_131.package_function_134(dataset_503.column_1318,dataset_503.column_1319,dataset_503.column_1320,dataset_2726.column_2344)  AS column_1328,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_1056,
         DECODE(dataset_503.column_1065 ,
         '#####-###-####-####','######: ########## ## ####### #### (#######)',
         '#####-###-####-####','######: ########## ## ####### (#######)',
         '###-####-####','######: ########## ## #######',
         dataset_503.column_1065)                                               AS column_7075,
        dataset_503.column_148                                                  AS column_7076,
        null                                                           AS column_7077,
        NULL                                                           AS column_7078,
        '######'                                                       AS column_7079,
        dataset_503.column_122                                                  AS column_2329,
        TO_CHAR(dataset_503.column_1059)                     AS column_7082,
        '#####'                                                        AS column_7083,
        NULL                                                           AS column_874,
        NULL                                                           AS column_7085,
        dataset_503.column_549                                                    AS column_1477,
        NULL                                                           AS column_549,
        NULL                                                           AS column_7086,
        NULL                                                           AS column_7087,
        TO_CHAR(dataset_503.column_899, '##/##/####')                           AS column_563,
        dataset_503.column_11                                                     AS column_7103,
        dataset_259.column_2348                                                 AS column_753,
        dataset_503.column_562                                                        AS column_562,
        package_381.package_function_413(
                        argument_01             => '#####',
                        argument_650            => dataset_503.column_1065,
                        argument_73             => dataset_503.column_76,
                        argument_252            => dataset_503.column_753)  AS column_7105,
        dataset_503.column_534                                                  AS column_534,
        dataset_503.column_753                                                  AS column_7117        
    FROM
        dataset_10418         dataset_503,
        dataset_260      dataset_259,
        dataset_949                            dataset_964,
        dataset_2723      dataset_2726  
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_259.column_76 = dataset_503.column_76     
        AND dataset_964.column_76 = dataset_503.column_76     
        AND dataset_503.column_1065   IN ( 
                    '###-####-####',
                    '#####-###-####-####',
                    '#####-###-####-####')
        AND dataset_503.column_2440=dataset_2726.column_591  
        and dataset_503.column_354 =dataset_2726.column_354
                       

)
