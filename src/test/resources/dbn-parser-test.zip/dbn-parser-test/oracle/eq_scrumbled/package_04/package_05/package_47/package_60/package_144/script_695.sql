/*
   #### ### #############
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : ######## ### #### #### #######
   ##.#.#   ##.##.####   ########   ###-#### : ############ #### ######
   ##.#.#   ##.##.####   ########   ###-#### : ###### #### #####
   ####### ##.#
   ##.#.#   ##.##.####   ########   ###-#### : ######## ######## #####
   ##.#.#   ##.##.####   ########   ###-#### : ###### #### ########### #####
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : ######## ###### ######### ######## ######
   ##.#.#   ##.##.####   ########   ###-#### : #### ##### ###########
   ####### ##
   ##.#.#   ##.##.####   ########   ###-#### : #### ##### ########### ##### ##### ###
   ####### ##
   ##.#.#   ##.##.####   ########## ###-##### : ######## ###### ### ## ####.
   ####### ##
   ##.#.#   ##.##.####   ########   ###-##### : ##### ##### ## ###### ######### ####.
  ####### ##.#
   ##.#.#    ##.##.####	 #######    ###-#####: ########### ##. ####### ######## #### #########
   */
SELECT
  column_5441,
  column_9832,
  column_6383,
  column_6558,
  column_04,
  column_10,
  column_4357,
  column_1785,
  column_738,
  column_4358,
  column_5434,
  column_2748,
 SUM(column_05) AS column_05,
  column_4264,
   SUM(column_09) AS column_09,
  column_4354,
  /*
  * ########### #### #### ### ## ###### ####### ## ### ###### ## ###.
  * ##### ###### ##### ## #### ### ######## ### #### ### ## #######.
  */
  CASE
    WHEN COUNT(DISTINCT column_599) OVER (PARTITION BY column_6383) > 1
    THEN '#'
    ELSE '#'
  END AS column_9833,
  DECODE(MAX(column_9834) OVER (PARTITION BY  column_6383), '#','#', '#') column_9835,
  DECODE(MAX(column_9836) OVER (PARTITION BY column_6383), '#','#', '#') column_9837,
  DECODE(MAX(column_9838) OVER (PARTITION BY column_6383), '#','#', '#') column_9839,
  DECODE(MAX(column_9840) OVER (PARTITION BY column_6383), '#','#', '#') column_9840               
FROM
  (
    SELECT
      NVL(dataset_318.column_5441, dataset_1172.column_2740)
      column_5441 ,
      dataset_268.column_599,
       DECODE(dataset_461.column_6384,
         '######_####', dataset_45.column_4126,
         '####', dataset_45.column_598,
         '#############_####', dataset_45.column_598 || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_598
         ) AS column_6383,
       DECODE(dataset_461.column_6384,
         '######_####', dataset_335.column_742,
         '####', dataset_45.column_742,
         '#############_####', dataset_45.column_742  || ' ' || to_char(dataset_268.column_973, '####'),
         '#############', null,
         '#########_####',dataset_45.column_742
         ) AS column_6558,
      dataset_268.column_742  column_9832,
      dataset_318.column_04,
      dataset_318.column_10 ,
      dataset_318.column_4357,
      dataset_318.column_1785,
      dataset_318.column_738 ,
      dataset_318.column_4358,
      dataset_318.column_5434 ,
      NVL( dataset_2397.column_9841, dataset_2397.column_2748) column_2748,
      dataset_1185.column_05,
      dataset_2397.column_4264,
      dataset_1185.column_09,
      dataset_2397.column_4354,
      CASE
        WHEN dataset_318.column_738 IS NOT NULL
        THEN '#'
        ELSE '#'
      END AS column_9834,
      CASE
        WHEN column_1785           != column_5434                 
        THEN '#'
        ELSE '#'
      END AS column_9836,
      CASE
        WHEN dataset_1185.column_09     IS NOT NULL
        AND dataset_1185.column_09   > 0
        THEN '#'
        ELSE '#'
      END AS column_9838,
      DECODE(dataset_461.column_3119,'##_###','#','#') column_9840,
        dataset_318.column_12      
    FROM
      dataset_317                  dataset_318
    JOIN dataset_1171           dataset_1172
    ON
      dataset_1172.column_12 = dataset_318.column_12      
    JOIN dataset_272 dataset_2397
    ON
      dataset_2397.column_08 = dataset_1172.column_08  
    JOIN dataset_270 dataset_268
    ON
      dataset_268.column_599 = dataset_1172.column_599   
    JOIN (SELECT DISTINCT column_3118,
            column_598,
            CASE
            WHEN EXISTS
            (SELECT 1
                FROM dataset_2483      dataset_3724
                WHERE dataset_3724.column_3118    = dataset_45.column_3118   
                AND dataset_45.column_598                   = dataset_3724.column_598
                AND dataset_3724.column_1446        IS NULL )
            THEN NULL
            ELSE dataset_45.column_1446       
            END AS column_1446       
          FROM dataset_2483      dataset_45) dataset_2484
    ON
      dataset_268.column_598      = dataset_2484.column_598
    AND dataset_268.column_11 = NVL( dataset_2484.column_1446, dataset_268.column_11)
    JOIN dataset_2485 dataset_461
      ON dataset_461.column_3118 = dataset_2484.column_3118   
    JOIN dataset_269 dataset_45
     ON dataset_45.column_598 = dataset_268.column_598
    JOIN dataset_269 dataset_335
     ON dataset_45.column_4126 = dataset_335.column_598
    LEFT JOIN dataset_13                   dataset_1185
    ON
      dataset_1185.column_08                  = dataset_1172.column_08  
    AND dataset_1185.column_07             = dataset_318.column_07     
    AND dataset_1185.column_04 = dataset_318.column_04                 
    AND dataset_1185.column_12            = dataset_318.column_12      
    WHERE
      dataset_318.column_07   = 
    AND dataset_2484.column_3118 = 
  )
  dataset_3725

GROUP BY
  column_5441,
  column_599,
  column_9832,
  column_6383,
  column_6558,
  column_04,
  column_10,
  column_4357,
  column_1785,
  column_738,
  column_4358,
  column_5434,
  column_2748,
  column_4264,
  column_4354,
  column_9834,
  column_9836,
  column_9838,
  column_9840,
  column_12      

ORDER BY
  dataset_3725.column_5441       DESC,
  dataset_3725.column_04                  DESC