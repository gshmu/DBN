/* #### ####### #####
    ####### ##.#
    ##.#.#  ##.##.####  ######## ###-##### : ####### #### #######_########### ######## #########
    ####### ##.#
    ##.#.#  ##.##.####  ########## ###-##### : ##_### #### ####### ######## ####### ### ########## ### ######### ### ### ### ###
    ##.#.#  ##.##.####  ########## ###-##### : ######## ########### ########## ## ######### #######.
    ####### ##.#
    ##.#.#	##.##.####	#######		###-#####:#### ####### #### ### #### #### "#### ###### ########" ### #### #### ### ########## ####### ######
    ####### ##.#
    ##.#.#  ##.##.####  ########   ###-##### : ### ### ##_### #### ####### ######## ####### ### ########## ### ######### ### ### ### ###
    ##.#.#  ##.##.####  ######      ###-##### : ####### ### #### ###### ##### ## #### ###### #######
    */
WITH
dataset_8350 AS (SELECT * FROM
                  (
                     SELECT DISTINCT dataset_2746.column_598,dataset_2746.column_7121,dataset_2746.column_973,dataset_2746.column_2746
                                FROM dataset_2483      dataset_2484,
                                     dataset_2485 dataset_461,
                                     dataset_2737                   dataset_2746 ,
                                     dataset_1634                  dataset_1981
                             where 1=1
                               AND dataset_461.column_3118 = dataset_2484.column_3118   
                               AND nvl(dataset_2484.column_714, dataset_1981.column_714) = dataset_1981.column_714  
                               AND nvl(dataset_2484.column_1446, dataset_1981.column_1446) = dataset_1981.column_1446       
                               AND dataset_2484.column_598 = dataset_1981.column_598
                               AND dataset_2746.column_598 =dataset_1981.column_598
                               AND dataset_1981.column_07=
                               AND SYSDATE BETWEEN dataset_2746.column_973 AND dataset_2746.column_2746
                    UNION ALL
                    SELECT NULL,NULL,NULL,NULL FROM dataset_62
                  )
           ORDER BY column_973 nulls last
           FETCH FIRST ROW ONLY
           )
,dataset_976 AS (
      SELECT dataset_2484.column_3118,
             dataset_1981.column_598,
             dataset_1981.column_4128,
             dataset_1981.column_3160,
             dataset_1981.column_6382,
             DECODE(dataset_461.column_6384,
                    '######_####', dataset_1981.column_4126,
                    '####', dataset_1981.column_598,
                    '#############_####', dataset_1981.column_598 || dataset_1981.column_3120,
                    '#############', dataset_1981.column_451,
                    '#########_####', dataset_647.column_2055) AS column_6383,
             dataset_1981.column_5253,
             dataset_1981.column_714,
             dataset_1981.column_1446,
             dataset_1981.column_3063       AS column_3063,
             dataset_1981.column_6381            AS column_6562,
             CASE WHEN dataset_1981.column_601 IN ('##_####', '##_####')
                  THEN GREATEST(dataset_1981.column_4129, dataset_1981.column_4128)
                  WHEN dataset_1981.column_986 = '######'
                  THEN GREATEST(dataset_1981.column_4129 - dataset_1981.column_4128, 0)
                  ELSE dataset_1981.column_4129  
             END AS column_6561,
             /* ######### #### ###### ## ######## #### ### ########### ######## */
             dataset_1981.column_2726 - dataset_1981.column_2725        AS column_6087,
             CASE WHEN  = '#' OR dataset_1981.column_3084 = '#' THEN dataset_1981.column_2730         ELSE 0 END AS column_6563,
             dataset_1981.column_6377,
             dataset_1981.column_6375            AS column_6633,
             CASE WHEN dataset_1981.column_6377 = '#'
                  THEN schema_384.package_180.package_function_396(
                                dataset_1981.column_07, dataset_1981.column_451,
                                dataset_1981.column_452)
             END AS column_6567,
             CASE WHEN dataset_1981.column_6377 = '#' THEN dataset_1981.column_6376          END AS column_6572,
             case when dataset_1981.column_6377 = '#' THEN nvl(dataset_1981.column_6376, 0) END AS column_23480,
             dataset_1981.column_6379,
             dataset_1981.column_6380,
             CASE WHEN (dataset_460.column_3145  = '##_###'
                   OR dataset_461.column_3119 = '###'
                   OR dataset_461.column_3119 =  '##_####'
                )
                THEN
                   schema_384.package_363.package_function_1499(
                      ,
                      dataset_1981.column_07,
                      dataset_1981.column_451,
                      dataset_1981.column_452)
             ELSE '#'
             END
             AS column_23481,
             dataset_461.column_6385,
             '##########' column_2646,
              -- ##_### ####
             dataset_1981.column_2710,
             dataset_1981.column_2857,
             dataset_1981.column_601,
             dataset_1981.column_11,
             dataset_2746.column_7121,
             CASE WHEN dataset_2746.column_7121=2 THEN
            (SELECT dataset_1841.column_7145           FROM dataset_2740      dataset_1841 WHERE dataset_1841.column_7123=dataset_2746.column_7124)
            ELSE dataset_1841.column_7145          
            END AS column_7145          
          FROM dataset_1634                  dataset_1981,
             dataset_2737                   dataset_2746,
             dataset_1299          dataset_1300,
             dataset_2740      dataset_1841,
             dataset_270 dataset_268,
             dataset_2483      dataset_2484,
             dataset_2485 dataset_461,
             dataset_646        dataset_647,
             dataset_459                    dataset_460,
             dataset_8350
            WHERE dataset_1981.column_07 = 
         AND dataset_461.column_3118 = dataset_2484.column_3118   
         AND dataset_2484.column_598 = dataset_1981.column_598
         AND dataset_647.column_2031 = dataset_1981.column_2031         
         AND nvl(dataset_2484.column_714, dataset_1981.column_714) = dataset_1981.column_714  
         AND nvl(dataset_2484.column_1446, dataset_1981.column_1446) = dataset_1981.column_1446       
         AND dataset_1300.column_2985 (+)= dataset_1981.column_2985  
         AND dataset_1300.column_3466 (+) = '####_#####_##'
         AND dataset_2746.column_598 (+) = dataset_1981.column_598
         AND dataset_268.column_599 (+) = dataset_1300.column_1028
         AND dataset_1841.column_7123 (+) = dataset_268.column_7146       
         AND dataset_2746.column_7121(+)=dataset_8350.column_7121                 
         AND dataset_2746.column_973(+)=dataset_8350.column_973
         AND dataset_2746.column_2746(+)=dataset_8350.column_2746
         AND dataset_2746.column_598(+)=dataset_8350.column_598
         AND dataset_1981.column_451    = dataset_460.column_451      
         AND dataset_1981.column_11             = dataset_460.column_11
         AND dataset_1981.column_3063   = dataset_460.column_3063      
   UNION ALL
      SELECT dataset_2484.column_3118,
             dataset_45.column_598,
             0 AS column_4128,
             NULL AS column_3160,
             NULL AS column_6382,
             DECODE(dataset_461.column_6384,
                    '######_####', dataset_45.column_4126,
                    '####', dataset_45.column_598,
                    '#############_####', dataset_45.column_598 || to_char(dataset_319.column_973, '####'),
                    '#############', null,
                    '#########_####', null) AS column_6383,
             NULL AS column_11,
             NULL AS column_714,
             dataset_318.column_11 column_1446,
             NULL AS column_3063,
             0 column_6562,
             0 AS column_6561,
            /* # ########## ## #### #### ## ########## ## #### #####*/
            0 AS column_6087,
            0 AS column_6563,
            '#' AS column_6377,
            1 AS column_6633,   --#### ## ########
            NULL AS column_6567,
            NULL AS column_6572,
            NULL AS column_23480,
            NULL AS column_6379,
            NULL AS column_6380,
            '#' AS column_23481,
            dataset_461.column_6385,
            '############' column_2646,
            -- ##_### ####
            NULL AS column_2710,
            NULL AS column_2857,
            NULL AS column_601,
            NULL AS column_11,
            NULL AS column_7121,
            NULL AS column_7145          
       FROM dataset_317                  dataset_318,
            dataset_270 dataset_319,
            dataset_269 dataset_45,
            dataset_269 dataset_2538,
            dataset_2483      dataset_2484,
            dataset_2485 dataset_461
      WHERE dataset_318.column_07 = 
        AND dataset_318.column_599 = dataset_319.column_599   
        AND dataset_45.column_598 = dataset_319.column_598
        AND dataset_45.column_4126 = dataset_2538.column_598
        AND dataset_2484.column_598 = dataset_45.column_598
        AND dataset_2484.column_3118 = dataset_461.column_3118   
        AND dataset_461.column_3119   in('####','###','##_###','##_####')
        AND nvl(dataset_2484.column_1446, dataset_318.column_11) = dataset_318.column_11
        AND dataset_461.column_6384         IN ('######_####', '####', '#############_####')),
    dataset_6410 AS (
        SELECT dataset_333.*,
               CASE WHEN dataset_333.column_6377 = '#' THEN dataset_333.column_6087 - dataset_333.column_6563 END AS column_6565,
               CASE WHEN dataset_333.column_6377 = '#' THEN dataset_333.column_6087 - dataset_333.column_6563 end AS column_23482,
               CASE WHEN dataset_333.column_6377 = '#' THEN (dataset_333.column_6087 - dataset_333.column_6563) * nvl(dataset_333.column_6567, 100) / dataset_333.column_6633     END AS column_6569,
               CASE WHEN dataset_333.column_6377 = '#' THEN (dataset_333.column_6087 - dataset_333.column_6563) * nvl(dataset_333.column_6572, nvl(dataset_333.column_6567, 100)) / dataset_333.column_6633     END AS column_6573,
               CASE WHEN dataset_333.column_6567 < 100 THEN dataset_333.column_6379                ELSE dataset_333.column_6380               END AS column_6568,
               CASE WHEN dataset_333.column_6572 < 100 THEN dataset_333.column_6379                ELSE dataset_333.column_6380               END AS column_6636,
               CASE WHEN dataset_333.column_6377 = '#' THEN nvl(dataset_333.column_6567, 100) END AS column_23483,
               CASE WHEN dataset_333.column_3063 = '########'
                      OR (dataset_333.column_3063 = '########' AND dataset_333.column_4128 > 0)
                    THEN dataset_333.column_6087 - dataset_333.column_6563
               END AS column_6579,
               CASE WHEN NOT (dataset_333.column_3063 = '########'
                      OR (dataset_333.column_3063 = '########' and dataset_333.column_4128 > 0))
                    THEN dataset_333.column_6087 - dataset_333.column_6563
               END AS column_6581,
               CASE WHEN column_6563 > 0
                     AND dataset_333.column_3160           IS NOT NULL
                     AND dataset_333.column_3160 > dataset_333.column_6382      
                    THEN dataset_333.column_6563
               END AS column_6583,
               CASE WHEN dataset_333.column_6563 > 0
                     AND dataset_333.column_3160           IS NULL
                      OR (dataset_333.column_3160           IS NOT NULL AND dataset_333.column_3160           <= dataset_333.column_6382)
                    THEN dataset_333.column_6563
               END AS column_6585,
               --### ##########
               CASE WHEN dataset_333.column_6563 > 0 AND dataset_333.column_23481 = '#' THEN dataset_333.column_6563 END AS column_23484,
               CASE WHEN dataset_333.column_6563 > 0 AND dataset_333.column_23481 = '#' THEN dataset_333.column_6563 END AS column_23485,
               -- ## ### #### ##########
               CASE WHEN (dataset_333.column_2710='##_###' OR dataset_333.column_601='##_###')
                     AND ((MONTHS_BETWEEN(SYSDATE,dataset_2547.column_973)/12) <= 2 OR
                          (MONTHS_BETWEEN(SYSDATE,dataset_2546.column_2748)/12) <= 1 )
                    THEN dataset_333.column_6563
               END AS column_23486,
               CASE WHEN (dataset_333.column_2710='##_###' OR dataset_333.column_601='##_###')
                     AND ((MONTHS_BETWEEN(SYSDATE,dataset_2547.column_973)/12) > 2 AND
                          (MONTHS_BETWEEN(SYSDATE,dataset_2546.column_2748)/12) > 1 )
                    THEN dataset_333.column_6563
                    WHEN (dataset_333.column_2710       <> '##_###' AND dataset_333.column_601<> '##_###')
                    THEN dataset_333.column_6563
               END AS column_23487             
         FROM dataset_976 dataset_333
                   LEFT OUTER JOIN dataset_1210           dataset_2546  ON (dataset_333.column_2857 = dataset_2546.column_2858 )
                   LEFT OUTER JOIN dataset_1211           dataset_2547 ON (dataset_2547.column_2859 = dataset_2546.column_2859)),
    dataset_6411 AS (
        SELECT dataset_333.*,
               /* ##### ###### */
               /* #### ### ##### ####### #### ## [#### ######, ####### ####] ###### ## #### #### #### ##### ######## */
               CASE WHEN dataset_333.column_6087 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6087 DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23488,
               CASE WHEN dataset_333.column_6087 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6087 DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23489,

               /* #### ### ##### ########## ####### ## [#### ######, ########## #######] ###### ## #### #### #### ##### ######## */
               CASE WHEN dataset_333.column_6087 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6087 DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23490,
               CASE WHEN dataset_333.column_6087 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6087 DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23491,

               /* ######### ###### */
               /* #### ### ##### ####### #### ## [#### ######, ####### ####] ###### ## #### #### #### ######### ######## */
               CASE WHEN dataset_333.column_6563 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6563 DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23492,
               CASE WHEN dataset_333.column_6563 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6563 DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23493,

               /* #### ### ##### ########## ####### ## [#### ######, ########## #######] ###### ## #### #### #### ######### ######## */
               CASE WHEN dataset_333.column_6563 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6563 DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23494,
               CASE WHEN dataset_333.column_6563 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6563 desc nulls last) = 1 THEN dataset_333.column_1446        END AS column_23495,

               /* ###### ### *###* ####### ## ########### */
               /* #### ### ##### ####### #### ## [#### ######, ####### ####] ###### ## #### #### #### ###### ### *###* ####### ## ########### ######## */
               CASE WHEN dataset_333.column_6565 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6565 DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23496,
               CASE WHEN dataset_333.column_6565 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6565 desc nulls last) = 1 THEN dataset_333.column_714   END AS column_23497,

               /* #### ### ##### ########## ####### ## [#### ######, ########## #######] ###### ## #### #### #### ###### ### *###* ####### ## ########### ######## */
               CASE WHEN dataset_333.column_6565 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6565 DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23498,
               CASE WHEN dataset_333.column_6565 > 0 and row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6565 DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23499,

               /* ###### ### ####### ## ########### */
               /* #### ### ##### ####### #### ## [#### ######, ####### ####] ###### ## #### #### #### ###### ### ####### ## ########### ######## */
               CASE WHEN dataset_333.column_23482 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_23482          DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23500,
               CASE WHEN dataset_333.column_23482 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_23482          DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23501,

               /* #### ### ##### ########## ####### ## [#### ######, ########## #######] ###### ## #### #### #### ###### ### ####### ## ########### ######## */
               CASE WHEN dataset_333.column_23482 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_23482          DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23502,
               CASE WHEN dataset_333.column_23482 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118,  dataset_333.column_1446        ORDER BY dataset_333.column_23482          DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23503,
               CASE WHEN dataset_333.column_6377 = '#' THEN package_180.package_function_394(,dataset_333.column_6568,dataset_333.column_6569,dataset_333.column_11) END AS column_6570,
               CASE WHEN dataset_333.column_6377 = '#' THEN package_180.package_function_394(,dataset_333.column_6636,dataset_333.column_6573,dataset_333.column_11) END AS column_6574,

               /* ####### ### ###### #########, ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_6579 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6579         desc nulls last) = 1 THEN dataset_333.column_714   END AS column_23504,
               CASE WHEN dataset_333.column_6579 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6579         desc nulls last) = 1 THEN dataset_333.column_714   END AS column_23505,
               CASE WHEN dataset_333.column_6579 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6579         DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23506,
               CASE WHEN dataset_333.column_6579 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6579         DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23507,

               /*####### ### ###### ####### #######, ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_6581 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6581              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23508,
               CASE WHEN dataset_333.column_6581 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6581              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23509,
               CASE WHEN dataset_333.column_6581 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6581              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23510,
               CASE WHEN dataset_333.column_6581 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6581              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23511,

               /*####### ### "######### #### ############", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_6583 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6583          DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23512,
               CASE WHEN dataset_333.column_6583 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6583          DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23513,
               CASE WHEN dataset_333.column_6583 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6583          DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23514,
               CASE WHEN dataset_333.column_6583 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6583          DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23515,

               /*####### ### "######### ### #######", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_6585 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_6585              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23516,
               CASE WHEN dataset_333.column_6585 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_6585              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23517,
               CASE WHEN dataset_333.column_6585 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_6585              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23518,
               CASE WHEN dataset_333.column_6585 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_6585              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23519,

               /*####### ### ### "######### #### #######", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_23484 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_23484      DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23520,
               CASE WHEN dataset_333.column_23484 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_23484      DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23521,
               CASE WHEN dataset_333.column_23484 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_23484      DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23522,
               CASE WHEN dataset_333.column_23484 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_23484      DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23523,

               /*####### ### "######### #### ### ####", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_23485 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_23485       DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23524,
               CASE WHEN dataset_333.column_23485 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_23485       DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23525,
               CASE WHEN dataset_333.column_23485 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_23485       DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23526,
               CASE WHEN dataset_333.column_23485 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_23485       DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23527,
               CASE WHEN dataset_333.column_6087 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383 ORDER BY dataset_333.column_6087 DESC NULLS LAST) = 1 THEN dataset_333.column_5253         END AS column_23528,

               /*####### ### "########## ### ######### ###", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/
               CASE WHEN dataset_333.column_23487 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_23487              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23529,
               CASE WHEN dataset_333.column_23487 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_23487              DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23530,
               CASE WHEN dataset_333.column_23487 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_23487              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23531,
               CASE WHEN dataset_333.column_23487 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_23487              DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23532,

               /*####### ### "########## ### ######### ### ###", ### ### ##### ####### ####, ########## ####### ### # ###### ### ######-#### ###########*/

               CASE WHEN dataset_333.column_23486 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_714   ORDER BY dataset_333.column_23486                  DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23533,
               CASE WHEN dataset_333.column_23486 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_714   ORDER BY dataset_333.column_23486                  DESC NULLS LAST) = 1 THEN dataset_333.column_714   END AS column_23534,
               CASE WHEN dataset_333.column_23486 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_6383, dataset_333.column_1446        ORDER BY dataset_333.column_23486                  DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23535,
               CASE WHEN dataset_333.column_23486 > 0 AND row_number() OVER (PARTITION BY dataset_333.column_3118, dataset_333.column_1446        ORDER BY dataset_333.column_23486                  DESC NULLS LAST) = 1 THEN dataset_333.column_1446        END AS column_23536                 
          FROM dataset_6410 dataset_333),
    dataset_8351   AS (
        SELECT dataset_333.*,
               /*### # ##### ## ####### ####### #####, ########## ######## ### ####### #### ## ####### ### # ######.
                 #### ## ####### ########### ## #####, ### ##### ### ## ####### #### #### ######*/

               /*#####, #######/########### #####*/
               COUNT(DISTINCT dataset_333.column_23489) OVER (PARTITION BY dataset_333.column_3118) column_23537,
               COUNT(DISTINCT dataset_333.column_23491) OVER (PARTITION BY dataset_333.column_3118) column_23538,
               MAX(DECODE(dataset_333.column_23489, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23539,

               /*#########, #######/########### #####*/
               COUNT(DISTINCT dataset_333.column_23493) OVER (PARTITION BY dataset_333.column_3118) column_23540,
               COUNT(DISTINCT dataset_333.column_23495) OVER (PARTITION BY dataset_333.column_3118) column_23541,
               MAX(DECODE(dataset_333.column_23493, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23542,

               /*######-### ####### ## ########### #######/########### #####*/
               COUNT(DISTINCT dataset_333.column_23497) OVER (PARTITION BY dataset_333.column_3118) column_23543,
               COUNT(DISTINCT dataset_333.column_23499) OVER (PARTITION BY dataset_333.column_3118) column_23544,
               MAX(DECODE(dataset_333.column_23497, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23545,

               /*######-####### ## ########### #######/########### #####*/
               COUNT(DISTINCT dataset_333.column_23501) OVER (PARTITION BY dataset_333.column_3118) column_23546,
               COUNT(DISTINCT dataset_333.column_23503) OVER (PARTITION BY dataset_333.column_3118) column_23547,
               MAX(DECODE(dataset_333.column_23501, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23548,

               /*###### ########, ## #### ## ######## #####*/
               COUNT(DISTINCT dataset_333.column_23505) OVER (PARTITION BY dataset_333.column_3118) column_23549,
               COUNT(DISTINCT dataset_333.column_23507) OVER (PARTITION BY dataset_333.column_3118) column_23550,
               MAX(DECODE(dataset_333.column_23505, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23551,

               /*###### ####### #######, ## #### ## ######## #####*/
               COUNT(DISTINCT dataset_333.column_23509) OVER (PARTITION BY dataset_333.column_3118) column_23552,
               COUNT(DISTINCT dataset_333.column_23511) OVER (PARTITION BY dataset_333.column_3118) column_23553,
               MAX(DECODE(dataset_333.column_23509, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23554,

               /*######### #### ############, ## #### ## ######## #####*/
               COUNT(DISTINCT dataset_333.column_23513) OVER (PARTITION BY dataset_333.column_3118) column_23555,
               COUNT(DISTINCT dataset_333.column_23515) OVER (PARTITION BY dataset_333.column_3118) column_23556,
               MAX(DECODE(dataset_333.column_23513, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23557,

               /*######### ### #######, ## #### ## ######## #####*/
               COUNT(DISTINCT dataset_333.column_23517) OVER (PARTITION BY dataset_333.column_3118) column_23558,
               COUNT(DISTINCT dataset_333.column_23519) OVER (PARTITION BY dataset_333.column_3118) column_23559,
               MAX(DECODE(dataset_333.column_23517, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23560,


               /*######### #### #######, ## #### ## ### #####*/
               COUNT(DISTINCT dataset_333.column_23521) OVER (PARTITION BY dataset_333.column_3118) column_23561,
               COUNT(DISTINCT dataset_333.column_23523) OVER (PARTITION BY dataset_333.column_3118) column_23562,
               MAX(DECODE(dataset_333.column_23521, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23563,

               /*######### #### ### ####, ## #### ## ### #####*/
               COUNT(DISTINCT dataset_333.column_23525) OVER (PARTITION BY dataset_333.column_3118) column_23564,
               COUNT(DISTINCT dataset_333.column_23527) OVER (PARTITION BY dataset_333.column_3118) column_23565,
               MAX(DECODE(dataset_333.column_23525, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23566,

               MAX(DECODE(dataset_333.column_2646, '##########', '#','#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23567,
               MAX(DECODE(dataset_333.column_2646, '############', '#','#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23568,
               /* ## ### ########## ### ######### ### */
               COUNT(DISTINCT dataset_333.column_23530) OVER (PARTITION BY dataset_333.column_3118) column_23569,
               COUNT(DISTINCT dataset_333.column_23531) OVER (PARTITION BY dataset_333.column_3118) column_23570,
               MAX(DECODE(dataset_333.column_23530, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23571,

               /* ## ### ########## ### ######### ### ### */
               COUNT(DISTINCT dataset_333.column_23534) OVER (PARTITION BY dataset_333.column_3118) column_23572,
               COUNT(DISTINCT dataset_333.column_23536) OVER (PARTITION BY dataset_333.column_3118) column_23573,
               MAX(DECODE(dataset_333.column_23534, '####', '#')) OVER (PARTITION BY dataset_333.column_3118) AS column_23574                
          FROM dataset_6411 dataset_333)
    SELECT dataset_461.column_3118,
           dataset_333.column_6383,
           dataset_461.column_500,
           dataset_461.column_23575,
           dataset_461.column_3119,
           dataset_461.column_8208,
           dataset_461.column_2647,
           dataset_461.column_8207,
           dataset_461.column_6559,
           dataset_461.column_8206          AS column_23576,
           dataset_461.column_10,
           DECODE(SUM(dataset_333.column_6563), 0, '#', '#') AS column_6578,
           dataset_333.column_7121,
           dataset_333.column_7145,
           /* ########## ##### */
           COUNT(DISTINCT dataset_333.column_23488) AS column_23577,
           --#####(######## #.#####_##########_#######) ## #####_##########_########

           /* ##### ######## ###### ## # ### ## #####, ###### ### ###### #### ####### ### ###### ######### ####### ########### #### */
           CASE WHEN MAX(dataset_333.column_23537) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####' AND max(column_23538) = 1 AND max(column_23539) IS NULL
                THEN nvl(sum(nvl(dataset_333.column_6565, 0) + nvl(dataset_333.column_6570, 0) + nvl(dataset_333.column_6563, 0) ), 0)
           END AS column_6087,
           NVL(dataset_461.column_6559,

           /* #####_#######_####_#### */
           DECODE(dataset_461.column_3119, '#######',
                        LISTAGG(dataset_333.column_23528, ',') WITHIN GROUP (ORDER BY dataset_333.column_23528),
                        LISTAGG(dataset_333.column_23488, ',') WITHIN GROUP (ORDER BY dataset_333.column_23488))) AS column_23578,
           NVL(SUM((NVL(dataset_333.column_6565, 0) + NVL(dataset_333.column_6570, 0) + NVL(dataset_333.column_6563, 0)) * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_5007,

           /* ########## ###### ### ####### ## ########### */
           COUNT(DISTINCT dataset_333.column_23500) AS column_23579,
           CASE WHEN max(dataset_333.column_23546) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23547) = 1
                 AND max(dataset_333.column_23548) IS NULL
                THEN nvl(sum(dataset_333.column_6570), 0)
           END AS column_6570,
           NVL(dataset_461.column_6559,

           /* ######_####_#######_####_#### */
           LISTAGG(dataset_333.column_23500, ',') WITHIN GROUP (ORDER BY dataset_333.column_23500)) AS column_23580,
           NVL(SUM(dataset_333.column_6570 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6571,
           CASE
                /* ## ########### ####### ## ########### ####### ####### ########### #### => ##### #### */
                WHEN COUNT(dataset_333.column_6567) = 0 THEN NULL
                /* ### ########### ####### ## ########### ####### ### #### ####### ########### #### => ##### #### #### */
                WHEN COUNT(DISTINCT dataset_333.column_23483) = 1 THEN max(dataset_333.column_23483)
                /* ### ########### ####### ## ########### ####### ######### ####### ########### ##### => ##### -# */
                ELSE -1
           END AS column_6567,
           SUM(dataset_333.column_6574 * dataset_333.column_6561 * dataset_333.column_6562 ) AS column_6575,

           /* ### ########### ####### ## ########### ####### ### #### ### ########### #### => ##### #### #### #### ##### #### */
           CASE WHEN COUNT(DISTINCT dataset_333.column_23480) = 1 THEN MAX(dataset_333.column_6572) END AS column_6572,

           /* ########## ###### ### *###* ####### ## ########### */

           COUNT(DISTINCT dataset_333.column_23496) AS column_23581,
           --#####(######## #.######_##########_#######) ## ######_##########_########,
           CASE WHEN MAX(dataset_333.column_23543) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(column_23544)  = 1
                 AND max(column_23545) IS NULL
                THEN nvl(sum(dataset_333.column_6565), 0)
           END AS column_6565,
           NVL(dataset_461.column_6559, /* ######_#######_####_#### */ listagg(dataset_333.column_23496, ',') WITHIN GROUP (ORDER BY dataset_333.column_23496) ) AS column_23582,
           NVL(SUM(dataset_333.column_6565 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6566,

           /* ########## ######### */
           -- #####(######## #.#####_#######_####) ## #####_#######_#####,
           -- #####(######## #.#####_##########_#######) ## #####_##########_########,
           CASE WHEN MAX(dataset_333.column_23540) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND MAX(column_23541) = 1
                 AND MAX(column_23542) IS NULL
                THEN NVL(SUM(dataset_333.column_6563), 0)
           END AS column_6563,
           nvl(dataset_461.column_6559,
           /* #####_#######_####_#### */
           LISTAGG(dataset_333.column_23492, ',') WITHIN GROUP (ORDER BY dataset_333.column_23492)) AS column_23583,
           NVL(SUM(dataset_333.column_6563 * dataset_333.column_6561 * dataset_333.column_6562), 0) AS column_6564,

           /*###### ######### ####### ### ######## #####*/
           COUNT(DISTINCT dataset_333.column_23504) AS column_23584,
           CASE WHEN MAX(dataset_333.column_23549) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND MAX(dataset_333.column_23550) = 1
                 AND MAX(dataset_333.column_23551) IS NULL THEN NVL(sum(dataset_333.column_6579), 0)
           END AS column_6579,
           /* ######_#########_#######_####_#### */
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23504, ',') WITHIN GROUP (ORDER BY dataset_333.column_23504)) AS column_23585,
           NVL(sum(dataset_333.column_6579 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6580,

           /*###### ####### ####### ####### ### ######## #####*/
           COUNT(DISTINCT dataset_333.column_23508) AS column_23586,
           CASE WHEN MAX(dataset_333.column_23552) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23553) = 1
                 AND max(dataset_333.column_23554) IS NULL
                THEN nvl(sum(dataset_333.column_6581), 0)
           END AS column_6581,

           /* ######_#######_#####_#######_####_#### */
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23508, ',') WITHIN GROUP (ORDER BY dataset_333.column_23508) ) AS column_23587,
           NVL(sum(dataset_333.column_6581 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6582,

           /*"######### #### ############" ####### ### ######## #####*/
           COUNT(DISTINCT dataset_333.column_23512) AS column_23588,
           CASE WHEN MAX(dataset_333.column_23555) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND MAX(dataset_333.column_23556) = 1
                 AND MAX(dataset_333.column_23557) IS NULL
                THEN nvl(sum(dataset_333.column_6583), 0)
           END AS column_6583,

           /* ######_#######_#####_#######_####_#### */
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23512, ',') WITHIN GROUP (ORDER BY dataset_333.column_23512)) AS column_23589,
           NVL(SUM(dataset_333.column_6583 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6584,

           /*"######### #### ############" ####### ### ######## #####*/
           COUNT(DISTINCT dataset_333.column_23516) AS column_23590,
           CASE WHEN MAX(dataset_333.column_23558) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23559) = 1
                 AND max(dataset_333.column_23560) IS NULL
                THEN nvl(sum(dataset_333.column_6585), 0)
           END AS column_6585,

           /* ######_#######_#####_#######_####_#### */
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23516, ',') WITHIN GROUP (ORDER BY dataset_333.column_23516)) AS column_23591,
           NVL(SUM(dataset_333.column_6585 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_6586,

           /*"######### #### #######" ####### ### ### #####*/
           COUNT(DISTINCT dataset_333.column_23520) AS column_23592,
           CASE WHEN max(dataset_333.column_23561) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23562) = 1
                 AND max(dataset_333.column_23563) IS NULL
                THEN nvl(sum(dataset_333.column_23484), 0)
           END AS column_23484,
           NVL(dataset_461.column_6559, listagg(dataset_333.column_23520, ',') within group (order by dataset_333.column_23520) )AS column_23593,
           NVL(SUM(dataset_333.column_23484 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_23594,

           /*"######### #### ### ####" ####### ### ### #####*/
           COUNT(DISTINCT dataset_333.column_23524) AS column_23595,
           CASE WHEN max(dataset_333.column_23564) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23565) = 1
                 AND max(dataset_333.column_23566) IS NULL
                THEN nvl(sum(dataset_333.column_23485), 0)
           END AS column_23485,
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23524, ',') WITHIN GROUP (ORDER BY dataset_333.column_23524) ) AS column_23596,
           NVL(sum(dataset_333.column_23485 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_23597,
           dataset_461.column_6385,
           MAX(column_23567) column_23598,
           MAX(column_23568) column_23599,

           /*"########## ### ######### ### ### ### ##### ####*/
           COUNT(DISTINCT dataset_333.column_23529) AS column_23600,
           CASE WHEN MAX(dataset_333.column_23569) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23570) = 1
                 AND max(dataset_333.column_23571) IS NULL
                THEN nvl(sum(dataset_333.column_23487), 0)
           END AS column_23601,
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23529, ',') WITHIN GROUP (ORDER BY dataset_333.column_23529) ) AS column_23602,
           NVL(SUM(dataset_333.column_23487 * dataset_333.column_6561 * dataset_333.column_6562 ), 0) AS column_23603,

           /*########## ### ######### ### ### ### ##### ####*/
           COUNT(DISTINCT dataset_333.column_23533) AS column_23604,
           CASE WHEN MAX(dataset_333.column_23572) = 0 THEN 0
                WHEN dataset_461.column_8208 = '######'
                  OR dataset_461.column_8208 = '####'
                 AND max(dataset_333.column_23573) = 1
                 AND max(dataset_333.column_23574) IS NULL
                THEN nvl(sum(dataset_333.column_23486), 0)
           END AS column_23605,
           NVL(dataset_461.column_6559, LISTAGG(dataset_333.column_23533, ',') WITHIN GROUP (ORDER BY dataset_333.column_23533)) AS column_23606,
           NVL(SUM(dataset_333.column_23486 * dataset_333.column_6561 * dataset_333.column_6562), 0) AS column_6628                
      FROM dataset_8351   dataset_333,
           (SELECT DENSE_RANK() OVER (ORDER BY dataset_461.column_500, dataset_461.column_2647) AS column_23575, dataset_461.* FROM dataset_2485 dataset_461) dataset_461
     WHERE dataset_461.column_3118 = dataset_333.column_3118   
  GROUP BY dataset_461.column_3118,
           dataset_461.column_500,
           dataset_461.column_23575,
           dataset_461.column_3119,
           dataset_461.column_2647,
           dataset_461.column_8207,
           dataset_461.column_8208,
           dataset_461.column_6559,
           dataset_461.column_8206,
           dataset_461.column_10,
           dataset_333.column_7121,
           dataset_333.column_7145,
           dataset_333.column_6383,
           dataset_461.column_6385             
  ORDER BY
           dataset_461.column_500,
           dataset_461.column_2647