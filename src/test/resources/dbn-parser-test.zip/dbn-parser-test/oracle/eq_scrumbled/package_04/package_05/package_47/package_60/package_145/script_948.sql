/******************************************************************************
    ##### #####: ########_#####_#######
    #########:   ########_#####
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### ######## ##### ##### (####### #####)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### #### (###########)
        - #######_######                   ####### ######
        - ##########_####                  ########## ####
        - ######_####                      ###### ####
        - #########                        #########
        - ####                             ####
        - ########_#########               ######## #########
        - ####                             ####
        - #####_####                       ##### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - #####_##                         ##### ## / #### ## / #### ##
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #############_######             ############# ######
        - ####_#####                       #### #####
        - ####_####_#                      #### #### #
        - #####_####                       ##### ####
        - ######                           ######
        - #####_##########                 ##### ##### (##### ##########)
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - #######                          #######
        - #############_########           ############# ########
        - ####_##                          ########### ##
        - ###########_##                   ########### ##
        - #####_######                     ##### ######/ #######/ ########## ######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####

    ###### ## ###########:  ##(######## #####)||###(#######)||<####### ##### ##>||<##.#####_###########_##>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ######## ######## #####/#### ######
    ##.#.#    ##.##.####   ### #####    ###-##### ######### #######
*******************************************************************************/
SELECT
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_567,
    NULL AS column_7074,
    column_7075,
    column_562,
    column_7077,
    NULL AS column_5861,
    column_3924,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_5694,
    column_7083,
    column_874,
    NULL AS column_7084,
    column_7085,
    column_1477,
    NULL AS column_549,
    column_11799,
    column_7087,
    NULL AS column_11800,
    column_566,
    column_10,
    NULL AS column_11801,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    NULL AS column_8429,
    column_7078,
    NULL AS column_3816,
    column_1309,
    column_753,
    NULL AS column_534,
    NULL AS column_7106,
    NULL AS column_7107,
    NULL AS column_7108,
    NULL AS column_7109,
    NULL AS column_7110,
    NULL AS column_7111,
    NULL AS column_7112,
    NULL AS column_7113,
    NULL AS column_7114
FROM (
    WITH dataset_949                            as (
            select /*+ ########### */ dataset_950.column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_360  dataset_104
                WHERE column_2345 = 
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),    
    dataset_260      AS (
        SELECT column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
      dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945)    
    SELECT
        dataset_104.column_354                                                                      AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_937.column_7118                                  AS column_1117,
        '#'                                                                               AS column_2468,
        package_131.package_function_134(  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2400                 
                 ELSE dataset_747.column_1318               
            END    ,
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2401             
                 ELSE dataset_747.column_1319           
            END     ,  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2396            
                 ELSE dataset_747.column_1320          
            END    ,dataset_2726.column_2344)                                                        AS column_1328,
        TO_CHAR(dataset_747.column_899, '##/##/####')                                              AS column_567,
        '##########: #### - ##### ## ######'                                              AS column_7075,
        dataset_937.column_562                                                                           AS column_562,
        dataset_747.column_148                                                                     AS column_7077,
        '#####'                                                                           AS column_3924,
        dataset_104.column_122                                                                      AS column_2329,
        dataset_747.column_148                                                                     AS column_5694,
        '#####'                                                                           AS column_7083,
        '###'                                                                             AS column_874,
        DECODE(dataset_937.column_3916, '###', dataset_937.column_3920, NULL)                         AS column_7085,
        DECODE(dataset_937.column_3916, '####', dataset_937.column_3920, NULL)                        AS column_1477,
        dataset_747.column_735                                                                         AS column_11799,
        dataset_937.column_7119                                                                     AS column_7087,
        TO_CHAR(dataset_937.column_566, '##/##/####')                                              AS column_566,
        '##### ## ######'                                                                 AS column_10,
        dataset_937.column_532                                                                     AS column_7078,
        dataset_747.column_148                                                                     AS column_1309,
        dataset_259.column_2348       ||'/'||
            package_381.package_function_413(
                            argument_01              => '#####',
                            argument_650             => dataset_747.column_1065,
                            argument_73              => dataset_259.column_76)||'/'||
             DECODE(dataset_937.column_3916, '###',
                    dataset_747.column_2442,
                    dataset_747.column_2443)                                      AS column_753  
    FROM dataset_1519       dataset_937,
         dataset_1369      dataset_747,
         dataset_257  dataset_256,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_360  dataset_104,
         dataset_2723      dataset_2726 
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_937.column_1061 = '##'
        AND dataset_937.column_1071               <> '###'
        AND dataset_256.column_583 = dataset_937.column_148          
        AND dataset_256.column_3619         IS NULL
        AND dataset_747.column_148 = dataset_256.column_583          
        AND dataset_747.column_1065 = '######-#########-####-##'
        AND dataset_747.column_76 = dataset_259.column_76 (+)
        AND nvl(dataset_747.column_76,dataset_747.column_2444) = dataset_964.column_76     
        AND CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_530 
                 ELSE dataset_747.column_2440           
            END =dataset_2726.column_591
        -- ###### ###### / ####### ######
        AND dataset_104.column_354 = 
        AND dataset_747.column_204 >  
        AND dataset_747.column_204 <= 

    UNION ALL
    SELECT
        dataset_104.column_354                                                                      AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_937.column_7118                                  AS column_1117,
        '#'                                                                               AS column_2468,
        package_131.package_function_134(  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2400                 
                 ELSE dataset_747.column_1318               
            END    ,
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2401             
                 ELSE dataset_747.column_1319           
            END     ,  
            CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_2396            
                 ELSE dataset_747.column_1320          
            END    ,dataset_2726.column_2344)                                                        AS column_1328,
        TO_CHAR(dataset_747.column_899, '##/##/####')                                              AS column_567,
        '##########: #### - ##### ## ######'                                              AS column_7075,
        dataset_937.column_562                                                                           AS column_562,
        dataset_747.column_148                                                                     AS column_7077,
        '####_#####'                                                                      AS column_3924,
        dataset_104.column_122                                                                      AS column_2329,
        dataset_747.column_148                                                                     AS column_5694,
        '#####'                                                                           AS column_7083,
        '###'                                                                             AS column_874,
        DECODE(dataset_937.column_3916, '###', dataset_937.column_3920, NULL)                         AS column_7085,
        DECODE(dataset_937.column_3916, '####', dataset_937.column_3920, NULL)                        AS column_1477,
        dataset_747.column_735                                                                         AS column_11799,
        dataset_937.column_7119                                                                     AS column_7087,
        TO_CHAR(dataset_937.column_566, '##/##/####')                                              AS column_566,
        '##### ## ######'                                                                 AS column_10,
        dataset_937.column_532                                                                     AS column_7078,
        dataset_747.column_148                                                                     AS column_1309,
        dataset_259.column_2348       ||'/'||
            package_381.package_function_413(
                            argument_01              => '#####',
                            argument_650             => dataset_747.column_1065,
                            argument_73              => dataset_259.column_76)||'/'||
             DECODE(dataset_937.column_3916, '###',
                    dataset_747.column_2442,
                    dataset_747.column_2443)                                      AS column_753  
    FROM dataset_1519       dataset_937,
         dataset_1369      dataset_747,
         dataset_2425      dataset_256,
         dataset_260      dataset_259,
         dataset_949                            dataset_964,
         dataset_360  dataset_104,
         dataset_2723      dataset_2726 
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_937.column_1061 = '##'
        AND dataset_937.column_1071               <> '###'
        AND dataset_256.column_3619 = dataset_937.column_148          
        AND dataset_747.column_148 = dataset_256.column_3619        
        AND dataset_747.column_1065 = '######-#########-####-##'
        AND dataset_747.column_76 = dataset_259.column_76 (+)
        AND nvl(dataset_747.column_76,dataset_747.column_2444) = dataset_964.column_76     
        AND CASE WHEN dataset_937.column_3916 = '###'
                 THEN dataset_747.column_530 
                 ELSE dataset_747.column_2440           
            END =dataset_2726.column_591
        -- ###### ###### / ####### ######
        AND dataset_104.column_354 = 
        AND dataset_747.column_204 >  
        AND dataset_747.column_204 <= 
)

