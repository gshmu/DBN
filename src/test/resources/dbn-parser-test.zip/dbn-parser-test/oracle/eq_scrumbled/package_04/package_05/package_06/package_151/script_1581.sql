create or replace PACKAGE                                                 package_911             
AUTHID CURRENT_USER
IS

  /*****************************************************************************
   ######### (#) ####,#### ###, ### ##

   ######.....: ##_###_#######_###_#####
   #######....: #### ####### ######## #### ##### ### ### ####### ###_#######_###_#####.

  ####### ####         ###            ########
**********************************************************************
  ####### ##.#
  ##.#.#  ##.##.####   ########       ###-##### : ####### ### ####### ###_###########_###
**********************************************************************/

TYPE type_893       IS RECORD
        (type_attribute_1410                  schema_435.dataset_4890%TYPE
        ,type_attribute_1411                  schema_435.dataset_4891%TYPE
        ,type_attribute_01                 schema_435.dataset_05%TYPE
        ,type_attribute_1412                   schema_435.dataset_4892%TYPE
        ,type_attribute_17                         schema_435.dataset_08%TYPE
        ,type_attribute_1786            schema_435.dataset_5769%TYPE
        ,type_attribute_1787            schema_435.dataset_3269%TYPE
        ,type_attribute_1788            schema_435.dataset_5770%TYPE
        );
    
    TYPE type_894              IS RECORD
        (type_attribute_01                   schema_09.dataset_05%TYPE
        ,type_attribute_1789                      schema_09.dataset_474%TYPE
        ,type_attribute_1787              schema_09.dataset_3269%TYPE
        ,type_attribute_207                 schema_09.dataset_04%TYPE
        ,type_attribute_1788              schema_09.dataset_5770%TYPE
        ,type_attribute_1790              schema_09.dataset_3291%TYPE
        ,type_attribute_65                      schema_173.dataset_147%TYPE
        );
    
    TYPE type_895                IS RECORD
        (type_attribute_1410           schema_435.dataset_4890%TYPE
        ,type_attribute_1411           schema_435.dataset_4891%TYPE
        ,type_attribute_01          schema_435.dataset_05%TYPE
        ,type_attribute_1412            schema_435.dataset_4892%TYPE
        ,type_attribute_1787     schema_435.dataset_3269%TYPE
        ,type_attribute_17                  schema_435.dataset_08%TYPE
        ,type_attribute_65             schema_173.dataset_147%TYPE
        );
    
    TYPE type_896  IS RECORD
        (type_attribute_01         schema_07.dataset_05%TYPE
        ,type_attribute_100      schema_07.dataset_186%TYPE
        ,type_attribute_101    schema_07.dataset_187%TYPE
        ,type_attribute_374               schema_07.dataset_09%type
        ,type_attribute_752        schema_07.dataset_2548%TYPE
        ,type_attribute_951    schema_07.dataset_3260%TYPE
        ,type_attribute_755    schema_07.dataset_2549%TYPE
        ,type_attribute_950    schema_07.dataset_3259%TYPE
        ,type_attribute_945    schema_07.dataset_3261%TYPE
        ,type_attribute_1791         schema_07.dataset_6043%TYPE
        ,type_attribute_936    NUMBER(21,6)
        ,type_attribute_564          schema_07.dataset_28%TYPE
        ,type_attribute_565      schema_07.dataset_1990%TYPE
        ,type_attribute_566         schema_07.dataset_1991%TYPE
        ,type_attribute_349           schema_07.dataset_1099%tYPE
        ,type_attribute_207      schema_07.dataset_04%TYPE
        ,type_attribute_870         schema_186.dataset_2707%TYPE
        ,type_attribute_832     schema_186.dataset_1493%TYPE
        ,type_attribute_1792       schema_545.dataset_4838%TYPE
        ,type_attribute_858              schema_07.dataset_2695%type
        ,type_attribute_1793       DATE
        ,type_attribute_1698   schema_07.dataset_5782%TYPE
        );

-- %#####(#### ##### #### ## #### ####### ### ####### ### #####)
-- %###########(### #####)

-- %####(### ###### ### ######)
-- %###########(### ###### ### ###### ####### #)
PROCEDURE procedure_2602;

-- %####(### ###### ### ######)
-- %###########(### ###### ### ###### ####### #)
PROCEDURE procedure_2603;

-- %####(##### ##### #### #####)
-- %###########(### ### ####### #### ####### #)
PROCEDURE procedure_2604;

-- %####(##### ##### #### #####)
-- %###########(### ### ####### #### ####### #)
PROCEDURE procedure_2605;

-- %####(##### ##### #### ##### ########)
-- %###########(##### ##### #### ##### ######## ####### #)
PROCEDURE procedure_2606;

-- %####(##### ##### #### ##### ########)
-- %###########(##### ##### #### ##### ######## ####### #)
PROCEDURE procedure_2607;

-- %####(##### ##### #### ##### #########)
-- %###########(##### ##### #### ##### ######### ####### #)
PROCEDURE procedure_2608;

-- %####(##### ##### #### ##### #########)
-- %###########(##### ##### #### ##### ######### ####### #)
PROCEDURE procedure_2609;

-- %####(### ###### ########## #### ##)
-- %###########(### ###### ########## #### ## ####### ####### ####)
PROCEDURE procedure_2610;

-- %####(### ####### ########## ####)
-- %###########(### ####### ########## #### ####### ####### ####)
PROCEDURE procedure_2611;

-- %####(### ###### ########## ####)
-- %###########(### ###### ########## #### ####### ####### ####)
PROCEDURE procedure_2612;

-- %####(### ### ### ########)
-- %###########(### ### ### ######## ####### ### ### ########)
PROCEDURE procedure_2613;

-- %####(### ###### ### ###### #######)
-- %###########(### ###### ### ###### ####### ####### #)
PROCEDURE procedure_2614;

-- %####(### ###### ### ###### #######)
-- %###########(### ###### ### ###### ####### ####### #)
PROCEDURE procedure_2615;

-- %####(### ##### ####)
-- %###########(### ##### #### ####### #)
PROCEDURE procedure_2616;

-- %####(### ##### #### ### ##########)
-- %###########(### ##### #### ### ########## ####### #)
PROCEDURE procedure_2617;

-- %####(### ##### #### ### ##########)
-- %###########(### ##### #### ### ########## ####### #)
-- %######(-#####)
PROCEDURE procedure_2618;

-- %####(### ########### ######)
-- %###########(### ########### ###### ####### #)
PROCEDURE procedure_2619;

-- %####(### ########### ######)
-- %###########(### ########### ###### ####### #)
PROCEDURE procedure_2620;

-- %####(### ########### #######)
-- %###########(### ########### ####### ####### #)
PROCEDURE procedure_2621;

-- %####(### ###### ####)
-- %###########(### ###### #### ####### #)
PROCEDURE procedure_2622;

-- %####(### ### ### ###### ######)
-- %###########(### ### ### ###### ###### ####### #)
PROCEDURE procedure_2623;

-- %####(### ### ### ##### ###### ######)
-- %###########(### ### ### ##### ###### ###### ####### #)
PROCEDURE procedure_2624;

-- %####(### ########## ###### ####)
-- %###########(### ########## ###### #### ####### #)
PROCEDURE procedure_2625;

-- %####(### ########## ###)
-- %###########(### ########## ### ####### ######)
PROCEDURE procedure_2626;

-- %####(## #### ######)
-- %###########(## #### ###### ####### ###### ## #)
PROCEDURE procedure_2627;

-- %####(## #### ######)
-- %###########(## #### ###### ####### ###### ## #)
PROCEDURE procedure_2628;

-- %####(######### ########## ########)
-- %###########(######### ########## ######## ####### ######)
PROCEDURE procedure_2629;

-- %####(######### ########## ######## ### ##########)
-- %###########(######### ########## ######## ### ########## ####### ######)
PROCEDURE procedure_2630;

-- %####(### ########### ###### ####)
-- %###########(### ########### ###### #### ####### #)
PROCEDURE procedure_2631;

-- %####(### ########### ######### ######)
-- %###########(### ########### ######### ###### ####### ###### ##)
PROCEDURE procedure_2632;

-- %####(### ########### ######### ######)
-- %###########(### ########### ######### ###### ####### ########### ######)
PROCEDURE procedure_2633;

-- %####(### ########### ######### ##)
-- %###########(### ########### ######### ## ####### #########_##)
PROCEDURE procedure_2634;

-- %####(### ########### ######### ##)
-- %###########(### ########### ######### ## ####### ####)
PROCEDURE procedure_2635;

-- %####(### ########### #######)
-- %###########(### ########### ####### ####### ########### ####### ### ##### #### ######)
PROCEDURE procedure_2636;

END package_911;
/

create or replace PACKAGE BODY                                                 package_911              AS

  /*********************************************************************************************************
  
  ### ####### #### ######## - ###_#######_### ######.
  
  ### ### ####### #### ####### # 
  ### ### ####### #### ####### # 
  ##### ##### #### ##### ######## ####### # 
  ##### ##### #### ##### ######## ####### # 
  ##### ##### #### ##### ######### ####### #
  ##### ##### #### ##### ######### ####### #
  ### ###### ########## #### ## ####### ####### ####
  ### ####### ########## #### ####### ####### #### 
  ### ###### ########## #### ####### ####### ####
  ### ### ### ######## ####### ### ### ########
  ### ###### ### ###### ####### ####### #
  ### ###### ### ###### ####### ####### #
  ### ##### #### ####### #
  ### ##### #### ### ########## ####### # 
  ### ##### #### ### ########## ####### # 
  ### ########### ###### ####### #
  ### ########### ###### ####### # 
  ### ########### ####### ####### # 
  ### ###### #### ####### #
  ### ### ### ###### ###### ####### # 
  ### ### ### ##### ###### ###### ####### # 
  ### ########## ###### #### ####### #
  ### ########## ### ####### ######
  ## #### ###### ####### ###### ## #
  ## #### ###### ####### ###### ## #
  ######### ########## ######## ####### ######
  ### ########### ###### #### ####### #
  ### ########### ######### ###### ####### ###### ##
  ### ########### ######### ###### ####### ########### ######
  ### ########### ######### ## ####### #########_##
  ### ########### ######### ## ####### ####
  ### ########### ####### ####### ########### ####### ### ##### #### ######

  **********************************************************************************************************/  
  
    PROCEDURE procedure_2602       AS
    any_12752        schema_767.dataset_6044;
    any_12753        cursor_2515;
    any_12300        VARCHAR2(1);
    BEGIN
        package_435.method_4938(argument_01            => '#####'
                                                   ,argument_05            => '#############'
                                                   ,argument_3700          => column_16152
                                                   );
        FETCH any_12752        INTO any_12753;
        IF column_16152%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3523;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2603       AS
    any_12752        schema_767.dataset_6044;
    any_12753        cursor_2515;
    any_12300        VARCHAR2(1);
    BEGIN
        package_435.method_4938(argument_01            => '#####'
                                                   ,argument_05            => '#############'
                                                   ,argument_3700          => column_16152
                                                   );
        FETCH any_12752        INTO any_12753;
        IF column_16152%NOTFOUND THEN
            method_4621      := dataset_16.column_53;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);
    END function_3524;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------
    
    PROCEDURE procedure_2604      AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_1177(argument_01            => '#####'
                                                                      ,argument_2809          => '######'
                                                                      ,argument_3007          => '#'
                                                                      ,argument_05            => '#############'
                                                                      ,argument_3008          => '###'
                                                                      );
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3525;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2605      AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_1177(argument_01            => '#####'
                                                                      ,argument_2809          => '############-######'
                                                                      ,argument_3007          => '#'
                                                                      ,argument_05            => '###########'
                                                                      ,argument_3008          => '####'
                                                                      );
        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);
    END function_3526;
    
-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------
  
    PROCEDURE procedure_2606                AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_721(argument_01              =>  '#####'
                                                                      ,argument_1643            =>  '#'
                                                                      ,argument_3701            =>  '####'
                                                                      ,argument_3000            =>  '#'
                                                                      ,argument_2984            =>  '#'
                                                                       );
         schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3527;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2607                AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_721(argument_01              =>  '#####'
                                                                      ,argument_1643            =>  '##'
                                                                      ,argument_3701            =>  '#'
                                                                      ,argument_3000            =>  null
                                                                      ,argument_2984            =>  '#'
                                                                       );
        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);   
    END function_3528;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2608                 AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_721(argument_01              =>  '#####'
                                                                      ,argument_1643            =>  '#'
                                                                      ,argument_3701            =>  '####'
                                                                      ,argument_3000            =>  '#'
                                                                      ,argument_2984            =>  '#'
                                                                       );
         schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3529;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2609                 AS
    any_12300        VARCHAR2(1);
    BEGIN
        method_4621      := package_435.package_function_721(argument_01              =>  '#####'
                                                                      ,argument_1643            =>  '##'
                                                                      ,argument_3701            =>  '#'
                                                                      ,argument_3000            =>  null
                                                                      ,argument_2984            =>  '#'
                                                                       );
        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);   
    END function_3530;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2610                 AS
    any_12300        DATE;
    any_2053 DATE := '##.##.##';
    BEGIN
        method_4621      := package_435.package_function_685(argument_01            => '#####'
                                                                               ,argument_05            => '#############'
                                                                               ,argument_200           => '#########'
                                                                               ,argument_556           => '#'
                                                                                );
        schema_442.package_428.method_2199(trunc(column_3869)).any_4188(trunc(column_15535));
    END function_3531;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2611                AS
    any_12300        DATE;
    any_2053 DATE := '##.##.##';
    BEGIN
        method_4621      := package_435.package_function_1178(argument_01            => '#####'
                                                                             ,argument_05            => '#############'
                                                                             ,argument_200           => '############'
                                                                             ,argument_556           => '#'
                                                                            );
        schema_442.package_428.method_2199(trunc(column_3869)).any_4188(trunc(column_15535));
    END function_3532;


-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2612               AS
    any_12300        DATE;
    any_2053 DATE := '##.##.##';
    BEGIN
        method_4621      := package_435.package_function_1178(argument_01             => '#####'
                                                                             ,argument_05            => '#############'
                                                                             ,argument_200           => '##_####'
                                                                             ,argument_556           => '##'
                                                                            );
        schema_442.package_428.method_2199(trunc(column_3869)).any_4188(trunc(column_15535));
    END function_3533;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2613    AS
    any_12300        schema_435.dataset_4892%TYPE;
    BEGIN
        method_4621      := package_435.package_function_1179(argument_01            => '#####'
                                                                       ,argument_05            => '#############'
                                                                        );
        schema_442.package_428.method_2199(2449).any_4188(column_15535);
    END function_3534;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2614              AS
    any_12300        VARCHAR(2);
    any_12754                  schema_767.dataset_5786;
    any_12755                  schema_767.dataset_5787;
    BEGIN
        package_435.method_4547(argument_01                => '#####'
                                                           ,argument_05                => '#############'
                                                           ,argument_200               => '##-#########-##-##'
                                                           ,argument_556               => '#'
                                                           ,argument_3507              => column_16153
                                                           );
        FETCH any_12754                  INTO any_12755;
        IF column_16153%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3535;
    
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2615              AS
    any_12300        VARCHAR(2);
    any_12754                   schema_767.dataset_5786;
    any_12755                   schema_767.dataset_5787;
    BEGIN
        package_435.method_4547(argument_01                => '#####'
                                                           ,argument_05                => '#############'
                                                           ,argument_200               => '##-#########-##-##'
                                                           ,argument_556               => '#'
                                                           ,argument_3507              => column_16153
                                                           );
        FETCH any_12754                  INTO any_12755;
        IF column_16153%NOTFOUND THEN
            method_4621      := dataset_16.column_53;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);
    END function_3536;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2616 AS
    any_12300        VARCHAR(50);
    any_12756            schema_767.dataset_5779;
    any_1882     cursor_2516;
    BEGIN
        package_435.method_4939(argument_01            => '#####'
                                          ,argument_05            => '#############'
                                          ,argument_3702          => column_16154
                                          );
        FETCH any_12756           INTO any_1882;
        IF column_16154%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3537;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2617              AS
    any_12300        VARCHAR(2);
    any_12756            schema_767.dataset_5779;
    any_12757        schema_767.dataset_6045;
    BEGIN
        package_435.method_4940(argument_01            => '#####'
                                                         ,argument_05            => '#############'
                                                         ,argument_19            => trunc(SYSDATE)
                                                         ,argument_3702          => column_16154
                                                         );
        FETCH any_12756           INTO any_12757;
        IF column_16154%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3538;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2618              AS
    any_12300        VARCHAR(2);
    any_12756            schema_767.dataset_5779;
    any_12757        schema_767.dataset_6045;
    BEGIN
        package_435.method_4940(argument_01            => '#####'
                                                         ,argument_05            => '#############'
                                                         ,argument_19            => trunc(SYSDATE)
                                                         ,argument_3702          => column_16154
                                                         );
        FETCH any_12756           INTO any_12757;
        IF column_16154%NOTFOUND THEN
            method_4621      := dataset_16.column_53;
        END IF;
        
    END function_3539;
    
-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2619         AS
    any_12300        VARCHAR(2);
    any_12758                schema_767.dataset_6046;
    any_12759                cursor_2517;
    BEGIN
        package_435.method_4941(argument_01              => '#####'
                                                  ,argument_05              => '#############'
                                                  ,argument_3703            => column_16155
                                                  );
        FETCH any_12758                INTO any_12759;
        IF column_16155%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
     schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3540;   

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2620         AS
    any_12300        VARCHAR(2);
    any_12758                schema_767.dataset_6046;
    any_12759                cursor_2517;
    BEGIN
        package_435.method_4941(argument_01              => '#####'
                                                  ,argument_05              => '#############'
                                                  ,argument_3703            => column_16155
                                                  );
        FETCH any_12758                INTO any_12759;
        IF column_16155%NOTFOUND THEN
            method_4621      := dataset_16.column_53;
        END IF;
        
     schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);
    END function_3541;   

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2621        AS
    any_12300        VARCHAR(2);
    any_12760                   schema_767.dataset_6047;
    any_12761                   schema_767.dataset_6048;
    BEGIN
        package_435.method_4942(argument_01                => '#####'
                                                   ,argument_3704              => column_16156
                                                   );
        FETCH any_12760                  INTO any_12761;
        IF column_16156%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3542;   

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2622 AS
    any_12300        VARCHAR(2);
    any_12762     schema_767.dataset_6049;
    any_12763     schema_767.dataset_6050;
    BEGIN
        package_435.method_4943(argument_01            => '#####'
                                           ,argument_1524           => column_16157
                                            );
        FETCH any_12762    INTO any_12763;
        IF column_16157%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3543;  

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2623        AS
    any_12300        VARCHAR(2);
    any_12764              schema_767.dataset_6051;
    any_12765              schema_767.dataset_6052;
    BEGIN
        package_435.method_4944(argument_01                    => '#####'
                                                   ,argument_05                    => '#############'
                                                   ,argument_2809                  => '######'
                                                   ,argument_3701                  => '####-#####'
                                                   ,argument_3705                  => '##.##.##'
                                                   ,argument_3706                  => '##.##.##'
                                                   ,argument_150                   => '#######'
                                                   ,argument_3707                  => '##.##.##'
                                                   ,argument_3708                  => '##.##.##'
                                                   ,argument_3709                  => '##.##.##'
                                                   ,argument_3710                  => '##.##.##'
                                                   ,argument_1923                  => '###'
                                                   ,argument_3711                  => '#'
                                                   ,argument_720                   => '#######'
                                                   ,argument_3712                  => column_16158
                                                   );
        FETCH any_12764             INTO any_12765;
        IF column_16158%NOTFOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3544;  

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2624             AS
    any_12300        VARCHAR(2);
    any_12766                   schema_767.dataset_6053;
    any_12767                   schema_767.dataset_6054;
    BEGIN
        package_435.method_4945(argument_01                 => '#####'
                                                        ,argument_2809               => '######'
                                                        ,argument_3007               => '#'
                                                        ,argument_05                 => '#############'
                                                        ,argument_3008               => '###'
                                                        ,argument_3713               => column_16159
                                                        );
        FETCH any_12766                  INTO any_12767;
        IF column_16159%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3545; 

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2625          AS
    any_12300        VARCHAR(2);
    any_12768                schema_767.dataset_6055;
    any_12769                schema_767.dataset_6056;
    BEGIN
        package_435.method_4946(argument_01             => '#####'
                                                     ,argument_2899           => column_16160
                                                     );
        FETCH any_12768               INTO any_12769;
        IF column_16160%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3546;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2626   AS
    any_12300        NUMBER;
    BEGIN
        method_4621      := package_435.package_function_1180(argument_01            => '#####'
                                                                  ,argument_200           => '##-#########-##-##'
                                                                  ,argument_09              => '###-###-###-####'
                                                                  ,argument_928           => '#####'
                                                                  ,argument_2983          => '#'
                                                                  ,argument_2984          => '#'
                                                                  );

        schema_442.package_428.method_2199(100).any_4188(column_15535);
    END function_3547;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2627 AS
    any_12300        VARCHAR(2);
    BEGIN
        method_4621      := package_435.package_function_1181(argument_01            => '#####'
                                                              ,argument_2983          => '####'
                                                              );

        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3548;
    
-- -----------------------------------------------------------------------------------------------------------------------------    
    
    PROCEDURE procedure_2628 AS
    any_12300        VARCHAR(2);
    BEGIN
        method_4621      := package_435.package_function_1181(argument_01            => '#####'
                                                              ,argument_2983          => '####'
                                                              );

        schema_442.package_428.method_2199(dataset_16.column_53).any_4188(column_15535);
    END function_3549;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2629              AS 
    any_12300        NUMBER;
    BEGIN
        method_4621      := package_435.package_function_1182(argument_01            => '#####'
                                                                               ,argument_05            => '#############'
                                                                               ,argument_200           => '##########'
                                                                               ,argument_556           => '#'
                                                                               );
        
        schema_442.package_428.method_2199(0).any_4188(column_15535);
    END function_3550;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2630                AS 
    any_12300        NUMBER;
    BEGIN
        method_4621      := package_435.package_function_1183(argument_01            => '#####'
                                                                               ,argument_3714          => '##############+###'
                                                                               ,argument_1990               => '####'
                                                                               );
                                                                        
        schema_442.package_428.method_2199(9).any_4188(column_15535);
    END function_3551;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2631           AS
    any_12300        VARCHAR(2);
    any_12770                 schema_767.dataset_6057;
    any_12771                 schema_767.dataset_6058;
    BEGIN
        package_435.method_4947(argument_01              => '#####'
                                                      ,argument_3715            => column_16161
                                                      );
        FETCH any_12770                INTO any_12771;
        IF column_16161%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
        
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3552;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2632                   AS
    any_12103                       schema_435.dataset_5778%TYPE;
    BEGIN
        package_435.method_4531(argument_01                     => '#####'
                                                           ,argument_08                        => '#######'
                                                           ,argument_2983                      => '####'
                                                           ,argument_3009                   => column_15225
                                                           );
        
        schema_442.package_428.method_2199(dataset_16.column_3010).any_4188(column_15225);
    END function_3553;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2633                AS
    any_12103                       schema_435.dataset_5778%TYPE;
    BEGIN
        package_435.method_4531(argument_01                    => '#####'
                                                           ,argument_08                       => '####'
                                                           ,argument_2983                     => '####'
                                                           ,argument_3009                  => column_15225
                                                           );
        
        schema_442.package_428.method_2199(dataset_16.column_12938).any_4188(column_15225);
    END function_3554;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2634       AS
    any_12772      schema_435.dataset_1233%TYPE;
    BEGIN
        package_435.method_4948(argument_01            => '#####'
                                                  ,argument_2809          => '######'
                                                  ,argument_3007            => '#'
                                                  ,argument_05            => '#############'
                                                  ,argument_3008          => '###'
                                                  ,argument_711           => column_16162
                                                  );
                                                       
        schema_442.package_428.method_2199('######').any_4188(column_16162);
    END function_3555;

-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2635            AS
    any_12772      schema_435.dataset_1233%TYPE;
    BEGIN
        package_435.method_4948(argument_01            => '#####'
                                                  ,argument_2809          => '#############-######'
                                                  ,argument_3007            => '#'
                                                  ,argument_05            => '#########'
                                                  ,argument_3008          => '#'
                                                  ,argument_711           => column_16162
                                                  );
                                                       
        schema_442.package_428.method_2199('').any_4188(column_16162);
    END function_3556;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

    PROCEDURE procedure_2636        AS
    any_12300        VARCHAR(2);
    any_12773                  schema_767.dataset_6059;
    any_12774                  cursor_2518;
    
    BEGIN
        package_435.method_4949(argument_01              => '#####'
                                                  ,argument_2809             => '#############-######'
                                                  ,argument_3007               => '#'
                                                  ,argument_05               => '#############'
                                                  ,argument_3008             => '##'
                                                  ,argument_3716             => column_16163
                                                  );
        
        FETCH any_12773                 INTO any_12774;
        IF column_16163%FOUND THEN
            method_4621      := dataset_16.column_54;
        END IF;
                                                       
        schema_442.package_428.method_2199(dataset_16.column_54).any_4188(column_15535);
    END function_3557;

-- -----------------------------------------------------------------------------------------------------------------------------
-- -----------------------------------------------------------------------------------------------------------------------------

END package_911;