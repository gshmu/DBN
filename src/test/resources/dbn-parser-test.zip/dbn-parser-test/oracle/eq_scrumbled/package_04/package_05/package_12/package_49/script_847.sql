
--### *********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###
--###  #### #### : #####_########_#####_##.###
--###
--###  ########  : ########
--###  ######    : ###
--###
--###  ####                 ########
--### *********************************************************************
--###  ##.##.#### ##:##:##  ####### ######## #### ########## ####### ########
--###
--### *********************************************************************



DECLARE
BEGIN
   FOR cursor_82 IN (SELECT column_741,
                      column_742,
                      column_743,
                      column_744,
                      column_11008,
                      column_2884,
                      column_745,
                      column_746,
                      column_747,
                      column_748
                 FROM schema_57.dataset_352)
   LOOP
      BEGIN
         INSERT INTO dataset_353 (column_741,
                            column_742,
                            column_743,
                            column_744,
                            column_11008,
                            column_2884,
                            column_745,
                            column_746,
                            column_747,
                            column_748)
              VALUES (dataset_354.column_741,
                      dataset_354.column_742,
                      dataset_354.column_743,
                      dataset_354.column_744,
                      dataset_354.column_11008,
                      dataset_354.column_2884,
                      dataset_354.column_745,
                      dataset_354.column_746,
                      dataset_354.column_747,
                      dataset_354.column_748);
      EXCEPTION
         WHEN DUP_VAL_ON_INDEX
         THEN
            UPDATE dataset_353
               SET column_742 = dataset_354.column_742,
                   column_743 = dataset_354.column_743,
                   column_744 = dataset_354.column_744,
                   column_11008 = dataset_354.column_11008,
                   column_2884 =
                      dataset_354.column_2884,
                   column_745 = dataset_354.column_745,
                   column_746 = dataset_354.column_746,
                   column_747 = dataset_354.column_747,
                   column_748 = dataset_354.column_748
             WHERE column_741 = dataset_354.column_741;
      END;
      BEGIN
         INSERT INTO dataset_355 (column_741,
                                  column_749)
              VALUES (dataset_354.column_741,
                      '###_#####');
      EXCEPTION
         WHEN DUP_VAL_ON_INDEX
         THEN
           NULL;
      END;
   END LOOP;

   DELETE dataset_356
    WHERE (column_741, column_750) IN (SELECT column_741, column_750 
                                         FROM schema_57.dataset_357      
                                        WHERE column_751 = '#');

   FOR cursor_82 IN (SELECT column_750, column_741
                 FROM schema_57.dataset_357      
                WHERE column_751 = '#')
   LOOP
      BEGIN
         INSERT INTO dataset_356 (column_750, column_741)
              VALUES (dataset_354.column_750, dataset_354.column_741);
      EXCEPTION
         WHEN DUP_VAL_ON_INDEX
         THEN
            NULL;
      END;
   END LOOP;
END;
/


COMMIT
/