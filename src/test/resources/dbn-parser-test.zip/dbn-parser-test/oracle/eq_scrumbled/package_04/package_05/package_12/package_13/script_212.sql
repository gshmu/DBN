--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : ####_#_####_##############.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.
--###  ##.#.#  ##.##.#### ########	         ###-###
--### *********************************************************************/




CREATE OR REPLACE FORCE VIEW view_02
 (
     column_07,
     column_354,
     column_1317,
     column_4344,
     column_4345,
     column_4346,
     column_1287,
     column_1288,
     column_1289,
     column_1290,
     column_204,
     column_609,
     column_229,
     column_610,
     column_06
     )
 AS
     SELECT  dataset_1735.column_07,
             dataset_1735.column_354,
             dataset_1735.column_1317,
             dataset_1735.column_4344,
             dataset_1735.column_4345,
             dataset_1735.column_4346,
             dataset_1735.column_1287,
             dataset_1735.column_1288,
             dataset_1735.column_1289,
             dataset_1735.column_1290,
             dataset_1735.column_204,
             dataset_1735.column_609,
             dataset_1735.column_229,
             dataset_1735.column_610,
             dataset_1735.column_06       
       FROM dataset_1736        dataset_1735
      WHERE dataset_1735.column_354 = SYS_CONTEXT ('###_#######_###', '#######')
/

COMMIT
/






