--### /********************************************************************
--###  #### ####   : ####_##_##_#_########_###_########_####.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####      ###-##### ### ####### (######## ### ######## ####)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_70                     
AS
    -- ########_#####
    SELECT dataset_67.column_544,
           dataset_67.column_4605,
           dataset_67.column_4608,
           dataset_67.column_4606,
           dataset_67.column_5819,
           '########_#####' AS column_25061,
           dataset_8552.column_25062,
           dataset_8552.column_1640,
           NULL AS column_2316,
           dataset_8552.column_5817,
           dataset_8552.column_5818,
           NULL AS column_25063,
           NULL AS column_25064,
           NULL AS column_25065,
           NULL AS column_25066,
           NULL AS column_25067,
           NULL AS column_25068,
           NULL AS column_25069,
           NULL AS column_25070,
           NULL AS column_25071                                      
      FROM dataset_1849           dataset_67,
           JSON_TABLE ( dataset_67.column_5819, '$.######' COLUMNS (
                    column_25062            VARCHAR2(100) PATH '$.#####################',
                    NESTED PATH '$.##############[*]' COLUMNS(
                            column_1640   VARCHAR2(2) PATH '$.###########',
                            column_532    VARCHAR2(3) PATH '$.############',
                            NESTED PATH '$.##########.####################[*]' COLUMNS (
                                    column_5817   VARCHAR2(7) PATH '$.############',
                                    column_5818   NUMBER PATH '$.############')))) dataset_8552,
           dataset_476 dataset_104
     WHERE dataset_104.column_213 = dataset_8552.column_1640 
       AND dataset_8552.column_5817   LIKE dataset_8552.column_532   ||'%'

    -- #######_#####
    UNION ALL
    SELECT dataset_67.column_544,
           dataset_67.column_4605,
           dataset_67.column_4608,
           dataset_67.column_4606,
           dataset_67.column_5819,
           '#######_#####' AS column_25061,
           dataset_8552.column_25062,
           dataset_8552.column_1640,
           NULL AS column_2316,
           NULL AS column_5817,
           NULL AS column_5818,
           dataset_8552.column_25063,
           dataset_8552.column_25064,
           dataset_8552.column_25065,
           NULL AS column_25066,
           NULL AS column_25067,
           NULL AS column_25068,
           NULL AS column_25069,
           NULL AS column_25070,
           NULL AS column_25071                                      
      FROM dataset_1849           dataset_67,
           JSON_TABLE ( dataset_67.column_5819, '$.######' COLUMNS (
                    column_25062            VARCHAR2(100) PATH '$.#####################',
                    NESTED PATH '$.##############[*]' COLUMNS(
                            column_1640   VARCHAR2(2) PATH '$.###########',
                            column_532    VARCHAR2(3) PATH '$.############',
                            NESTED PATH '$.##########' COLUMNS (
                                    column_25063                                 NUMBER PATH '$.##########################',
                                    column_25064                                 NUMBER PATH '$.#############################',
                                    column_25065                                 NUMBER PATH '$.#####################################')))) dataset_8552 
    -- ######_#####
    UNION ALL
    SELECT dataset_67.column_544,
           dataset_67.column_4605,
           dataset_67.column_4608,
           dataset_67.column_4606,
           dataset_67.column_5819,
           '######_#####' AS column_25061,
           dataset_8552.column_25062,
           dataset_8552.column_1640,
           dataset_8552.column_2316,
           NULL AS column_5817,
           NULL AS column_5818,
           NULL AS column_25063,
           NULL AS column_25064,
           NULL AS column_25065,
           dataset_8552.column_25066,
           dataset_8552.column_25067,
           NULL AS column_25068,
           NULL AS column_25069,
           NULL AS column_25070,
           NULL AS column_25071                                      
      FROM dataset_1849           dataset_67,
           JSON_TABLE ( dataset_67.column_5819, '$.######' COLUMNS (
                    column_25062            VARCHAR2(100) PATH '$.#####################',
                    NESTED PATH '$.##############[*]' COLUMNS(
                            column_1640   VARCHAR2(2)   PATH '$.###########',
                            column_532    VARCHAR2(3)   PATH '$.############',
                            NESTED PATH '$.###########[*]' COLUMNS (
                                    column_2316   VARCHAR2(100) PATH '$.##########',
                                    column_25066                           NUMBER PATH '$.############################',
                                    column_25067                           NUMBER PATH '$.#################################')))) dataset_8552 
     WHERE dataset_8552.column_2316 IS NOT NULL

     -- ######_#####
    UNION ALL
    SELECT dataset_67.column_544,
           dataset_67.column_4605,
           dataset_67.column_4608,
           dataset_67.column_4606,
           dataset_67.column_5819,
           '######_#####' AS column_25061,
           dataset_8552.column_25062,
           dataset_8552.column_1640,
           NULL AS column_2316,
           NULL AS column_5817,
           NULL AS column_5818,
           NULL AS column_25063,
           NULL AS column_25064,
           NULL AS column_25065,
           NULL AS column_25066,
           NULL AS column_25067,
           dataset_8552.column_25068,
           dataset_8552.column_25069,
           dataset_8552.column_25070,
           dataset_8552.column_25071                                      
      FROM dataset_1849           dataset_67,
           JSON_TABLE ( dataset_67.column_5819, '$.######' COLUMNS (
                    column_25062            VARCHAR2(100) PATH '$.#####################',
                    NESTED PATH '$.##############[*]' COLUMNS(
                            column_1640   VARCHAR2(2) PATH '$.###########',
                            column_532    VARCHAR2(3) PATH '$.############',
                            column_25068                                        NUMBER PATH '$.#########.#####################',
                            column_25069                                        NUMBER PATH '$.#########.##################################',
                            column_25070                                        NUMBER PATH '$.#########.############################################',
                            column_25071                                        NUMBER PATH '$.#########.#############################################'))) dataset_8552
/
