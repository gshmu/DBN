--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : ####_#_#####_####_#######.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ######### ###### (##### #### ####### ####)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_80             
AS
    SELECT dataset_461.column_3118,
           dataset_461.column_3119,
           dataset_333.column_2985  
      FROM dataset_2485 dataset_461,
           dataset_2483      dataset_2484,
           dataset_315    dataset_86,
           dataset_276 dataset_275,
           dataset_336 dataset_333
     WHERE dataset_461.column_3118 = dataset_2484.column_3118   
       AND dataset_2484.column_598 = dataset_86.column_598
       AND (dataset_2484.column_714    IS NULL OR dataset_2484.column_714 = dataset_275.column_714) 
       AND (dataset_2484.column_1446         IS NULL OR dataset_2484.column_1446 = dataset_275.column_1446) 
       AND dataset_86.column_451 = dataset_333.column_451      
       AND dataset_275.column_11 = dataset_333.column_11
/
