--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : ####_##_###_######_############.###
--###
--###  ####### ####       ###               ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######           ##/###### ######
--###  ####### ##.#
--### *********************************************************************/












--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####


CREATE OR REPLACE FORCE VIEW view_85
(
   column_19111,
   column_2840,
   column_19072,
   column_2831,
   column_19112,
   column_19073,
   column_615,
   column_2856,
   column_19160,
   column_19113,
   column_19161,
   column_19162,
   column_19078,
   column_5498,
   column_19086,
   column_19087,
   column_19084,
   column_19088,
   column_19089,
   column_742,
   column_19103,
   column_19104,
   column_19105,
   column_19114,
   column_738,
   column_3331,
   column_1309,
   column_354,
   column_19080,    
   column_19115,  
   column_19116, 
   column_19083,   
   column_19085, 
   column_5245,       
   column_19079,
   column_14328,
   column_14327
)
AS
   SELECT   column_19111,
            column_2840,
            column_19072,
            column_2831,
            column_19112,
            column_19073,
            column_615,
            column_2856,
            column_19160,
            column_19113,
            column_19161,
            column_19162,
            column_19078,
            column_5498,
            column_19086,
            column_19087,
            column_19084,
            column_19088,
            column_19089,
            column_742,
            column_19103,
            column_19104,
            column_19105,
            column_19114,
            column_738,
            column_3331,
            column_1309,
            column_354,
            column_19080,    
            column_19115,  
            column_19116, 
            column_19083,   
            column_19085, 
            column_5245,       
            column_19079,
            column_14328,
            column_14327
     FROM   dataset_7025       
    WHERE   column_354 = SYS_CONTEXT ('###_#######_###', '#######')
/

COMMIT
/
      





