/******************************************************************************
    ##### #####: ########_####_#######
    #########:   ########_####
    ########:    ####### (###_#######)
    ######### #### ####### ##### ### ######## #### ##### (####### ##### - ##### #########)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### #### (###########)
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_####                      ###### ####
        - #########                        #########
        - ########_#########               ######## #########
        - ########_#########               ######## #########
        - ####                             ####
        - ###########_####                 ########### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #######                          #######
        - ####_#####                       #### #####
        - #######_####                     ####### ####
        - ####_####_#                      #### #### #
        - ####_#####                       #### #####
        - ####_#####                       #### #####
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - ####_####                        #### ####
        - ####_###                         #### ###
        - #####_######                     ##### ######
        - ####_######                      #### ######
        - #######                          #######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####


    ###### ## ###########:  ##(######## ####)||###(#######)||<####### ##### ##>||<#########>||<####.########_####_###########_##>

    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ####### #####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##
    ##.#.#    ##.##.####   ##### ###### ###-##### : ######### #######
    ##.#.#    ##.##.####   ### #####    ###-##### / ###-##### ########## #####
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ########### ####### #############
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ####### #### ### ####
    ##.#.#    ##.##.####   ### #####    ###-##### ######## #####
    ###### ##.#
    ##.#.#    ##.##.####   ##### #####  ###-##### ####### #### ## ## ######### ## ####### ####### ##### ####### 
*******************************************************************************/

SELECT
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_1056,
    NULL AS column_7074,
    column_7075,
    column_7076,
    column_7077,
    NULL AS column_5861,
    NULL AS column_7079,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_7082,
    column_7083,
    column_874,
    NULL AS column_7084,
    column_7085,
    column_1477,
    NULL AS column_549,
    NULL AS column_7086,
    NULL AS column_7087,
    NULL AS column_563,
    NULL AS column_7088,
    NULL AS column_7089,
    NULL AS column_7090,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    column_18107,
    NULL AS column_7104,
    column_753,
    NULL AS column_18108,
    column_7105,
    column_534,
    NULL AS column_7106,
    NULL AS column_7107,
    NULL AS column_7108,
    NULL AS column_7109,
    NULL AS column_7110,
    NULL AS column_7111,
    NULL AS column_7112,
    NULL AS column_7113,
    NULL AS column_7114
FROM (
    WITH dataset_949                            as (
        SELECT /*+ ########### */ dataset_950.column_76     
          FROM dataset_951                      dataset_950
              ,dataset_15 dataset_104
         WHERE column_2345 = 
           AND dataset_104.column_354 = 
           AND DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),
    dataset_260      AS (
        SELECT   /*+ ########### */
               column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
    dataset_6755    AS (
                SELECT   /*+ ########### */ DISTINCT
                     dataset_230.column_527                  as column_527
                    ,dataset_230.column_528                  as column_528
                    ,dataset_230.column_532                  as column_532
                    ,dataset_230.column_724                  as column_724
                    ,dataset_230.column_533                  as column_533  
                FROM dataset_231          dataset_230
                WHERE column_533 = '######'
                ),
     dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = ),
      dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = ),
                               
            dataset_1573 
            AS (select /*+ ##### (###_#########_########_#### ##_###_##) ########### */  
                    *
                  from dataset_1057               
                  where 1=1
                    -- ###### ###### / ####### ######
                    AND column_204 > 
                    AND column_204 <= 
                    AND column_354=),
           dataset_6756   AS
            (select dataset_1578.column_567,dataset_1573.column_2427                 
             from   dataset_1579              dataset_1578, 
                    dataset_1060          dataset_1585,
                    dataset_1573
            where   dataset_1573.column_2427 = dataset_1585.column_2427                 
                    and dataset_1585.column_148=dataset_1578.column_148          
                    and dataset_1573.column_1058='####-##-############-##-##'
                    AND dataset_1578.column_1058='#####_###_######'
                    and dataset_1578.column_354=)
        -- ##### ########
        SELECT /*+ ##### (#### ##_###_##) */ dataset_104.column_354                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            CASE WHEN dataset_1573.column_1058  in('######_######_#####','######_####_#####') THEN
            package_131.package_function_135(dataset_1573.column_2430,dataset_2726.column_2344,dataset_962.column_2354) 
            ELSE
            package_131.package_function_134(dataset_1573.column_2400,dataset_1573.column_2401,dataset_1573.column_2396,dataset_2726.column_2344)
            END                                                                                   AS column_1328,
            CASE WHEN dataset_1573.column_1058='####-##-############-##-##' 
                THEN MAX(TO_CHAR(dataset_6757.column_567, '##/##/####')) 
                ELSE TO_CHAR(dataset_1573.column_899, '##/##/####') 
           END                                                                                     AS column_1056,
         CASE
            -- #######-##
            WHEN dataset_1573.column_1058 = '#######-##'
                AND max(column_5216) = '######' THEN
                CASE WHEN max(dataset_1585.column_76) IN ('###_##','###_##','###_##')
                 THEN '########: #### #### ## ########'
                 ELSE '########: #### ######## ## ########'
                END
                           
            WHEN dataset_1573.column_1058 = '#######-##' 
                AND max(column_5216) = '###########' THEN
                CASE WHEN max(dataset_1585.column_76) IN ('###_##','###_##','###_##')
                    THEN '#### #######:[' || max(dataset_1585.column_07) || ']'
                    ELSE '#######:[' || max(dataset_1585.column_07) || ']'
                END

            WHEN dataset_1573.column_1058 = '#######-##'
                AND max(column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734
            
             WHEN dataset_1573.column_1058 = '#######-##' 
                AND max(column_5216) = '####' THEN
                '#### ########### #######'
                
            -- ###-##
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(column_5216) IN ('######', '###_######')
            THEN '########: ########## ## ###'
            
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(column_5216) = '####' THEN
                '#### ####### #######'
           
            WHEN dataset_1573.column_1058 = '###-##'
                AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) NOT IN ('######', '###_######'))
            THEN '#######: ## '|| dataset_1573.column_734
            
            --#######_#######_##
            WHEN dataset_1573.column_1058 = '#######-#######-##'
                AND max(dataset_1585.column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734
            
            WHEN dataset_1573.column_1058 = '#######-#######-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######: ## '||  max(dataset_1585.column_07)
            
            -- ####-##
            WHEN dataset_1573.column_1058 = '####-##'
            THEN '########: ########## ## ####'

              -- ##-###-##
            WHEN dataset_1573.column_1058 = '##-###-##'
            THEN '########: ########## ## ## ###'
            
            -- ########## ## ####### ###
            WHEN dataset_1573.column_1058 = '#######-###-##'
            THEN '########:  ########## ## ####### ###'
            
            -- ###-##
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
            THEN '########: ######## ## ####'
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
            THEN '########: ########## ## ####'
            --##########-###-##
            WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
            THEN '########: ######## ## ##########'
            WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
            THEN '########: ########## ## ##########'

            --###-###-###########-## ### ###-###########-###########-##
            WHEN dataset_1573.column_1058  IN ('###-###-###########-##','###-###########-###########-##')
            THEN '########: ######## ## ######## ###'
            
            -- ########-##
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '########'
            THEN '########: ########## ## ########'
            WHEN dataset_1573.column_1058 = '########-##'
                AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) <> '########')
            THEN '########: ######## ## ##########'

            -- ######-#########-####-##
            WHEN dataset_1573.column_1058 = '######-#########-####-##'
            THEN '##########:#### #######'

            -- ####-##-##########
            WHEN dataset_1573.column_1058 = '####-##-##########'
            THEN
                CASE
                    WHEN max(dataset_1585.column_76) IN ('###_##','###_##','###_##') 
                    THEN '########: #### #### ## ########'
                    ELSE '########: ## ######## #######'
                END

            -- ######-##
            WHEN dataset_1573.column_1058 = '######-##'
                AND max(dataset_1585.column_76) IN ('###_##','###_##','###_##') 
            THEN '#### ########: ###### ####'

            -- #####-#######-##
            WHEN dataset_1573.column_1058 = '#####-#######-##' THEN
             CASE
                WHEN max(dataset_1585.column_76) IN ('###_##','###_##','###_##') 
                    THEN '####### #### #######:[' || max(dataset_1585.column_07) || ']'
                    ELSE '#######:[' || max(dataset_1585.column_07) || ']'
             END

            -- #####-########-##
            WHEN dataset_1573.column_1058 = '#####-########-##'
            THEN '#######:[' || max(dataset_1585.column_07) || ']'

            -- ########-##
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '######'
            THEN '########: ######## ## ########'
            
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######:[' || max(dataset_1585.column_07) || ']'
            
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '####'
            THEN '#### ######## #######'

            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734
            
            --####-########-####-##
            WHEN dataset_1573.column_1058 = '####-########-####-##'
                AND max(dataset_1585.column_5216) = '######'
            THEN '########: ########(#### ########) ## ########'

            WHEN dataset_1573.column_1058 = '####-########-####-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######: '||max(dataset_1585.column_07)
            
            --#####-####-########-####-##
             WHEN dataset_1573.column_1058 = '#####-####-########-####-##'
            THEN '#######: '||max(dataset_1585.column_07)
            
            -- ######-####-##
            WHEN dataset_1573.column_1058 = '######-####-##' 
            THEN '#### ## : #### ######## ## ' || max(dataset_2733.column_2348)
            
            --########-############-##
            WHEN dataset_1573.column_1058  in ('########-############-##','########-############-##-##')
            THEN '############# : ############ ## #########'
            
            --####-##-########-##
            WHEN dataset_1573.column_1058 = '####-##-########-##' AND max(dataset_1585.column_1064) = '###########_############'
            THEN '######## : ######### ## ########'
            WHEN dataset_1573.column_1058 = '####-##-########-##' AND max(dataset_1585.column_1064) = '########_#######'
            THEN '######## : ######## ## ########'
            
            --########-########-####-##
            WHEN dataset_1573.column_1058 = '########-########-####-##'
            THEN '#######: ## '|| max(dataset_1585.column_734)
            
            --########-######-#######-##
            WHEN dataset_1573.column_1058 = '########-######-#######-##'
            THEN '#######: ## '|| max(dataset_1585.column_734)
            
            WHEN dataset_1573.column_1058 = '#####-##' 
            THEN '######## : #### #### ## #########' 
            
            WHEN dataset_1573.column_1058 = '####-##-############-##-##'
            THEN '#### ######## ## ## ########## #######'
            
            WHEN dataset_1573.column_1058 = '##-######-##'
            THEN '#### ######## : ## #### ## ## #### #######'
            
            ELSE dataset_1053.column_742 
            END                                                                                   AS column_7075,

            CASE WHEN dataset_1573.column_1058  IN ('######-#########-####-##','######_######_#####','######_####_#####')
                 THEN dataset_1573.column_1050         
                 ELSE TO_CHAR(dataset_1573.column_2427)
            END                                                                                   AS column_7076,
            CASE WHEN dataset_1573.column_2440 = '#####_#####'
                  AND max(dataset_1585.column_5216) = '###########'
                 THEN NULL
                 ELSE dataset_1573.column_1318               ||dataset_1573.column_1319           
            END                                                                                   AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            NULL                                                                                  AS column_7085,
            dataset_1573.column_735                                                                           AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            CASE WHEN dataset_1573.column_1058  IN ('######_######_#####','######_####_#####')
                 THEN  CASE WHEN INSTR((dataset_1573.column_189), ';') = 0
                              THEN (dataset_1573.column_189)  
                              ELSE SUBSTR((dataset_1573.column_189), 1, INSTR((dataset_1573.column_189), ';')-1 )  
                              END
            ELSE               
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => dataset_1585.column_1064,
                    argument_680            => dataset_1585.column_5216,
                    argument_679            => dataset_6758.column_533,
                    argument_73             => dataset_259.column_76,
                    argument_1105             => function_4251(dataset_1585.column_2802, '$.########'),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2442)               
            END                                                                                   AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM /*###_#########_########_####*/ dataset_1573,
            dataset_1060          dataset_1585,
             dataset_6755    dataset_6758,
             dataset_1054        dataset_1053,
             dataset_15 dataset_104,
             dataset_260      dataset_259,
             dataset_260      dataset_2733,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726,
             dataset_959        dataset_962,
             dataset_6756   dataset_6757
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1573.column_2427 = dataset_1585.column_2427(+)
            AND dataset_1573.column_2427 = dataset_6757.column_2427(+)
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2400 = dataset_6758.column_527(+)
            AND dataset_1573.column_2401     = dataset_6758.column_528(+)
            AND dataset_1573.column_532                = dataset_6758.column_532(+)
            AND dataset_1573.column_724       = dataset_6758.column_724(+)
            AND dataset_1573.column_76 = dataset_259.column_76     
            AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
            AND dataset_259.column_76 = dataset_964.column_76     
            AND (column_2441    <> 2
                        AND dataset_1573.column_530  <> '#####_#####'
                        AND (dataset_1573.column_1058  not in ('####-######-####-##', '######-####-##', '####-##-##########-##','############-##-####-##-##') 
                        OR     (dataset_1573.column_1058 = '######-####-##' AND dataset_1573.column_2401              <> dataset_1573.column_1319)) OR
                (column_2441 = 2 
                        AND dataset_1573.column_1064 = '####'))
            and dataset_1573.column_530=dataset_2726.column_591
            and dataset_1573.column_530=dataset_962.column_591 
            and dataset_104.column_354 =dataset_2726.column_354
            and dataset_104.column_354 =dataset_962.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_1573.column_189,
            dataset_104.column_122,
            dataset_1573.column_2427,
            dataset_1573.column_734,
            dataset_1573.column_2400,
            dataset_1573.column_2401,
            dataset_1573.column_2396,
            dataset_1573.column_2430,
            dataset_1573.column_899,
            dataset_1573.column_1058,
            dataset_1573.column_2440,
            dataset_1053.column_742,
            dataset_1573.column_1050,
            dataset_1573.column_1318,
            dataset_1573.column_1319,
            dataset_1573.column_532,
            dataset_1573.column_735,
            dataset_259.column_2348,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => dataset_1585.column_1064,
                    argument_680            => dataset_1585.column_5216,
                    argument_679            => dataset_6758.column_533,
                    argument_73             => dataset_259.column_76,
                    argument_1105             => function_4251(dataset_1585.column_2802, '$.########'),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2442),
            dataset_1573.column_2442,
            dataset_2726.column_2344,
            dataset_962.column_2354  
            
         UNION ALL
          -- ###### ########
           SELECT
            dataset_104.column_354                                                                          AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            CASE WHEN dataset_1573.column_1058  in('######_######_#####','######_####_#####') THEN
            package_131.package_function_135(dataset_1573.column_2431,dataset_2726.column_2344,dataset_962.column_2354) 
            ELSE
            package_131.package_function_134(dataset_1573.column_1318,dataset_1573.column_1319,dataset_1573.column_1320,dataset_2726.column_2344)
            END                                                                                   AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            CASE
                -- #######-##
                WHEN dataset_1573.column_1058 = '#######-##'
                    AND max(column_5216) = '######' THEN
                   CASE WHEN max(dataset_1585.column_76) IN ('###_##','###_##','###_##')
                    THEN '######## : ######## #### #### ####'
                    ELSE '######## : ######## #### ##########'
                 END

                -- ###-##
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(column_5216) IN ('######', '###_######')
                THEN '########:  ### #### ##########'
                
                 --#######_#######_##
                WHEN dataset_1573.column_1058 = '#######-#######-##'
                    AND max(dataset_1585.column_5216) = '#######'
                THEN '#######: ## '|| max(dataset_1573.column_734)
                
                WHEN dataset_1573.column_1058 = '#######-#######-##'
                    AND max(dataset_1585.column_5216) = '###########'
                THEN '#######: ## '||  max(dataset_1585.column_07)
            
                -- ####-##
                WHEN dataset_1573.column_1058 = '####-##'
                THEN '########: #### #### ##########'

                -- ##-###-##
                WHEN dataset_1573.column_1058 = '##-###-##'
                THEN '########: ## ### #### ##########'                
                
                --#######-###-##
                WHEN dataset_1573.column_1058 = '#######-###-##'
                THEN '########: ####### ### #### ##########'
                
                -- ###-##
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(dataset_1585.column_1064) = '########_#######'
                THEN '########: #### #### ########'
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(dataset_1585.column_1064) <> '########_#######'
                THEN '########: #### #### ##########'
                
                --##########-###-##
                WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
                THEN '########: ########## #### ########'
                WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
                THEN '########: ########## #### ##########'

                --###-###-###########-## ### ###-###########-###########-##
                WHEN dataset_1573.column_1058  IN ('###-###-###########-##','###-###########-###########-##')
                THEN '########: ######## ### #### ########'
                
                -- ########-##
                WHEN dataset_1573.column_1058 = '########-##'
                    AND max(dataset_1585.column_5216) = '########'
                THEN '########: ######## #### ##########'
                WHEN dataset_1573.column_1058 = '########-##'
                    AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) <> '########')
                THEN '########: ########## #### ########'

                -- ######-#########-####-##
                WHEN dataset_1573.column_1058 = '######-#########-####-##'
                THEN
                    CASE
                        WHEN dataset_2733.column_76 = '###_##_###'
                        THEN '##########:####### ####### #######'
                        ELSE '##########:#### #######'
                    END    
                
                -- ####-##-##########
                WHEN dataset_1573.column_1058 = '####-##-##########'
                    THEN
                    CASE
                        WHEN dataset_2733.column_76      IN ('###_##','###_##','###_##')
                        THEN '########: ######## ####### #### #### ####'
                        ELSE '########: ######## #######'
                    END

                -- ########-##
                WHEN dataset_1573.column_1058 = '########-##'
                    AND max(dataset_1585.column_5216) = '######'
                THEN '######## : ######## #### ########'
                
                --####-########-####-## 
                WHEN dataset_1573.column_1058 = '####-########-####-##'
                    AND max(dataset_1585.column_5216) = '######'
                THEN '######## : ######## #### ########(#### ########)'
                
                -- ######-####-##
                WHEN dataset_1573.column_1058 = '######-####-##' 
                THEN '#### ## : #### ######## #### ' || dataset_6759.column_2348       
            
                --########-############-##
                WHEN dataset_1573.column_1058  in('########-############-##','########-############-##-##')
                THEN '############# : ######### #### ############'
                
                --####-##-########-##
                WHEN dataset_1573.column_1058 = '####-##-########-##'
                THEN '######## : ######## #### #########'
                
                --####-##-##########-##
                WHEN dataset_1573.column_1058 = '####-##-##########-##'
                THEN '############# : ##### #######'

                --#####-##
                WHEN dataset_1573.column_1058 = '#####-##'
                THEN '######## : ######### #### #### ####'
                
                WHEN dataset_1573.column_1058 = '############-##-####-##-##'
                THEN '#### ######## #### ## ########## #######'
                
                WHEN dataset_1573.column_1058 = '##-######-##'
                THEN '#### ######## : ## #### #### ## #### #######'
                
                ELSE dataset_1053.column_742 

            END                                                                                    AS column_7075,

            CASE WHEN dataset_1573.column_1058  IN (
                        '######-#########-####-##',
                        '######_######_#####',
                        '######_####_#####')
                 THEN dataset_1573.column_1050         
                 WHEN  dataset_1573.column_1058 = '####-##-##########-##'
                 THEN max(dataset_1585.column_734)
                 ELSE TO_CHAR(dataset_1573.column_2427)
            END                                                                                   AS column_7076,
            dataset_1573.column_2400                 ||dataset_1573.column_2401                                   AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            dataset_1573.column_735                                                                           AS column_7085,
            NULL                                                                                  AS column_1477,
            DECODE(dataset_1573.column_2440, '#####_#####',
                            dataset_6759.column_2348,
                            NVL(dataset_2733.column_2348, dataset_6759.column_2348))                  AS column_753,
            CASE WHEN dataset_1573.column_1058  IN ('######_######_#####','######_####_#####')
                 THEN              CASE WHEN INSTR((dataset_1573.column_189), ';') = 0
                                   THEN max(dataset_1573.column_189)  
                                   ELSE substr((dataset_1573.column_189), instr((dataset_1573.column_189), ';')+1 )  
                                   END
            ELSE                                   
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_####',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => dataset_1585.column_1064,
                    argument_680            => dataset_1585.column_5216,
                    argument_679            => dataset_6758.column_533,
                    argument_73             =>
                        DECODE(dataset_1573.column_2440, '#####_#####',
                              dataset_6759.column_76,
                              NVL(dataset_2733.column_76, dataset_6759.column_76)),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2443)
            END                                                                                   AS column_7105,
            dataset_1573.column_2443                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM /*###_#########_########_#### */ dataset_1573,
             dataset_1060           dataset_1585,
             dataset_1054        dataset_1053,
             dataset_6755    dataset_6758,
             dataset_15 dataset_104,
             dataset_260      dataset_6759,
             dataset_260      dataset_2733,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726,
             dataset_959        dataset_962
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1573.column_2427 = dataset_1585.column_2427(+)
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2400 = dataset_6758.column_527(+)
            AND dataset_1573.column_2401     = dataset_6758.column_528(+)
            AND dataset_1573.column_532                = dataset_6758.column_532(+)
            AND dataset_1573.column_724       = dataset_6758.column_724(+)
            AND dataset_1573.column_76 = dataset_6759.column_76     
            AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
            AND dataset_6759.column_76 = dataset_964.column_76     
            AND (dataset_1573.column_2441    <> 2
                        AND dataset_1573.column_2440            <> '#####_#####'
                        AND (dataset_1573.column_1058  not in ('####-######-####-##', '######-####-##','####-##-############-##-##')
                        OR (dataset_1573.column_1058 = '######-####-##' AND dataset_1573.column_2401              <> dataset_1573.column_1319)) OR
                 (dataset_1573.column_2441 = 2
                        AND dataset_1573.column_1064 = '###'))
            AND dataset_1573.column_2440=dataset_2726.column_591
            AND dataset_1573.column_2440=dataset_962.column_591  
            AND dataset_104.column_354 =dataset_2726.column_354
            AND dataset_104.column_354 =dataset_962.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_1573.column_189,
            dataset_104.column_122,
            dataset_1573.column_2427,
            dataset_1573.column_1318,
            dataset_1573.column_1319,
            dataset_1573.column_1320,
            dataset_1573.column_2431,
            dataset_1573.column_899,
            dataset_1053.column_742,
            dataset_1573.column_1058,
            dataset_1573.column_1050,
            dataset_1573.column_2400,
            dataset_1573.column_2401,
            dataset_1573.column_532,
            dataset_1573.column_735,
            dataset_1573.column_2443,
            dataset_1573.column_2440,
            dataset_6759.column_76,
            dataset_2733.column_76,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_####',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => dataset_1585.column_1064,
                    argument_680            => dataset_1585.column_5216,
                    argument_679            => dataset_6758.column_533,
                    argument_73             =>
                        DECODE(dataset_1573.column_2440, '#####_#####',
                              dataset_6759.column_76,
                              NVL(dataset_2733.column_76, dataset_6759.column_76)),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2443),
            dataset_6759.column_2348,
            dataset_2733.column_2348,
            dataset_6758.column_533,
            dataset_2726.column_2344,
            dataset_962.column_2354  

        -- ###### ########
        UNION ALL
        SELECT
            dataset_104.column_354                                                                          AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_1318,dataset_1573.column_1319,dataset_1573.column_1320,dataset_2726.column_2344)     AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,

            CASE
                -- #######-##
                WHEN dataset_1573.column_1058 = '#######-##'
                    AND max(column_5216) = '######'
                THEN '######## : ######## #### ##########' ||' ####### #######'

                -- ###-##
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(column_5216) IN ('######', '###_######')
                THEN '########:  ### #### ##########' ||' ####### #######'
                
                 --#######_#######_##
                WHEN dataset_1573.column_1058 = '#######-#######-##'
                    AND max(dataset_1585.column_5216) = '#######'
                THEN '#######: ## '|| max(dataset_1573.column_734)
                
                WHEN dataset_1573.column_1058 = '#######-#######-##'
                    AND max(dataset_1585.column_5216) = '###########'
                THEN '#######: ## '||  max(dataset_1585.column_07)
            
                -- ####-##
                WHEN dataset_1573.column_1058 = '####-##'
                THEN '########: #### #### ##########' ||' ####### #######'

                -- ##-###-##
                WHEN dataset_1573.column_1058 = '##-###-##'
                THEN '###: ## ### #####'                
                
                --#######-###-##
                WHEN dataset_1573.column_1058 = '#######-###-##'
                THEN '########: ####### ### #### ##########' ||' ####### #######'
                
                -- ###-##
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(dataset_1585.column_1064) = '########_#######'
                THEN '########: #### #### ########' ||' ####### #######'
                WHEN dataset_1573.column_1058 = '###-##'
                    AND max(dataset_1585.column_1064) <> '########_#######'
                THEN '########: #### #### ##########' ||' ####### #######'
                
                --##########-###-##
                WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
                THEN '########: ########## #### ########' ||' ####### #######'
                WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
                THEN '########: ########## #### ##########' ||' ####### #######'

                --###-###-###########-## ### ###-###########-###########-##
                WHEN dataset_1573.column_1058  IN ('###-###-###########-##','###-###########-###########-##')
                THEN '########: ######## ### #### ########' ||' ####### #######'                
                
                -- ########-##
                WHEN dataset_1573.column_1058 = '########-##'
                    AND max(dataset_1585.column_5216) = '########'
                THEN '########: ######## #### ##########' ||' ####### #######'
                WHEN dataset_1573.column_1058 = '########-##'
                    AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) <> '########')
                THEN '########: ########## #### ########' ||' ####### #######'

                -- ######-#########-####-##
                WHEN dataset_1573.column_1058 = '######-#########-####-##'
                THEN '##########:#### #######' ||' ####### #######'

                -- ####-##-##########
                WHEN dataset_1573.column_1058 = '####-##-##########'
                THEN '########: ######## #######' ||' ####### #######'

                -- ########-##
                WHEN dataset_1573.column_1058 = '########-##'
                    AND max(dataset_1585.column_5216) = '######'
                THEN '######## : ######## #### ########' ||' ####### #######'
                
                --####-########-####-## 
                WHEN dataset_1573.column_1058 = '####-########-####-##'
                    AND max(dataset_1585.column_5216) = '######'
                THEN '######## : ######## #### ########(#### ########)' ||' ####### #######'
                
                --####-##-########-##
                WHEN dataset_1573.column_1058 = '####-##-########-##'
                THEN '######## : ##### #####'
                
                ELSE dataset_1053.column_742  ||' ####### #######'
            END                                                                                   AS column_7075,
             CASE 
                 WHEN dataset_1573.column_1058 = '####-##-########-##' 
                 THEN max(dataset_1585.column_148)
                 ELSE '#######_####### '||TO_CHAR(dataset_1573.column_899, '##/##/####')
                 END                                                                               AS column_7076,
            '####### ####'                                                                        AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            NULL                                                                                  AS column_7085,
            sum(dataset_1585.column_735 )                                                                      AS column_1477,
            DECODE(dataset_1573.column_2440, '#####_#####',
                            dataset_6759.column_2348,
                            NVL(dataset_2733.column_2348, dataset_6759.column_2348))                  AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_####',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum = 1),
                    argument_680            => (SELECT column_5216      
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum = 1),
                    argument_73             =>
                            DECODE(dataset_1573.column_2440, '#####_#####',
                                      dataset_6759.column_76,
                                      NVL(dataset_2733.column_76, dataset_6759.column_76)),
                    argument_252            => max(dataset_104.column_753),
                    argument_672            => dataset_1573.column_2443)                 AS column_7105,
            dataset_1573.column_2443                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM /*###_#########_########_####*/ dataset_1573,
             dataset_1060           dataset_1585,
             dataset_1054        dataset_1053,
             dataset_15 dataset_104,
             dataset_260      dataset_6759,
             dataset_260      dataset_2733,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2427 = dataset_1585.column_2427                 
            AND dataset_1573.column_76 = dataset_6759.column_76     
            AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
            AND dataset_6759.column_76 = dataset_964.column_76     
            AND (dataset_1573.column_1058  IN ('###-##','####-##','##########-###-##','#######-###-##','###-###-###########-##','###-###########-###########-##') OR
                (dataset_1573.column_1058  IN ('#######-##','########-##','####-########-####-##') AND dataset_1585.column_5216 = '######') OR
                (dataset_1573.column_1058  IN ('###-##','######-##','#######-#######-##','##-###-##') AND dataset_1573.column_2440            <> '#####_#####') OR
                (dataset_1573.column_1058  IN ('########-##') AND dataset_1585.column_5216 = '########') OR
                (dataset_1573.column_1058  IN ('####-##-########-##') AND dataset_1585.column_1064 = '###########_############'))
            AND dataset_1573.column_2440=dataset_2726.column_591
            AND dataset_1573.column_76      NOT IN ('###_##', '###_##', '###_##')--## ######## ###### ## #### ## #### ########
            AND dataset_104.column_354 =dataset_2726.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2427 ,
            dataset_1573.column_1318,
            dataset_1573.column_1319,
            dataset_1573.column_1320,
            dataset_1573.column_899,
            dataset_1053.column_742,
            dataset_1573.column_1058,
            dataset_1573.column_532 ,
            dataset_1573.column_2443,
            dataset_1573.column_2440,
            dataset_6759.column_76,
            dataset_2733.column_76,
            dataset_6759.column_2348,
            dataset_2733.column_2348,
            dataset_2726.column_2344 
        -- ###### ########--###### ## ######### ####### ## ########### ###### #####
        UNION ALL
        SELECT
            dataset_104.column_354                                                                          AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_1318,dataset_1573.column_1319,dataset_1573.column_1320,dataset_2726.column_2344)      AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            CASE WHEN dataset_1573.column_1058 = '####-##-##########-##'
                 THEN '############# : #### #####'
                 WHEN dataset_1573.column_1058 = '########-############-##' THEN
                    CASE WHEN 
                            max(dataset_1585.column_2444) IN ('###_##','###_##','###_##')
                         THEN '############# : ##### #####'
                         ELSE '############# : ##### #####'
                     END
                 WHEN dataset_1573.column_1058 = '#######-##'
                 THEN max(dataset_1585.column_1064) || ': ####### #####'
                 WHEN dataset_1573.column_1058 = '######-####-##' THEN
                 CASE
                    WHEN max(dataset_1585.column_1064) = '####_########_####_####_##'
                    THEN '#### ## : #### ######## ####'
                    ELSE '#### ## : ####### ####### ####'
                 END
                 WHEN dataset_1573.column_1058 = '#####-##'
                 THEN '######## : ##### ######'
                 ELSE '############# : ##### #####'
            END                                                                                      AS column_7075,
            
            CASE WHEN dataset_1573.column_1058 = '####-##-##########-##'
                 THEN function_4251(dataset_1585.column_2802, '$.##############') || ' ' || dataset_1585.column_734
                 WHEN dataset_1585.column_1064      in ('####_##','####_########_####_####_##')
                 THEN coalesce(TO_CHAR(dataset_1585.column_2556), dataset_1585.column_148, TO_CHAR(dataset_1585.column_2429))
                 ELSE dataset_1585.column_148          
            END                                                                                    AS column_7076,
            '####### ####'                                                                        AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            NULL                                                                                  AS column_7085,
            sum(dataset_1585.column_735)                                                                       AS column_1477,
            DECODE(dataset_1573.column_2440, '#####_#####',
                            dataset_6759.column_2348,
                            NVL(dataset_2733.column_2348, dataset_6759.column_2348))                  AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_####',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum = 1),
                    argument_680            => (SELECT column_5216      
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum = 1),
                    argument_73             =>
                            DECODE(dataset_1573.column_2440, '#####_#####',
                                      dataset_6759.column_76,
                                      NVL(dataset_2733.column_76, dataset_6759.column_76)),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2443)                 AS column_7105,
            dataset_1573.column_2443                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM /*###_#########_########_####*/ dataset_1573,
             dataset_1060          dataset_1585,
             dataset_1054        dataset_1053,
             dataset_15 dataset_104,
             dataset_260      dataset_6759,
             dataset_260      dataset_2733,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2427 = dataset_1585.column_2427                 
            AND dataset_1573.column_76 = dataset_6759.column_76     
            AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
            AND dataset_6759.column_76 = dataset_964.column_76     
            AND (dataset_1573.column_1058  IN ('########-############-##','########-############-##-##', '####-##-##########-##', '#####-##')
                OR dataset_1573.column_1058 = '#######-##' AND dataset_1573.column_2444               IN ('###_##','###_##','###_##')
                OR dataset_1573.column_1058 = '######-####-##' AND dataset_1573.column_2401              <> dataset_1573.column_1319
            )
            AND dataset_1573.column_2440            <> '#####_#####'
            and dataset_1573.column_2440=dataset_2726.column_591
            and dataset_104.column_354 =dataset_2726.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2427 ,
            dataset_1573.column_1318,
            dataset_1573.column_1319,
            dataset_1573.column_1320,
            dataset_1573.column_899,
            dataset_1053.column_742,
            dataset_1573.column_1058,
            dataset_1573.column_532 ,
            dataset_1573.column_2443,
            dataset_1573.column_2440,
            dataset_6759.column_76,
            dataset_2733.column_76,
            dataset_6759.column_2348,
            dataset_2733.column_2348,
            dataset_104.column_753,
            CASE WHEN dataset_1573.column_1058 = '####-##-##########-##'
                 THEN function_4251(dataset_1585.column_2802, '$.##############') || ' ' || dataset_1585.column_734
                 WHEN dataset_1585.column_1064      in ('####_##','####_########_####_####_##')                 
                 THEN coalesce(TO_CHAR(dataset_1585.column_2556), dataset_1585.column_148, TO_CHAR(dataset_1585.column_2429))
                 ELSE dataset_1585.column_148          
            END,
            dataset_2726.column_2344 
                        
        -- ###### ####### ###### #### : #####
        UNION ALL
        SELECT
            dataset_104.column_354                                                                          AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_135(dataset_1573.column_2431,dataset_2726.column_2344,dataset_962.column_2354)  AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,

            dataset_1053.column_742  ||' ####### #######'                                                  AS column_7075,
            '#######_####### '||TO_CHAR(dataset_1573.column_899, '##/##/####')                            AS column_7076,
            '####### ####'                                                                        AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            NULL                                                                                  AS column_7085,
            sum(dataset_1594.column_735 )                                                                     AS column_1477,
            DECODE(dataset_1573.column_2440, '#####_#####',
                            dataset_6759.column_2348,
                            NVL(dataset_2733.column_2348, dataset_6759.column_2348))                  AS column_753,
            CASE WHEN INSTR(max(dataset_1594.column_189), ';') = 0
            THEN max(dataset_1594.column_189)  
            ELSE substr(max(dataset_1594.column_189), instr(max(dataset_1594.column_189), ';')+1 )      
            END                                                                                      AS column_7105,                            
            dataset_1573.column_2443                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM /*###_#########_########_####*/ dataset_1573,
             dataset_1595              dataset_1594,
             dataset_1054        dataset_1053,
             dataset_15 dataset_104,
             dataset_260      dataset_6759,
             dataset_260      dataset_2733,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726,
             dataset_959        dataset_962
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2427 = dataset_1594.column_2427                 
            AND dataset_1573.column_76 = dataset_6759.column_76     
            AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
            AND dataset_6759.column_76 = dataset_964.column_76     
            AND dataset_1573.column_1058='######_####_#####' AND dataset_1573.column_2440            <> '#####_#####'
            and dataset_1573.column_2440=dataset_2726.column_591
            and dataset_1573.column_2440=dataset_962.column_591
            and dataset_104.column_354 =dataset_2726.column_354
            and dataset_104.column_354 =dataset_962.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2427 ,
            dataset_1573.column_1318,
            dataset_1573.column_1319,
            dataset_1573.column_1320,
            dataset_1573.column_2431,
            dataset_1573.column_899,
            dataset_1053.column_742,
            dataset_1573.column_1058,
            dataset_1573.column_532,
            dataset_1573.column_2443,
            dataset_1573.column_2440,
            dataset_6759.column_76,
            dataset_2733.column_76 ,
            dataset_6759.column_2348,
            dataset_2733.column_2348,
            dataset_2726.column_2344,
            dataset_962.column_2354              
        UNION ALL
        -- ###### ########
        SELECT
             dataset_104.column_354                                                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_2400,dataset_1573.column_2401,dataset_1573.column_2396,dataset_2726.column_2344)  AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            NULL                                                                                  AS column_7075,
            '#######_####### '||TO_CHAR(dataset_1573.column_899, '##/##/####')                            AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            CASE WHEN dataset_6760.column_735 - nvl(dataset_6761.column_735,0) > 0
            THEN
            (dataset_6760.column_735 - nvl(dataset_6761.column_735,0))
            ELSE NULL
            END                                                                                   AS column_7085,
            CASE WHEN dataset_6760.column_735 - nvl(dataset_6761.column_735,0) < 0
            THEN
            (nvl(dataset_6761.column_735,0) - dataset_6760.column_735 )
            ELSE NULL
            END                                                                                   AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum =1),
                    argument_679            => dataset_6758.column_533,
                    argument_73             => dataset_259.column_76,
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2442)               AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM
            (SELECT dataset_1573.column_2400                 ||
                    dataset_1573.column_2401              as column_1328,
                    dataset_1573.column_354,
                    dataset_1573.column_899,
                    sum (dataset_1585.column_735) as column_735,
                    dataset_1573.column_76,
                    dataset_1573.column_532,
                    max(dataset_1573.column_2427) as column_18109
               FROM /*###_#########_########_####*/ dataset_1573,
                    dataset_1060          dataset_1585,
                    dataset_15 dataset_104
              WHERE 1 = 1
                -- ##### ##### / ##########
                AND dataset_104.column_354 = dataset_1573.column_354
                AND dataset_1573.column_2427 = dataset_1585.column_2427                 
                AND dataset_1573.column_530  <> '#####_#####'
                AND dataset_1573.column_1058  NOT IN('####-######-####-##',
                                             '########-############-##',
                                             '####-##-########-##',
                                             '########-############-##-##',
                                             '####-##-##########-##',
                                             '########-######-#######-##', 
                                             '########-########-####-##',
                                             '######-####-##','############-##-####-##-##','####-##-############-##-##') 
               AND function_4251(dataset_1585.column_2802, '$.############.######') NOT IN ('######','#######_###','########','########')
           GROUP BY
                dataset_1573.column_2400,
                dataset_1573.column_2401,
                dataset_1573.column_354,
                dataset_1573.column_899,
                dataset_1573.column_532,
                dataset_1573.column_76) dataset_6760,

            (SELECT dataset_1573.column_1318               ||
                    dataset_1573.column_1319            as column_1328,
                    dataset_1573.column_354,
                    dataset_1573.column_899,
                    sum (dataset_1585.column_735) as column_735,
                    dataset_1573.column_2444               as column_76,
                    dataset_1573.column_532,
                    max(dataset_1573.column_2427) as column_18110 
            FROM /*###_#########_########_####*/ dataset_1573,
                 dataset_1060          dataset_1585,
                    dataset_15 dataset_104
            WHERE 1 = 1
                -- ##### ##### / ##########
                AND dataset_104.column_354 = dataset_1573.column_354
                AND dataset_1573.column_2427 = dataset_1585.column_2427                 
                AND dataset_1573.column_1058  NOT IN(
                            '####-######-####-##',
                            '######-####-##', -- ## ### ### ### ##########
                            '###-##', -- ### ##### ### ## #####_##### ## ########## ########
                            '##########-###-##',
                            '###-###-###########-##',
                            '###-###########-###########-##',
                            '##-###-##',
                            '####-##',
                            '#######-##',
                            '########-##',
                            '###-##',
                            '#######-#######-##',
                            '######-##',
                            '########-############-##',
                            '####-##-########-##',
                            '########-############-##-##',
                            '####-##-##########-##',
                            '########-######-#######-##', 
                            '########-########-####-##','####-##-############-##-##','##-######-##')          
                AND dataset_1573.column_2440            <> '#####_#####'
           GROUP BY
                dataset_1573.column_1318,
                dataset_1573.column_1319,
                dataset_1573.column_354,
                dataset_1573.column_899,
                dataset_1573.column_532,
                dataset_1573.column_2444 ) dataset_6761,
            /*###_#########_########_####*/ dataset_1573,
            dataset_1054        dataset_1053,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_6755    dataset_6758,
            dataset_2723      dataset_2726
        WHERE dataset_6760.column_1328 = dataset_6761.column_1328(+)
          AND dataset_6760.column_354     = dataset_6761.column_354(+)
          AND dataset_6760.column_899     = dataset_6761.column_899(+)
          AND dataset_6760.column_76 = dataset_6761.column_76(+)
          AND dataset_6760.column_532  = dataset_6761.column_532(+)
          AND dataset_6760.column_735 - nvl(dataset_6761.column_735,0) <> 0
          AND dataset_1573.column_2427 = dataset_6760.column_18109
          AND dataset_1573.column_2400 = dataset_6758.column_527(+)
          AND dataset_1573.column_2401     = dataset_6758.column_528(+)
          AND dataset_1573.column_532                = dataset_6758.column_532(+)
          AND dataset_1573.column_724       = dataset_6758.column_724(+)
          AND dataset_104.column_354 = dataset_1573.column_354
          AND dataset_1053.column_1065 = dataset_1573.column_1058 
          AND dataset_1573.column_76 = dataset_259.column_76     
          AND dataset_259.column_76 = dataset_964.column_76     
          and dataset_1573.column_530=dataset_2726.column_591
          and dataset_104.column_354 =dataset_2726.column_354
          AND dataset_1573.column_76      NOT IN ('###_##','###_##','###_##')--####### ###### #### ####### ##### ## ######## ###-##### ## ########## ### ####
          
          --###### ######## ## ######, ####### ### #######_### #######
          UNION ALL
          SELECT
             dataset_104.column_354                                                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134
                (dataset_1573.column_2400
                ,dataset_1573.column_2401
                ,dataset_1573.column_2396
                ,dataset_2726.column_2344
                )                                                                                  AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            CASE 
                WHEN function_4251(dataset_1585.column_2802, '$.############.######')='#######_###' 
                    THEN '######: ####### ### #######'
                WHEN function_4251(dataset_1585.column_2802, '$.############.######')='########'
                    THEN '######: ########'
                ELSE '######: ####### ####### #######'   
            END                                                                                    AS column_7075,
            NVL(TO_CHAR(dataset_1585.column_2556), dataset_1585.column_148)                   AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            TO_CHAR(dataset_1573.column_2427 )                                            AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            SUM(dataset_1585.column_735)                                                                       AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => dataset_1585.column_1064,
                    argument_680            => NULL,
                    argument_679            => function_4251(dataset_1585.column_2802, '$.############.######'),
                    argument_73             => dataset_259.column_76,
                    argument_1105             => MAX(function_4251(dataset_1585.column_2802, '$.########')),
                    argument_252            => dataset_104.column_753,
                    argument_672            => dataset_1573.column_2442
                    )                                                                             AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
            NULL                                                                                  AS column_18107
        FROM
            dataset_1573,
            dataset_1060          dataset_1585,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726
        WHERE 1=1
          AND dataset_1573.column_2427 = dataset_1585.column_2427                 
          AND dataset_1573.column_76               = dataset_259.column_76     
          AND dataset_259.column_76                 = dataset_964.column_76     
          AND dataset_1573.column_354                   = dataset_104.column_354
          AND dataset_1573.column_530                  = dataset_2726.column_591
          AND dataset_104.column_354                      = dataset_2726.column_354
          AND function_4251(dataset_1585.column_2802, '$.############.######') IN ('######','#######_###','########')
          AND dataset_1573.column_1058  NOT IN('####-######-####-##', '######-####-##', '####-##-########-##')
          AND dataset_1573.column_76      NOT IN ('###_##','###_##','###_##')
     GROUP BY 
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2427,
            dataset_1573.column_2400,
            dataset_1573.column_2401,
            dataset_1573.column_2396,
            dataset_2726.column_2344,
            dataset_1573.column_899,
            dataset_1585.column_1064,
            NVL(to_char(dataset_1585.column_2556), dataset_1585.column_148),
            function_4251(dataset_1585.column_2802, '$.############.######'),
            dataset_1573.column_532,
            dataset_259.column_2348,
            dataset_1573.column_1058,
            dataset_259.column_76,
            dataset_1573.column_2442,
            dataset_104.column_753  
 
        UNION ALL
        -- ###### ######## ## ######## #######
        SELECT
             dataset_104.column_354                                                                            AS column_354,
            '#####'|| dataset_104.column_122      ||'#'|| max(dataset_1573.column_2427)               AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_2400,dataset_1573.column_2401,dataset_1573.column_2396,dataset_2726.column_2344)  AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            '##### ######## #######'                                                              AS column_7075,
            '#######_####### '||TO_CHAR(dataset_1573.column_899, '##/##/####')                            AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
              sum (dataset_1585.column_735)                                                                         AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                  argument_01             => '#####',
                  argument_552                => '####_######',
                  argument_161            => dataset_1585.column_1064,
                  argument_679            => '########',
                  argument_73             => dataset_259.column_76,
                  argument_252            => dataset_104.column_753,
                  argument_672            => dataset_1573.column_2442)                    AS column_7105,
            dataset_1573.column_2442                                                                          AS column_534,
              NULL                                                                                  AS column_18107
            FROM
            /*###_#########_########_####*/ dataset_1573,
            dataset_1060          dataset_1585,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726
        WHERE dataset_1573.column_2427 = dataset_1585.column_2427                 
          AND function_4251(dataset_1585.column_2802, '$.############.######') = '########'
          AND dataset_1573.column_1058  NOT IN('####-######-####-##', '######-####-##', '####-##-########-##')
          AND dataset_1573.column_76      NOT IN ('###_##','###_##','###_##')
          AND dataset_104.column_354 = dataset_1573.column_354
          AND dataset_1573.column_76 = dataset_259.column_76     
          AND dataset_259.column_76 = dataset_964.column_76     
          AND dataset_1573.column_530=dataset_2726.column_591
          AND dataset_104.column_354 =dataset_2726.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2400,
            dataset_1573.column_2401,
            dataset_1573.column_2396,
            dataset_1573.column_899,
            dataset_1585.column_1064,
            dataset_259.column_76,
            dataset_259.column_2348,
            dataset_104.column_753,
            dataset_1573.column_532,
            dataset_1573.column_2442,
            dataset_1573.column_530,
            dataset_2726.column_2344              
            
        UNION ALL
          -- ###### ######## ## ########## #######
        SELECT
             dataset_104.column_354                                                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_2400,dataset_1573.column_2401,dataset_1573.column_2396,dataset_2726.column_2344)    AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            '############# : ##### #######'                                                       AS column_7075,
            '#######_####### '||dataset_1585.column_734                                                    AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            sum(dataset_1585.column_735)                                                                       AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum =1),
                   argument_679             => NULL,
                   argument_73              => dataset_259.column_76,
                   argument_1105              => function_4251(max(column_2802), '$.########'),
                   argument_252             => dataset_104.column_753,
                   argument_672             => dataset_1573.column_2442
                  )                                                                               AS column_7105,
             dataset_1573.column_2442                                                                     AS column_534,
             NULL                                                                                 AS column_18107
        FROM
            /*###_#########_########_####*/ dataset_1573,
            dataset_1054        dataset_1053,
            dataset_1060          dataset_1585,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726
        WHERE 
           dataset_1573.column_2427 = dataset_1585.column_2427                 
          AND dataset_104.column_354 = dataset_1573.column_354
          AND dataset_1053.column_1065 = dataset_1573.column_1058 
          AND dataset_1573.column_76 = dataset_259.column_76     
          AND dataset_259.column_76 = dataset_964.column_76     
          and dataset_1573.column_1058  IN ('########-############-##','########-############-##-##')
          AND dataset_1573.column_530  <> '#####_#####'
          and dataset_1573.column_530=dataset_2726.column_591
          and dataset_104.column_354 =dataset_2726.column_354
          AND dataset_1573.column_76      NOT IN ('###_##', '###_##', '###_##')
          GROUP BY dataset_1573.column_2400,
                dataset_1573.column_2401,
                dataset_1573.column_2396,
                dataset_1573.column_354,
                dataset_1573.column_899,
                dataset_1573.column_532,
                dataset_1585.column_734,
                dataset_259.column_76,
                dataset_104.column_354,
                dataset_104.column_122,
                dataset_1573.column_2427,
                dataset_259.column_2348,
                dataset_104.column_753,
                dataset_1573.column_2442,
                dataset_2726.column_2344,
                dataset_1573.column_1058 

          UNION ALL
          -- ###### ######## ## ##########/######### ####### ### ####
        SELECT
             dataset_104.column_354                                                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_2400
                                                            ,dataset_1573.column_2401
                                                            ,dataset_1573.column_2396
                                                            ,dataset_2726.column_2344)                      AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            CASE 
                WHEN dataset_1573.column_1058 = '########-############-##'  
                THEN '############# : ##### #######'
                WHEN dataset_1573.column_1058 = '#####-##' 
                THEN '######## : ##### #####'                
                ELSE 
                 max(dataset_1585.column_1064) || ': ############ #####'
            END                                                                                   AS column_7075,
            dataset_1585.column_148                                                                        AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            sum(dataset_1585.column_735)                                                                       AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum =1),
                   argument_679             => NULL,
                   argument_73              => dataset_259.column_76)                                 AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
            CASE
                    WHEN dataset_1573.column_1058 = '#####-##'
                    THEN function_4251(dataset_1585.column_2802, '$.###########')
            END                                                                                   AS column_18107
        FROM
            /*###_#########_########_####*/ dataset_1573,
            dataset_1054        dataset_1053,
            dataset_1060          dataset_1585,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726
        WHERE 
           dataset_1573.column_2427 = dataset_1585.column_2427                 
          AND dataset_104.column_354 = dataset_1573.column_354
          AND dataset_1053.column_1065 = dataset_1573.column_1058 
          AND dataset_1573.column_76 = dataset_259.column_76     
          AND dataset_259.column_76 = dataset_964.column_76     
          AND (dataset_1573.column_1058  in( '########-############-##','#####-##')
                  OR dataset_1573.column_1058  IN ('####-##-##########', '#######-##')
                  AND dataset_1585.column_1064      IN ('########', '##########')
          )
          AND dataset_1573.column_2440            <> '#####_#####'
          AND dataset_1573.column_530=dataset_2726.column_591
          AND dataset_104.column_354 =dataset_2726.column_354
          AND dataset_1573.column_76      IN ('###_##', '###_##', '###_##')
          GROUP BY dataset_1573.column_2400,
                dataset_1573.column_2401,
                dataset_1573.column_2396,
                dataset_1573.column_354,
                dataset_1573.column_899,
                dataset_1573.column_532,
                dataset_1585.column_148,
                dataset_259.column_76,
                dataset_104.column_354,
                dataset_104.column_122,
                dataset_1573.column_2427,
                dataset_259.column_2348,
                dataset_1573.column_2442,
                dataset_2726.column_2344,
                dataset_1573.column_1058,
                CASE
                    WHEN dataset_1573.column_1058 = '#####-##'
                    THEN function_4251(dataset_1585.column_2802, '$.###########')
                END
                
     UNION ALL
         -- ###### ####### ########
        SELECT
            dataset_104.column_354                                                                          AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_134(dataset_1573.column_2400,dataset_1573.column_2401,dataset_1573.column_2396,dataset_2726.column_2344)      AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            CASE 
              WHEN dataset_1573.column_1058 = '####-##-########-##'
              THEN '######## : ##### #######'
              --########-########-####-##
              WHEN dataset_1573.column_1058 = '########-########-####-##'
              THEN '######## : ##### #######'
              --######-####-##
              WHEN dataset_1573.column_1058 = '######-####-##' THEN
                  CASE
                   WHEN max(dataset_1585.column_1064) = '####_########_####_####_##'
                    THEN '#### ## : ########### #### ######## #### '
                    ELSE '#### ## : ########### ####### ####### #### '
              END
              --########-######-#######-##
              WHEN dataset_1573.column_1058 = '########-######-#######-##' 
              THEN '###### : ##### #######'
              END                                                                                 AS column_7075,
            CASE 
              WHEN dataset_1585.column_1064 = '########_#######'
              THEN max(to_char(dataset_1585.column_2556))
              WHEN dataset_1585.column_1064 = '######_####'
              THEN max(to_char(NVL(dataset_1585.column_2556, dataset_1585.column_2480)))
              WHEN dataset_1585.column_1064      in ('####_##','####_########_####_####_##')
              THEN max(coalesce(TO_CHAR(dataset_1585.column_2556), dataset_1585.column_148, TO_CHAR(dataset_1585.column_2429)))
              ELSE max(dataset_1585.column_148) 
              END                                                                                 AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            sum(dataset_1585.column_735)                                                                       AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            package_381.package_function_413(
                    argument_01             => '#####',
                    argument_552                => '####_######',
                    argument_650            => dataset_1573.column_1058,
                    argument_161            => (SELECT column_1064     
                                                  FROM dataset_1060          dataset_1585
                                                 WHERE dataset_1585.column_2427 = dataset_1573.column_2427                 
                                                   AND rownum =1),
                   argument_679             => NULL,
                   argument_73              => dataset_259.column_76,
                   argument_252             => dataset_104.column_753,
                   argument_672             => dataset_1573.column_2442)               AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
             NULL                                                                                 AS column_18107
        FROM /*###_#########_########_####*/ dataset_1573,
             dataset_1060          dataset_1585,
             dataset_1054        dataset_1053,
             dataset_15 dataset_104,
             dataset_260      dataset_259,
             dataset_949                            dataset_964,
             dataset_2723      dataset_2726
        WHERE 1 = 1
            -- ##### ##### / ##########
            AND dataset_104.column_354 = dataset_1573.column_354
            AND dataset_1053.column_1065 = dataset_1573.column_1058 
            AND dataset_1573.column_2427 = dataset_1585.column_2427                 
            AND dataset_1573.column_76 = dataset_259.column_76     
            AND dataset_259.column_76 = dataset_964.column_76     
            AND (dataset_1573.column_1058  IN ('####-##-########-##', '########-######-#######-##', '########-########-####-##' ) OR
                 dataset_1573.column_1058 = '######-####-##' AND dataset_1573.column_2401              <> dataset_1573.column_1319            
                     AND dataset_1573.column_530  <> '#####_#####')
            and dataset_1573.column_530=dataset_2726.column_591
            and dataset_104.column_354 =dataset_2726.column_354
        GROUP BY
            dataset_104.column_354,
            dataset_104.column_122,
            dataset_1573.column_2427 ,
            dataset_1573.column_2400,
            dataset_1573.column_2401,
            dataset_1573.column_2396,
            dataset_1573.column_899,
            dataset_1053.column_742,
            dataset_1573.column_1058,
            dataset_1573.column_532 ,
            dataset_1573.column_2442,
            dataset_259.column_76,
            dataset_104.column_753,
            CASE WHEN dataset_1585.column_1064      IN ('########_#######', '######_####') THEN to_char(dataset_1585.column_2480) ELSE dataset_1585.column_148           END,
            dataset_1585.column_1064,
            dataset_259.column_2348,
            dataset_2726.column_2344 
     UNION ALL
        -- ###### ######## ###### ####
        SELECT
             dataset_104.column_354                                                                         AS column_354,
            '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                    AS column_1117,
            '#'                                                                                   AS column_2468,
            package_131.package_function_135(dataset_1573.column_2430,dataset_2726.column_2344,dataset_962.column_2354)  AS column_1328,
            TO_CHAR(dataset_1573.column_899, '##/##/####')                                                AS column_1056,
            NULL                                                                                  AS column_7075,
            '#######_####### '||TO_CHAR(dataset_1573.column_899, '##/##/####')                            AS column_7076,
            NULL                                                                                  AS column_7077,
            dataset_104.column_122                                                                          AS column_2329,
            NULL                                                                                   AS column_7082,
            '#####'                                                                               AS column_7083,
            dataset_1573.column_532                                                                       AS column_874,
            sum(dataset_1594.column_735)                                                                      AS column_7085,
            NULL                                                                                  AS column_1477,
            dataset_259.column_2348                                                                        AS column_753,
            CASE WHEN INSTR(MAX(dataset_1594.column_189), ';') = 0
            THEN MAX(dataset_1594.column_189)  
            ELSE SUBSTR(MAX(dataset_1594.column_189), 1, INSTR(MAX(dataset_1594.column_189), ';')-1 )
            END                                                                                      AS column_7105,
            dataset_1573.column_2442                                                                      AS column_534,
             NULL                                                                                 AS column_18107
        FROM
            dataset_1595              dataset_1594,
            /*###_#########_########_####*/ dataset_1573,
            dataset_1054        dataset_1053,
            dataset_15 dataset_104,
            dataset_260      dataset_259,
            dataset_949                            dataset_964,
            dataset_6755    dataset_6758
            ,dataset_2723      dataset_2726
            ,dataset_959        dataset_962
        WHERE dataset_1573.column_2427 = dataset_1594.column_2427                 
          AND dataset_1573.column_2400 = dataset_6758.column_527(+)
          AND dataset_1573.column_2401     = dataset_6758.column_528(+)
          AND dataset_1573.column_532                = dataset_6758.column_532(+)
          AND dataset_1573.column_724       = dataset_6758.column_724(+)
          AND dataset_104.column_354 = dataset_1573.column_354
          AND dataset_1053.column_1065 = dataset_1573.column_1058 
          AND dataset_1573.column_76 = dataset_259.column_76     
          AND dataset_259.column_76 = dataset_964.column_76     
          AND dataset_1573.column_530  <> '#####_#####'
          AND dataset_1573.column_1058='######_####_#####'    
          and dataset_1573.column_530=dataset_2726.column_591
          and dataset_1573.column_530=dataset_962.column_591
          and dataset_104.column_354 =dataset_2726.column_354
          and dataset_104.column_354 =dataset_962.column_354      
      GROUP BY
                dataset_1573.column_2400,
                dataset_1573.column_2401,
                dataset_1573.column_2430,
                dataset_1573.column_354,
                dataset_1573.column_899,
                dataset_1573.column_532,
                dataset_1573.column_76  ,
                dataset_104.column_354,
                dataset_104.column_122,
                dataset_1573.column_2427 ,
                dataset_1573.column_532 ,
                dataset_1573.column_2442,
                dataset_259.column_2348,
                dataset_259.column_76,
                dataset_2726.column_2344,
                dataset_962.column_2354
)