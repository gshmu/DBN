--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #_#########_########.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ##     ##.##.#### ######          ###-##### #### #######
--### *********************************************************************/


BEGIN
    EXECUTE IMMEDIATE '#### ####### #########_########';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/


CREATE OR REPLACE FORCE VIEW view_08
(
     column_714
    ,column_1064
    ,column_703
    ,column_700
    ,column_6132
    ,column_724
    ,column_6133
    ,column_3629
    ,column_1425
    ,column_1443
    ,column_3631 
)
AS
  SELECT dataset_2369.column_714
        ,dataset_2369.column_1064
        ,dataset_2370.column_703
        ,dataset_2370.column_700
        ,dataset_2369.column_6132
        ,DECODE(dataset_2371.column_724, '*', null , dataset_2371.column_724)
        ,dataset_2369.column_6133
        ,dataset_2370.column_3629
        ,dataset_2370.column_1425
        ,dataset_2369.column_1443
        ,dataset_2370.column_3631  
   FROM schema_138.dataset_2372 dataset_2370
       ,schema_138.dataset_2373            dataset_2369 
       ,schema_138.dataset_2374            dataset_2371
  WHERE dataset_2370.column_703 = dataset_2369.column_703
    AND dataset_2369.column_6133 = dataset_2371.column_6133
/

COMMIT
/
