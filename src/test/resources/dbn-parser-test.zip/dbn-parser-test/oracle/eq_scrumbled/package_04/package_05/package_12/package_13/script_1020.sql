--### /********************************************************************
--###  #### ####   : ####_##_##_#_########_###_######.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ### ####### (######## ########)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_20              
AS
    SELECT dataset_312.column_148,
           TO_NUMBER(NULL) AS column_718,
           NULL AS column_12130,
           dataset_312.column_2255,
           dataset_312.column_583,
           dataset_312.column_2968,
           dataset_923.column_3082,
           dataset_312.column_1064,
           dataset_312.column_2967,
           dataset_312.column_1490,
           dataset_312.column_684,
           DECODE(dataset_1848.column_4605, NULL, '#', CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) IN ('########', '#######') THEN '#' ELSE '#' END) AS column_12131,
           DECODE(dataset_1848.column_4605, NULL, '#', CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) = '#######' THEN '#' ELSE '#' END) AS column_12132,
           DECODE(dataset_1848.column_4605, NULL, '#', DECODE(MAX(CASE WHEN dataset_67.column_10 = '#####' THEN 1 ELSE 0 END), 1, '#', '#')) AS column_12133,
           DECODE(dataset_1848.column_4605, NULL, '#', DECODE(MAX(CASE WHEN dataset_67.column_4609 = '#' THEN 1 ELSE 0 END), 1, '#', '#')) AS column_12134,
           COUNT(dataset_314.column_10697) AS column_12135,
           dataset_1848.column_871,
           dataset_1848.column_4605,
           NVL(dataset_1848.column_4603,
               CASE WHEN dataset_312.column_1064       IN ('###', '###')
                     AND dataset_320.column_3146 = '###_##########_###########'
                     THEN '###_####'
                     ELSE '####' END) AS column_4603,
           NVL(dataset_1848.column_4604,
               CASE WHEN dataset_312.column_2968          IS NOT NULL
                      OR (dataset_312.column_2967 = '#' AND
                          dataset_312.column_2969 = '##### - ###_##_####') -- ####
                    THEN '#####'
                    ELSE '######' END) AS column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_12136,
           dataset_1848.column_12137,
           dataset_1848.column_12138     
      FROM dataset_311        dataset_312
           INNER JOIN dataset_313                   dataset_314 ON dataset_314.column_148 = dataset_312.column_148          
           INNER JOIN dataset_315    dataset_86 ON dataset_86.column_451 = dataset_314.column_451      
           INNER JOIN dataset_269 dataset_320 ON dataset_320.column_598 = dataset_86.column_598
            LEFT JOIN dataset_1849           dataset_67 ON dataset_67.column_544 = dataset_314.column_4614        
            LEFT JOIN dataset_4575            dataset_1848 ON dataset_1848.column_4605 = dataset_67.column_4605      
                  AND dataset_1848.column_4603  IN ('####', '###_####')
            LEFT JOIN dataset_924     dataset_923 ON dataset_923.column_2255 = dataset_312.column_2255
            LEFT JOIN dataset_257  dataset_256 ON dataset_256.column_583 = dataset_312.column_583          
     WHERE dataset_312.column_1064      IN ('###', '###', '########', '#######', '###_####', '####_######')
       AND dataset_312.column_3147 = '#'
       AND dataset_312.column_3149 = '#'
  GROUP BY dataset_312.column_148,
           dataset_312.column_2255,
           dataset_312.column_583,
           dataset_312.column_2968,
           dataset_312.column_2969,
           dataset_923.column_3082,
           dataset_312.column_1064,
           dataset_312.column_2967,
           dataset_312.column_1490,
           dataset_312.column_684,
           dataset_320.column_3146,
           dataset_1848.column_871,
           dataset_1848.column_4605,
           dataset_1848.column_4603,
           dataset_1848.column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_12136,
           dataset_1848.column_12137,
           dataset_1848.column_12138     
  ORDER BY dataset_312.column_148          

