--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : ####_###_######_######.###
--###
--###  ####### ####       ###               ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ########           ######
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ########           ###-#####
--### *********************************************************************/



BEGIN
    EXECUTE IMMEDIATE '#### ####### ###_######_######';
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END;
/

DECLARE
    any_204       schema_138.dataset_15.column_354%TYPE;
    any_09        VARCHAR2(30) := sys_context('#######','#######_######');

BEGIN
    
    EXECUTE IMMEDIATE '##### ###### ## ###_######_####.######_###### ## '||column_33 || ' #### ##### ######';
  
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

CREATE OR REPLACE FORCE VIEW view_17           AS
SELECT
    dataset_1318.column_2634
   ,dataset_3663.column_2642
   ,dataset_3663.column_2633
   ,dataset_3663.column_930
   ,dataset_3663.column_2643
   ,dataset_3663.column_2644
   ,dataset_3663.column_2645
   ,dataset_3663.column_2646
   ,dataset_3663.column_2647
   ,dataset_3663.column_2648
   ,dataset_3663.column_2649
   ,dataset_3663.column_2650
   ,dataset_3663.column_2651
   ,dataset_3663.column_2652
   ,dataset_3663.column_2653
   ,dataset_3663.column_2654
   ,dataset_3663.column_2655
   ,'#' column_2638
FROM
    dataset_1149  dataset_3663
    INNER JOIN dataset_1147 dataset_1318 ON dataset_3663.column_2633 = dataset_1318.column_2633
UNION
SELECT
    dataset_2214.column_2634
   ,dataset_3664.column_2642
   ,dataset_3664.column_2633
   ,dataset_3664.column_930
   ,dataset_3664.column_2643
   ,dataset_3664.column_2644
   ,dataset_3664.column_2645
   ,dataset_3664.column_2646
   ,dataset_3664.column_2647
   ,dataset_3664.column_2648
   ,dataset_3664.column_2649
   ,dataset_3664.column_2650
   ,dataset_3664.column_2651
   ,dataset_3664.column_2652
   ,dataset_3664.column_2653
   ,dataset_3664.column_2654
   ,dataset_3664.column_2655
   ,'#' column_2638
FROM
    schema_138.dataset_1149  dataset_3664
    INNER JOIN schema_138.dataset_1147 dataset_2214 ON dataset_3664.column_2633 = dataset_2214.column_2633
WHERE
    dataset_2214.column_2634 NOT IN (SELECT column_2634 FROM dataset_1147)
/

COMMIT
/


