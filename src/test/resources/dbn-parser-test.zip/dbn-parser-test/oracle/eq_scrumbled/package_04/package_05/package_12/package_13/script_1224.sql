--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : ####_##_######_#########_##########.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######         ##/###### ######
--###  ##.#.#. ##.##.#### #######   #######  #### ######## ####### #####
--### *********************************************************************/












--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####


CREATE OR REPLACE FORCE VIEW view_24
(column_2612                        
,column_354                        
,column_5173                        
,column_5174            
,column_264                        
,column_1267                    
,column_5175                    
,column_5176            
,column_5177            
,column_5178            
,column_10                                
,column_742                    
,column_5179                    
,column_5180                    
,column_5181            
,column_2368                    
,column_5934
,column_5182
,column_06
,column_204
,column_609
,column_229
,column_610
)
AS SELECT column_2612                        
,column_354                        
,column_5173                        
,column_5174            
,column_264                        
,column_1267                    
,column_5175                    
,column_5176            
,column_5177            
,column_5178            
,column_10                                
,column_742                    
,column_5179                    
,column_5180                    
,column_5181            
,column_2368                    
,column_5934
,column_5182
,column_06
,column_204
,column_609
,column_229
,column_610
FROM dataset_2298               
    WHERE column_354 = SYS_CONTEXT ('###_#######_###', '#######')
order by column_204 desc
/                         

COMMIT
/
      





