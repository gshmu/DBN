--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : #_########_###_#####_#########.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.#### #####         ###-##### -######## ## ####
--### *********************************************************************/

--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

CREATE OR REPLACE VIEW view_03                       
AS
    SELECT dataset_67.column_544,
            dataset_1848.column_4603,
            dataset_1848.column_4604,
            dataset_67.column_4605,
            dataset_67.column_4606,
            dataset_1848.column_4607,
            dataset_67.column_10,
            dataset_67.column_1052,
            dataset_67.column_4608,
            dataset_67.column_4609,
            dataset_67.column_4610,
            dataset_67.column_4611,
            dataset_67.column_4612,
            dataset_67.column_4613,
            dataset_67.column_189,
            dataset_67.column_3611,
            dataset_333.column_2985,
            dataset_314.column_148,
            NULL AS column_718        
       FROM dataset_1849           dataset_67,
            dataset_1850          dataset_1848,
            dataset_313                   dataset_314,
            dataset_336 dataset_333
      WHERE dataset_1848.column_4605 = dataset_67.column_4605      
        AND dataset_314.column_4614 = dataset_67.column_544 
        AND dataset_333.column_07 = dataset_314.column_07     
        AND dataset_333.column_451 = dataset_314.column_451      
        AND dataset_333.column_452 = dataset_314.column_452         
   GROUP BY dataset_67.column_544,
            dataset_1848.column_4603,
            dataset_1848.column_4604,
            dataset_67.column_4605,
            dataset_67.column_4606,
            dataset_1848.column_4607,
            dataset_67.column_10,
            dataset_67.column_1052,
            dataset_67.column_4608,
            dataset_67.column_4609,
            dataset_67.column_4610,
            dataset_67.column_4611,
            dataset_67.column_4612,
            dataset_67.column_4613,
            dataset_67.column_189,
            dataset_67.column_3611,
            dataset_333.column_2985,
            dataset_314.column_148          
   ORDER BY dataset_67.column_544
/

COMMIT
/






