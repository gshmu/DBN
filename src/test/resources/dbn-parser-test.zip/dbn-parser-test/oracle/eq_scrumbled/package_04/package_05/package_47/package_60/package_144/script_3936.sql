/*
    #### ####### ###### #####
    ####### ##.#
    ####### ##.#.# ####### #### ####### ###### #####   ########
    ##.#.# ####### ##### #### #####
    ##.#.# ####### ########### ########### ######
    ##.#.# ####### ####### ##### ########### ######
    ####### ##
    ##.#.# ####### ######## #### ######
    ##.#.# ######## ###-####: #### ############
    ##.#.# ####### ###-####:######## ##### #### ############## ##### ## ## ## ##### ## ####
    ##.#.# ####### ###-####:##### ######## #### ## ######## ########.
    ####### ##
    ##.#.# ####### ######## #### ######
    ####### ##
    ##.#.# ########  ###-#####:######### #######
    ##.#.# ########  ###-#####:###### ######## ##### ###
    ##.#.# ########  ###-#####:#### ##### ### ######
    ##.#.# ########  ###-#####:#### ##### ### ####### ## ###### # #####
    ####### ##.#
    ##.#.#  ##.##.####   ########  ###-##### ##### #########_##### #####
    ####### ##.#
    ##.#.#  ##.##.####  ########  ###-##### ## ### ####### ##### ####### ### ##### #### ####### ########
    ####### ##.#
    ##.#.#  ##.##.####  #######  ###-##### :###### #### ##### ##### ## ### ########
    ####### ##.#
    ##.#.#  ##.##.####  ######   ###-#####: ####### ####### ### #### ####### ###### #####
    ####### ##.#
    ##.#.#  ##.##.####  ########   ###-#####: ##### - ### ###### ## ########## ####### ######## (### ## ###-#####)
    ####### ##.#.#
    ##.#.#  ##.##.####  ########   ###-#####: ##### - ######## ### ###### #### ####### (########## ##########)
    ####### ##.#
    ##.#.#  ##.##.####  ########   ###-#####: ##### - ####### ### #### ###### ##### ### ##### ########## ##### ## #### ###### ##### #
    */
  SELECT
      /* ####### */
      column_07,
      column_451,
      column_452,
      column_714,
      column_1446,
      column_4127,
      column_5253,
      column_604         AS column_6576,
      column_4134        AS column_6577,
      column_5569,
      column_5284,
      column_5252,
      column_76,
      column_3154,
      /* ####### ##### */
      CASE
        WHEN column_6377 = '#'
        THEN package_180.package_function_394(,column_6568,column_29784, column_11)
        ELSE column_2726         
      END * column_6561 * column_6381            AS column_14061,
      CASE
        WHEN column_6377 = '#'
        THEN package_180.package_function_394(,column_6568,column_29784, column_11)
        ELSE column_2726         
      END * column_6561 * DECODE(column_604, column_4134, NULL, 1) AS column_29785,
      column_2730 * column_6561 * column_6381                           AS column_8475,
      column_2730 * column_6561 * column_6381                           AS column_29786,
      column_4129                                                                      AS column_2685,
      /* ######## */
      column_708           AS column_24497,
      column_4129 * column_708     AS column_179,
      column_709           AS column_6204,
      column_711           AS column_23677,
      column_712           AS column_26103,
      column_710           AS column_6605,
      column_2726          AS column_13133,
      column_2725          AS column_6205,
      column_2730          AS column_17619,
      /* ##### */
      CASE WHEN column_3063='########' AND column_656           IS NOT NULL
      THEN '########_########'
      ELSE column_3063      
      END AS column_3063,
      column_3759,
      column_4128       AS column_2723,
      column_4128       AS column_5500,
      /* #### #### ########## */
      column_3140,
      column_15005,
      /* ### */
      column_29787,
      column_3048,
      column_2710,
      /* ###### */
      column_2721,
      DECODE(column_644, column_2721, TO_DATE(NULL), column_644)           AS column_644,
      column_644                                                              AS column_29788,
      DECODE(column_2728, column_644, TO_DATE(NULL), column_2728) AS column_2728,
      column_2728                                                             AS column_29789,
      column_2729,
      column_3160,
      TRUNC(column_2560) AS column_2560,
      /* ###########: ######### */
      column_6375            AS column_6633,
      column_29790,
      column_29790 * column_6561 * column_6381            AS column_29791,
      /* ###########: ### */
      column_6376                                                                                                                                            AS column_6572,
      package_180.package_function_394(,column_6636,column_29792, column_11)                                               AS column_6574,
      package_180.package_function_394(,column_6636,column_29792, column_11) * column_6561 * column_6381            AS column_6575,
      /* ###########: ####### */
      column_6377            AS column_29793,
      CASE
        WHEN column_6377 = '#'
        THEN NVL(column_6567, 100)
      END                                                                                                                                                            AS column_6567,
      package_180.package_function_394(,column_6568,column_29784, column_11)                                               AS column_29794,
      package_180.package_function_394(,column_6568,column_29784, column_11) * column_6561 * column_6381            AS column_29795,
      /* ###########: ####### */
      column_6640                                              AS column_29796,
      column_708 - column_711 - column_712         AS column_29797,
      /* #### */
      column_12491                    AS column_29798,
      column_3116                      AS column_29799,
      NVL(column_5660,'#########') AS column_29800,
      column_28345                    AS column_29801,
      column_7136                     AS column_29802,
      column_1785                     AS column_29803,
      column_644                      AS column_29804,
      column_6601,
      column_6951,
      column_7140                     AS column_29805,
      column_6928                     AS column_6928,
      column_738                         AS column_738,
      column_23678,
      column_12070          
    FROM
      (SELECT dataset_4387.*,
          column_708 * 100 / NVL(column_6375, 100)
          AS column_29790,
        CASE
          WHEN column_6377 = '#'
          THEN (column_2726 - column_2725) * NVL (column_6567, 100) / column_6375           
        END AS column_29784,
        CASE
          WHEN column_6377 = '#'
          THEN column_708 * column_6376 / column_6375           
        END AS column_29792,
        CASE
          WHEN column_6567 < 100
          THEN column_6379               
          ELSE column_6380              
        END AS column_6568,
        CASE
          WHEN column_6376 < 100
          THEN column_6379               
          ELSE column_6380              
        END AS column_6636     
      FROM
        (SELECT dataset_1981.*,
          DECODE(dataset_1981.column_3048, '###_##_#####', '#', '#') AS column_29787,
          dataset_4051.column_3140,
          dataset_4051.column_15005,
          CASE
            WHEN dataset_1981.column_601 IN ('##_####','##_####')
            THEN greatest(dataset_1981.column_4129, dataset_1981.column_4128)
            WHEN dataset_1981.column_986 = '######'
            THEN GREATEST(dataset_1981.column_4129 - dataset_1981.column_4128, 0)
            ELSE dataset_1981.column_4129  
          END AS column_6561,
          CASE
              /* + ### ########### ### ###### #### ########## #### ## ########## #### ### ### ##### */
            WHEN           = '#'
            AND dataset_1981.column_3084 = '#'
            THEN 0
            ELSE dataset_1981.column_2730        
          END AS column_17619,
          CASE
            WHEN dataset_1981.column_6377 = '#'
            THEN schema_384.package_180.package_function_396 ( dataset_1981.column_07, dataset_1981.column_451, dataset_1981.column_452)
          END AS column_6567,
          dataset_10399.column_12491,
          dataset_10399.column_3116,
          dataset_10399.column_5660,
          dataset_10399.column_28345,
          dataset_10399.column_7136,
          dataset_10399.column_1785,
          dataset_10399.column_6482,
          dataset_977.column_549 * 100 / NVL(dataset_1981.column_6375, 100) AS column_6601,
          dataset_460.column_3154,
          dataset_10399.column_7140,
          dataset_45.column_6928,
          dataset_45.column_738,
          dataset_8051.column_1028 as column_23678,
          dataset_4561.column_1028 as column_12070,
          dataset_1632.column_1028 as column_656          
        FROM dataset_1634                  dataset_1981,dataset_459                    dataset_460,
          (SELECT column_07,
            column_451,
            column_452,
            column_549
          FROM dataset_978                 dataset_977
          WHERE dataset_977.column_1064 = '##########'
          ) dataset_977,
          dataset_4052               dataset_4051,
          dataset_4667                   dataset_10399,
          dataset_331 dataset_45,
          (
          select
            column_1028 ,column_2985  
            from dataset_1299         
            where column_3466='###########_######'
           ) dataset_8051,
           (
          select
            column_1028 ,column_2985  
            from dataset_1299         
            where column_3466='###########_##########'
           ) dataset_4561,
           (
              select
            column_1028 ,column_2985  
            from dataset_1299         
            where column_3466='######_##########_##'
           ) dataset_1632
        WHERE dataset_1981.column_2985     = 
        AND dataset_1981.column_07      = dataset_4051.column_07(+)
        AND dataset_1981.column_451    = dataset_4051.column_451(+)
        AND dataset_1981.column_452 = dataset_4051.column_452(+)
        AND dataset_1981.column_07      = dataset_977.column_07(+)
        AND dataset_1981.column_451    = dataset_977.column_451(+)
        AND dataset_1981.column_452 = dataset_977.column_452(+)
        AND dataset_1981.column_2985       = dataset_10399.column_2985(+)
        AND dataset_1981.column_451    = dataset_460.column_451(+)
        AND dataset_1981.column_11             =  dataset_460.column_11(+)
        AND dataset_1981.column_3063   =  dataset_460.column_3063(+)
        AND dataset_1981.column_6933 = dataset_45.column_6933(+)
        AND dataset_1981.column_2985 = dataset_8051.column_2985(+)
        AND dataset_1981.column_2985 = dataset_4561.column_2985(+)
        AND dataset_1981.column_2985 = dataset_1632.column_2985(+)
        ) dataset_4387
      )