--### /********************************************************************
--###  #### ####   : ####_##_##_#_########_###_###_######.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ### ####### (######## ########)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_64                  
AS
    SELECT NULL AS column_148,
           TO_NUMBER(NULL) AS column_718,
           dataset_1274.column_2680 AS column_12130,
           NULL AS column_2255,
           NULL AS column_583,
           dataset_1436.column_3530 AS column_2968,
           dataset_1294.column_3082,
           dataset_1274.column_1064,
           DECODE(dataset_1294.column_565, '###_##_####', '#', '#') AS column_2967,
           dataset_1274.column_1490,
           CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) IN ('########', '#######') THEN '#' ELSE '#' END AS column_12131,
           CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) = '#######' THEN '#' ELSE '#' END AS column_12132,
           DECODE(MAX(CASE WHEN dataset_67.column_10 = '#####' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12133,
           DECODE(MAX(CASE WHEN dataset_67.column_4609 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12134,
           COUNT(dataset_1291.column_2985) AS column_12135,
           dataset_1848.column_871,
           dataset_1848.column_4605,
           NVL(dataset_1848.column_4603,
               DECODE(dataset_1294.column_9079, '#',
                   CASE WHEN dataset_1274.column_1064      IN ('###', '###')
                         AND dataset_320.column_3146 = '###_##########_###########'
                         THEN '###_####'
                         ELSE '####'
                   END,
               '###_####')) AS column_4603,
           '#####' AS column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_12136,
           dataset_1848.column_12137,
           dataset_1848.column_12138,
           dataset_1294.column_10 AS column_15031           
      FROM dataset_1292 dataset_1274
           INNER JOIN dataset_1290          dataset_1291 ON dataset_1291.column_2680 = dataset_1274.column_2680
           INNER JOIN dataset_1293      dataset_1294 ON dataset_1294.column_3082 = dataset_1274.column_3082        
           INNER JOIN dataset_336 dataset_333 ON dataset_333.column_2985 = dataset_1291.column_2985  
           INNER JOIN dataset_315    dataset_86 ON dataset_86.column_451 = dataset_333.column_451      
           INNER JOIN dataset_269 dataset_320 ON dataset_320.column_598 = dataset_86.column_598
            LEFT JOIN dataset_1435            dataset_1436 ON dataset_1436.column_3530 = dataset_1294.column_2968         
            LEFT JOIN dataset_1849           dataset_67 ON dataset_67.column_544 = dataset_1291.column_4614        
            LEFT JOIN dataset_4575            dataset_1848 ON dataset_1848.column_4605 = dataset_67.column_4605      
     WHERE dataset_1274.column_1064      IN ('####', '########', '###', '###', '#######', '###_####', '####_######')
       AND dataset_1274.column_3147 = '#'
       AND dataset_1274.column_3149 = '#'
  GROUP BY dataset_1274.column_2680,
           dataset_1436.column_3530,
           dataset_1294.column_3082,
           dataset_1294.column_9079,
           dataset_1274.column_1064,
           DECODE(dataset_1294.column_565, '###_##_####', '#', '#'),
           dataset_1274.column_1490,
           dataset_320.column_3146,
           dataset_1848.column_871,
           dataset_1848.column_4605,
           dataset_1848.column_4603,
           dataset_1848.column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_12136,
           dataset_1848.column_12137,
           dataset_1848.column_12138,
           dataset_1294.column_10

