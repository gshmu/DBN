--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #_#######_####.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  #.#      ##.##.#### #######         #######
--###  ##.#     ##.##.#### ######          ###-##### ###### ##### 
--### *********************************************************************/

--### ############# ##;

--/* ######### ## ##/##/#### ##:##:## (### ##.###.#####.#####) */
CREATE OR REPLACE FORCE VIEW view_60
(
   column_354,
   column_122,
   column_742,
   column_6827,
   column_6825,
   column_6822,
   column_6824,
   column_6832,
   column_6823,
   column_6826,
   column_6828,
   column_6830,
   column_6829,
   column_6831,
   column_23,
   column_06,
   column_204,
   column_229,
   column_609,
   column_610,
   column_6840,
   column_1287,
   column_1288,
   column_1289,
   column_1290,
   column_753,
   column_6833,
   column_6834,
   column_6835,
   column_2333,
   column_2334,
   column_2335,
   column_1746,
   column_963,
   column_213,
   column_2830,
   column_10732,
   column_189,
   column_868,
   column_3025,
   column_5064
)
AS
   SELECT column_5630,
          column_23286,
          column_8108,
          column_23287,
          column_23288,
          column_23289,
          column_23290,
          column_23291,
          column_23292,
          column_23293,
          column_23294,
          column_23295,
          column_23296,
          column_23297,
          column_23298,
          column_11051,
          column_8115,
          column_8117,
          column_8116,
          column_8118,
          column_23299,
          column_11052,
          column_11053,
          column_11054,
          column_11055,
          column_23300,
          column_23301,
          column_23302,
          column_23303,
          column_16008,
          column_16009,
          column_16010,
          column_16011,
          column_16012,
          column_16013,
          column_23304,
          column_23305,
          column_23306,
          column_23307,
          column_23308,
          column_23309     
     FROM dataset_15@dblink_07  
    WHERE column_354 != '####'
/

COMMIT
/
