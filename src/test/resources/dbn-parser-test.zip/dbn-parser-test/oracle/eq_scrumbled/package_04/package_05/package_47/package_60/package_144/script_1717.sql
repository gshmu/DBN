/* ####### ##
      ##.#.#  ##.##.####   ########  ###-#####: ###### ##### ### ##### */
   select column_735
  from (select package_987.package_function_1298(,,) column_735 from dataset_62)
 where column_735 > 0