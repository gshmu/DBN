--### /********************************************************************
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_##_####.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ##.#.#  ##.##.#### ########        ###-##### : ####/###### ############ #### ###_##_####
--###  ##.#.#  ##.##.#### #######         ###-##### : ### ##### #####
--###  ##.#.#  ##.##.#### ########        ###-##### : ### ### ###-#####: ##### ##### ###########_####_####_#####
--### *********************************************************************/
DECLARE
  any_08              CONSTANT VARCHAR2(30) := '###_' || '########_' || '#######';
  any_09              VARCHAR2(30) := sys_context('#######','#######_######');
  any_10              VARCHAR2(3)  := '###';
  any_11              VARCHAR2(61);
  
  any_12              schema_03.dataset_18%TYPE := '###_##_####';
  any_2923            schema_03.dataset_18%TYPE := '###########_####_####_#####';
  
  CURSOR cursor_655      IS
        SELECT 1 
          FROM dataset_117 
         WHERE  column_282  = column_37   
           AND column_263        = column_33 ;
 
    any_527  NUMBER(1);

BEGIN
  IF column_33 != column_34          THEN
    method_05   := SUBSTR(column_33,13,3);
  END IF;
  
  method_06       := column_33 || '.######_######_' || column_35;
  BEGIN
    package_05.method_07(column_36,column_37);
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;

  OPEN cursor_655;
    FETCH any_2924        INTO any_527;
    IF column_5402%FOUND THEN
            
          BEGIN
            EXECUTE IMMEDIATE '#### ##### ' || column_37    || ' ####### ########### #####';
          EXCEPTION
              WHEN OTHERS THEN NULL;
          END;
    END IF;

  CLOSE any_2924;

  
  BEGIN
    EXECUTE IMMEDIATE '#### ############ #### ' || column_37;
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;
  
  BEGIN  
    EXECUTE IMMEDIATE 
         '###### ############ #### ' || column_37    
      || ' '
      || '########## ###_' || column_35   || '_####_#### '
      || ' ######### '
      || ' ####### # '
      || ' ####### ## '
      || ' ##### ######## '
      || ' ##### ##### ########## ###_' || column_35   || '_####_#### '
      || ' ####### ##### '
--      || ' ###### ##### ####### '
      || '## ###### * #### '
      || column_5403      || ''
      ;
    EXCEPTION
      WHEN OTHERS THEN 
      package_06.method_08(SUBSTR(sqlerrm,1,255));
  package_07.method_09(column_37,'##### = '||SQLERRM,sys_context( '#######','#######_######'));
  END;
  
  BEGIN
    package_05.method_10(column_36,column_37);
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##$###_##_####$#### ## ' || column_37    
                       || ' (#######_########) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##$###_##_####$##### ## ' || column_37    
                       || ' (###########_##, #############_##, ##########_########) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##$###_##_####$####_#### ## ' || column_37    
                       || ' (###########_##, #############_##, ###########_#######) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##$###_##_####$####_#### ## ' || column_37    
                       || ' (###########_####) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##$###_##_####$####### ## ' || column_37    
                       || ' (#######) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_##_####_## ## ' || column_37    
                       || ' (#####_####) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_##_####_## ## ' || column_37    
                       || ' (###########_####) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_##_####_## ## ' || column_37    
                       || ' (#####_####) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_##_####_## ## ' || column_37    
                       || ' (####_####) '
                       || ' ######## # ######### ########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;
  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_###_##_####_## ## ' || column_37    
                       || ' (###_####) '
                       || '########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;
  BEGIN
    EXECUTE IMMEDIATE '###### ##### ##_###_###_##_####_## ## ' || column_37    
                       || ' (### (###_####, ##_#### (''##-##-####'', ''##-##-####''))) '
                       || '########## ###_' || column_35   || '_####_####';
    EXCEPTION
      WHEN OTHERS THEN NULL;
  END;  
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
/

COMMIT
/




