
WITH dataset_3651
     AS (SELECT dataset_977.column_204 AS column_219,
                dataset_977.column_3816 AS column_1050,
                dataset_977.column_07      AS column_07,
                dataset_45.column_74  AS column_74,
                dataset_45.column_75 AS column_75,
                dataset_977.column_451       AS column_451,
                dataset_275.column_1446        AS column_1446,
                dataset_275.column_11 AS column_11,
                dataset_275.column_2955 AS column_2955,
                dataset_275.column_562 AS column_562,
                dataset_275.column_3125 AS column_3125,
                dataset_275.column_3744              AS column_3744,
                dataset_275.column_3621                 AS column_3621,
                dataset_275.column_714   AS column_714,
                dataset_977.column_549 AS column_549,
                dataset_977.column_1064      AS column_1064,
                '###-#' AS column_9517,
                '###-#' AS column_9518,
                dataset_977.column_5289,
                dataset_460.column_9519,
                dataset_977.column_76,
                dataset_977.column_3905 
           FROM dataset_978                 dataset_977
                INNER JOIN dataset_50   dataset_45
                   ON (dataset_977.column_07 = dataset_45.column_07)
                INNER JOIN dataset_276 dataset_275 ON (dataset_275.column_11 = dataset_977.column_11)
                INNER JOIN dataset_459                    dataset_460
                   ON (    dataset_460.column_451 = dataset_977.column_451      
                       AND dataset_460.column_11 = dataset_977.column_11
                       AND dataset_460.column_3154 = '###########')
          WHERE     dataset_977.column_604 = '###'
                AND dataset_977.column_11 LIKE '###_#####%'
                AND dataset_977.column_1064      IN ('##########', '####_##########')
                AND dataset_977.column_204 > 
                --## ###### ## ######### ######## ###### ## ####### ### ### ##########/####-##########
                AND NOT EXISTS
                       (SELECT 1
                          FROM dataset_563             dataset_503
                         WHERE     dataset_503.column_1064 =
                                      dataset_977.column_1064     
                               AND dataset_503.column_07 = dataset_977.column_07     
                               AND dataset_503.column_1050 = dataset_977.column_3816))
SELECT column_219,
       column_1050,
       column_07,
       column_74,
       column_75,
       column_451,
       column_1446,
       column_11,
       column_2955,
       column_562,
       column_3125,
       column_3744,
       column_3621,
       column_714,
       column_549,
       column_1064,
       column_9517,
       column_9518,
       column_9519,
       column_76,
       column_3905
  FROM dataset_3651 dataset_3652
 WHERE     1 = 1
       AND NOT EXISTS
              (SELECT 1
                 FROM dataset_3651 dataset_3653
                WHERE     dataset_3653.column_1064 =
                             CASE
                                WHEN dataset_3652.column_1064 = '##########'
                                THEN
                                   '####_##########'
                                WHEN dataset_3652.column_1064 =
                                        '####_##########'
                                THEN
                                   '##########'
                             END
                      AND CASE
                             WHEN dataset_3652.column_1064 = '##########'
                             THEN
                                dataset_3652.column_1050         
                             ELSE
                                dataset_3652.column_5289    
                          END =
                             CASE
                                WHEN dataset_3652.column_1064 = '##########'
                                THEN
                                   dataset_3653.column_5289    
                                ELSE
                                   dataset_3653.column_1050         
                             END)
