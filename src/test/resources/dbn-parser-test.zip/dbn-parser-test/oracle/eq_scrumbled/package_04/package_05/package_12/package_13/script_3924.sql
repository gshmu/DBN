--### /********************************************************************
--###  #### ####   : ####_##_##_#_########_###_#########.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ### ####### (######## ########)
--### *********************************************************************/

CREATE OR REPLACE VIEW view_81                 
AS
WITH
    dataset_10381   AS (
        SELECT SYSDATE - TO_NUMBER(NVL(package_11.package_function_04(
            argument_01             => '#####',
            argument_40             => '###_#######',
            argument_41             => '##',
            argument_42             => '#######_#######_####'), '###')) AS column_29711      
        FROM dataset_62),
    dataset_5700        AS (
        SELECT dataset_1230.column_4605,
               dataset_1230.column_4603,
               dataset_1230.column_4604,
               dataset_1230.column_12136,
               dataset_1230.column_12137,
               dataset_1230.column_12138,
               dataset_1230.column_12131,
               dataset_1230.column_12132,
               dataset_1230.column_12134,
               dataset_1230.column_12133,
               dataset_1230.column_12135,
               dataset_1230.column_1064,
               dataset_1230.column_2255,
               dataset_1230.column_583,
               dataset_1230.column_3082,
               dataset_1230.column_12130,
               dataset_1230.column_148,
               dataset_1230.column_718        
          FROM dataset_5701          dataset_1230,
               dataset_10381   dataset_7972
         WHERE dataset_1230.column_1490 = '#'
           AND dataset_1230.column_684               IN ('####', '####', '####')
           AND NVL(dataset_1230.column_12137, SYSDATE) > dataset_7972.column_29711),
    dataset_5702            AS (
        SELECT dataset_5703.column_4605,
               dataset_5703.column_4603,
               dataset_5703.column_4604,
               dataset_5703.column_12136,
               dataset_5703.column_12137,
               dataset_5703.column_12138,
               dataset_5703.column_12131,
               dataset_5703.column_12132,
               dataset_5703.column_12134,
               dataset_5703.column_12133,
               dataset_5703.column_12135,
               dataset_5703.column_1064,
               dataset_5703.column_2255,
               dataset_5703.column_583,
               dataset_5703.column_3082,
               dataset_5703.column_12130,
               dataset_5703.column_148,
               dataset_5703.column_718        
          FROM dataset_5704              dataset_5703,
               dataset_10381   dataset_7972
         WHERE dataset_5703.column_1490 = '#'
           AND NVL(dataset_5703.column_12137, SYSDATE) > dataset_7972.column_29711),
    dataset_5705            AS (
        SELECT dataset_5706.column_4605,
               dataset_5706.column_4603,
               dataset_5706.column_4604,
               dataset_5706.column_12136,
               dataset_5706.column_12137,
               dataset_5706.column_12138,
               dataset_5706.column_12131,
               dataset_5706.column_12132,
               dataset_5706.column_12134,
               dataset_5706.column_12133,
               dataset_5706.column_12135,
               dataset_5706.column_1064,
               dataset_5706.column_2255,
               dataset_5706.column_583,
               dataset_5706.column_3082,
               dataset_5706.column_12130,
               dataset_5706.column_148,
               dataset_5706.column_718        
          FROM dataset_5707              dataset_5706,
               dataset_10381   dataset_7972
         WHERE dataset_5706.column_1490 = '#'
           AND dataset_5706.column_15031 = '###_#########'
           AND NVL(dataset_5706.column_12137, SYSDATE) > dataset_7972.column_29711)

-- ###### ####### - ###### ###### (##### #######)
SELECT dataset_1230.column_4605,
           dataset_1230.column_4603,
           dataset_1230.column_4604,
           '#####' column_15032,
           dataset_1230.column_12136,
           dataset_1230.column_12137,
           dataset_1230.column_12138,
           dataset_1230.column_12131,
           dataset_1230.column_12132,
           dataset_1230.column_12134,
           dataset_1230.column_12133,
           dataset_1230.column_12135,
           1 AS column_15033,
           dataset_1230.column_1064,
           dataset_1230.column_2255,
           dataset_1230.column_583,
           dataset_1230.column_3082,
           dataset_1230.column_12130,
           dataset_1230.column_148,
           dataset_1230.column_718        
      FROM dataset_5700        dataset_1230
     WHERE dataset_1230.column_4604 = '######'

-- ###### ####### - ###### ########## (##### #######)
UNION ALL
    SELECT dataset_5703.column_4605,
           dataset_5703.column_4603,
           dataset_5703.column_4604,
           '#########' column_15032,
           dataset_5703.column_12136,
           dataset_5703.column_12137,
           dataset_5703.column_12138,
           dataset_5703.column_12131,
           dataset_5703.column_12132,
           dataset_5703.column_12134,
           dataset_5703.column_12133,
           dataset_5703.column_12135,
           1 AS column_15033,
           dataset_5703.column_1064,
           dataset_5703.column_2255,
           dataset_5703.column_583,
           dataset_5703.column_3082,
           dataset_5703.column_12130,
           dataset_5703.column_148,
           dataset_5703.column_718        
      FROM dataset_5702            dataset_5703
     WHERE dataset_5703.column_4604 = '######'


-- ##### ####### - ###### ###_###### (##### ######## / ### #######)
UNION ALL
    SELECT dataset_5706.column_4605,
           dataset_5706.column_4603,
           dataset_5706.column_4604,
           '#####' column_15032,
           dataset_5706.column_12136,
           dataset_5706.column_12137,
           dataset_5706.column_12138,
           dataset_5706.column_12131,
           dataset_5706.column_12132,
           dataset_5706.column_12134,
           dataset_5706.column_12133,
           dataset_5706.column_12135,
           1 AS column_15033,
           dataset_5706.column_1064,
           dataset_5706.column_2255,
           dataset_5706.column_583,
           dataset_5706.column_3082,
           dataset_5706.column_12130,
           dataset_5706.column_148,
           dataset_5706.column_718        
      FROM dataset_5705            dataset_5706
     WHERE dataset_5706.column_4604 = '#####'
       AND dataset_5706.column_12131 = '#'
       AND dataset_5706.column_12132 = '#'


-- ##### ####### - ###### ###### (##### ######## / ### #######)
UNION ALL
    SELECT dataset_1230.column_4605,
           dataset_1230.column_4603,
           dataset_1230.column_4604,
           '#####' column_15032,
           dataset_1230.column_12136,
           dataset_1230.column_12137,
           dataset_1230.column_12138,
           dataset_1230.column_12131,
           dataset_1230.column_12132,
           dataset_1230.column_12134,
           dataset_1230.column_12133,
           dataset_1230.column_12135,
           1 AS column_15033,
           dataset_1230.column_1064,
           dataset_1230.column_2255,
           dataset_1230.column_583,
           dataset_1230.column_3082,
           dataset_1230.column_12130,
           dataset_1230.column_148,
           dataset_1230.column_718        
      FROM dataset_5700        dataset_1230
     WHERE dataset_1230.column_4604 = '#####'
       AND dataset_1230.column_12131 = '#'
       AND dataset_1230.column_12132 = '#'

-- ##### ####### - ###### ########## (##### ######## / ### #######)
UNION ALL
    SELECT dataset_5703.column_4605,
           dataset_5703.column_4603,
           dataset_5703.column_4604,
           '#########' column_15032,
           dataset_5703.column_12136,
           dataset_5703.column_12137,
           dataset_5703.column_12138,
           dataset_5703.column_12131,
           dataset_5703.column_12132,
           dataset_5703.column_12134,
           dataset_5703.column_12133,
           dataset_5703.column_12135,
           1 AS column_15033,
           dataset_5703.column_1064,
           dataset_5703.column_2255,
           dataset_5703.column_583,
           dataset_5703.column_3082,
           dataset_5703.column_12130,
           dataset_5703.column_148,
           dataset_5703.column_718        
      FROM dataset_5702            dataset_5703
     WHERE dataset_5703.column_4604 = '#####'
       AND dataset_5703.column_12131 = '#'
       AND dataset_5703.column_12132 = '#'


-- ##### ####### - ####### ###_###### (##### ### ######### / ######## ###)
UNION ALL
    SELECT dataset_5706.column_4605,
           dataset_5706.column_4603,
           dataset_5706.column_4604,
           '#####' column_15032,
           dataset_5706.column_12136,
           dataset_5706.column_12137,
           dataset_5706.column_12138,
           CASE WHEN COUNT(DISTINCT dataset_5706.column_12131) = 1 AND MAX(dataset_5706.column_12131) = '#' THEN '#' ELSE '#' END AS column_12131,
           CASE WHEN COUNT(DISTINCT dataset_5706.column_12132) = 1 AND MAX(dataset_5706.column_12132) = '#' THEN '#' ELSE '#' END AS column_12132,
           DECODE(MAX(CASE WHEN dataset_5706.column_12134 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12134,
           DECODE(MAX(CASE WHEN dataset_5706.column_12133 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12133,
           SUM(dataset_5706.column_12135) AS column_12135,
           COUNT(dataset_5706.column_12130) AS column_15033,
           dataset_5706.column_1064,
           NULL AS column_2255,
           NULL AS column_583,
           dataset_5706.column_3082,
           NULL AS column_12130,
           NULL AS column_148,
           NULL AS column_718        
      FROM dataset_5705            dataset_5706
     WHERE dataset_5706.column_4604 = '#####'
       AND dataset_5706.column_12131 = '#'
  GROUP BY dataset_5706.column_4605,
           dataset_5706.column_4603,
           dataset_5706.column_4604,
           dataset_5706.column_12136,
           dataset_5706.column_12137,
           dataset_5706.column_12138,
           dataset_5706.column_1064,
           dataset_5706.column_3082        

-- ##### ####### - ####### ###### (##### ### ######### / ######## ###)
UNION ALL
    SELECT dataset_1230.column_4605,
           dataset_1230.column_4603,
           dataset_1230.column_4604,
           '#####' column_15032,
           dataset_1230.column_12136,
           dataset_1230.column_12137,
           dataset_1230.column_12138,
           CASE WHEN COUNT(DISTINCT dataset_1230.column_12131) = 1 AND MAX(dataset_1230.column_12131) = '#' THEN '#' ELSE '#' END AS column_12131,
           CASE WHEN COUNT(DISTINCT dataset_1230.column_12132) = 1 AND MAX(dataset_1230.column_12132) = '#' THEN '#' ELSE '#' END AS column_12132,
           DECODE(MAX(CASE WHEN dataset_1230.column_12134 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12134,
           DECODE(MAX(CASE WHEN dataset_1230.column_12133 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12133,
           SUM(dataset_1230.column_12135) AS column_12135,
           COUNT(dataset_1230.column_148) AS column_15033,
           dataset_1230.column_1064,
           dataset_1230.column_2255,
           dataset_1230.column_583,
           dataset_1230.column_3082,
           NULL AS column_12130,
           NULL AS column_148,
           NULL AS column_718        
      FROM dataset_5700        dataset_1230
     WHERE dataset_1230.column_4604 = '#####'
       AND dataset_1230.column_12131 = '#'
  GROUP BY dataset_1230.column_4605,
           dataset_1230.column_4603,
           dataset_1230.column_4604,
           dataset_1230.column_12136,
           dataset_1230.column_12137,
           dataset_1230.column_12138,
           dataset_1230.column_1064,
           dataset_1230.column_2255,
           dataset_1230.column_583,
           dataset_1230.column_3082        

-- ##### ####### - ####### ########## (##### ### ######### / ######## ###)
UNION ALL
    SELECT dataset_5703.column_4605,
           dataset_5703.column_4603,
           dataset_5703.column_4604,
           '#########' column_15032,
           dataset_5703.column_12136,
           dataset_5703.column_12137,
           dataset_5703.column_12138,
           CASE WHEN COUNT(DISTINCT dataset_5703.column_12131) = 1 AND MAX(dataset_5703.column_12131) = '#' THEN '#' ELSE '#' END AS column_12131,
           CASE WHEN COUNT(DISTINCT dataset_5703.column_12132) = 1 AND MAX(dataset_5703.column_12132) = '#' THEN '#' ELSE '#' END AS column_12132,
           DECODE(MAX(CASE WHEN dataset_5703.column_12134 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12134,
           DECODE(MAX(CASE WHEN dataset_5703.column_12133 = '#' THEN 1 ELSE 0 END), 1, '#', '#') AS column_12133,
           SUM(dataset_5703.column_12135) AS column_12135,
           COUNT(dataset_5703.column_148) AS column_15033,
           dataset_5703.column_1064,
           dataset_5703.column_2255,
           dataset_5703.column_583,
           dataset_5703.column_3082,
           NULL AS column_12130,
           NULL AS column_148,
           NULL AS column_718        
      FROM dataset_5702            dataset_5703
     WHERE dataset_5703.column_4604 = '#####'
       AND dataset_5703.column_12131 = '#'
  GROUP BY dataset_5703.column_4605,
           dataset_5703.column_4603,
           dataset_5703.column_4604,
           dataset_5703.column_12136,
           dataset_5703.column_12137,
           dataset_5703.column_12138,
           dataset_5703.column_1064,
           dataset_5703.column_2255,
           dataset_5703.column_583,
           dataset_5703.column_3082        



