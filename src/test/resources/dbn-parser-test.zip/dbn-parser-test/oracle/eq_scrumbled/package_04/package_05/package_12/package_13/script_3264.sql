--### /********************************************************************
--###  #### ####   : ####_##_##_#_########_###_########.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ### #####         ###-##### - ### ####### (######## ########)
--### *********************************************************************/
--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

CREATE OR REPLACE VIEW view_72                
AS
    SELECT dataset_1848.column_871,
           dataset_1848.column_4605,
           dataset_1848.column_4603,
           dataset_1848.column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_10 AS column_12136,
           dataset_1848.column_12137,
           MAX(dataset_9169.column_12137) AS column_12138,
           CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) IN ('########', '#######') THEN '#' ELSE '#' END as column_12131,
           CASE WHEN COUNT(DISTINCT dataset_67.column_10) = 1 AND MAX(dataset_67.column_10) = '#######' THEN '#' ELSE '#' END as column_12132,
           DECODE(MAX(CASE WHEN dataset_67.column_10 = '#####' THEN 1 ELSE 0 END), 1, '#', '#') as column_25982,
           DECODE(MAX(CASE WHEN dataset_67.column_4609 = '#' THEN 1 ELSE 0 END), 1, '#', '#') as column_12134
      FROM dataset_1850          dataset_1848
           INNER JOIN dataset_1849           dataset_67
                   ON dataset_67.column_4605 = dataset_1848.column_4605      
            LEFT JOIN dataset_1850          dataset_9169
                   ON dataset_9169.column_4603 = '#######'
                  AND dataset_9169.column_4605 = dataset_67.column_4605      
                  AND dataset_9169.column_871 > dataset_1848.column_871
     WHERE dataset_1848.column_4603  IN ('###_####', '####', '###_####')
       AND dataset_1848.column_871 = (
                SELECT max(dataset_2251.column_871)
                  FROM dataset_1850          dataset_2251
                 WHERE dataset_2251.column_4605 = dataset_1848.column_4605      
                   AND dataset_2251.column_4603 = dataset_1848.column_4603)
  GROUP BY dataset_1848.column_871,
           dataset_1848.column_4605,
           dataset_1848.column_4603,
           dataset_1848.column_4604,
           dataset_1848.column_4607,
           dataset_1848.column_12137,
           dataset_1848.column_10
  ORDER BY dataset_1848.column_871
/
