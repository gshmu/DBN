select column_6383
             , nvl(column_7132,0) as column_7132
             , column_1785
             , null AS column_7133
             , column_7134
             , column_6779 * 12 as column_7135
             , column_7136
             , column_2721
             , column_6482
             , column_7137
             , column_7138
             , column_7139
             , column_7140
             , column_2560
             , column_7141
             , column_10
                , column_7142
                , dataset_333.column_599
             ,column_597
             ,column_7143
             ,column_7144        
          from (

                    SELECT  dataset_2741.column_599
                            ,0 as column_7132     -- ####### #### ####### ######
                           ,nvl( dataset_2742.column_7134,0) as column_7134

                         ,  nvl( dataset_2743.column_7137,0) as column_7137
                        ,  0 as column_7139
                        , 0 as  column_7138         


                    FROM   (
                    select dataset_2473.column_599
                    ,dataset_2744.column_532
                    ,dataset_2744.column_735
                    ,dataset_2473.column_6359    
                    from dataset_1539       dataset_2744 , dataset_2472 dataset_2473
                   where dataset_2744.column_3843= dataset_2473.column_3839  
                        and dataset_2473.column_07 = 
                    ) dataset_2741
                    ,  ( select column_599 ,count(1) AS column_7137          from dataset_2472
        where column_07 = 
         and column_6359 = '######_#######_######'
        GROUP BY column_599

                                              )  dataset_2743
                   ,(
                   select column_599 , count(*) AS column_7134        from dataset_2472
        where column_07 = 
        and column_6359 = '#####_####' GROUP BY column_599

                   ) dataset_2742      


                    WHERE 1=1
                    and dataset_2743.column_599 (+)= dataset_2741.column_599   
                    and dataset_2742.column_599 (+) = dataset_2741.column_599   
                    group by dataset_2741.column_599
                    ,dataset_2743.column_7137
                    ,dataset_2742.column_7134
                )dataset_318
            ,    (
               select dataset_790.column_599
                    , sum(dataset_790.column_6779) column_6779
                    , sum(dataset_790.column_6166) column_7136
                    , min(dataset_790.column_1785) column_1785          
                 from dataset_791              dataset_790
                where dataset_790.column_07 = 
             group by dataset_790.column_599
               ) dataset_790
             , (
               select dataset_333.column_451       as column_6383
                    , dataset_1300.column_1028 as column_599
                    , dataset_320.column_597                     as column_597
                    , dataset_259.column_555        as column_7143
                    , min(dataset_333.column_2721) column_2721
                    , max(column_644) column_6482
                    , max(dataset_333.column_2560) AS column_2560
                    , dataset_1841.column_7145           AS column_7140
                    , dataset_2745.column_1028  as column_7141
                    , dataset_2746.column_7121                  as column_7144        
                 from dataset_336 dataset_333,
                      dataset_1299          dataset_1300,
                       dataset_1299          dataset_2745,
                      dataset_315    dataset_86,
                      dataset_269 dataset_320,
                      dataset_260      dataset_259,
                      dataset_276 dataset_275,
                      dataset_2483      dataset_2484,
                      dataset_2485 dataset_461,
                      dataset_270 dataset_268,
                      dataset_2740      dataset_1841,
                      dataset_2738                  dataset_2747,
                      (select dataset_2746.column_598 , dataset_2746.column_7121                  from 
                      dataset_2737                   dataset_2746 , dataset_336 dataset_333 ,dataset_315    dataset_86
                      where dataset_333.column_07 = 
                  and dataset_333.column_451 = dataset_86.column_451      
                  and dataset_2746.column_598 (+) = dataset_86.column_598 
                  and SYSDATE BETWEEN dataset_2746.column_973 and dataset_2746.column_2746) dataset_2746
                where dataset_333.column_07 = 
                  and dataset_333.column_451 = dataset_86.column_451      
                  and dataset_333.column_11 = dataset_275.column_11
                  and dataset_2484.column_3118 = 
                  and dataset_2484.column_3118 = dataset_461.column_3118   
                  and dataset_2484.column_598 = dataset_86.column_598
                  and dataset_320.column_598=dataset_86.column_598
                  and dataset_2746.column_598 (+) = dataset_86.column_598
                  AND dataset_259.column_76(+) = dataset_320.column_597                    
                  and nvl(dataset_2484.column_714, dataset_275.column_714) = dataset_275.column_714  
                  and nvl(dataset_2484.column_1446, dataset_275.column_1446) = dataset_275.column_1446       
                  and dataset_461.column_6384 = '#############'
                  and dataset_333.column_2985 = dataset_1300.column_2985  
                  and dataset_1300.column_3466 = '####_#####_##'
                  and dataset_268.column_599=    dataset_1300.column_1028
                   and dataset_2745.column_3466(+)='##########_######'
                  and dataset_2745.column_2985(+) = dataset_1300.column_2985  
                  and dataset_268.column_7146=dataset_1841.column_7123        
                  and dataset_1841.column_7123=dataset_2747.column_7123        
                  and dataset_2747.column_3925=    '#######_#######_#############'
                group by dataset_333.column_451
                    , dataset_1300.column_1028
                    ,dataset_1841.column_7145
                    ,dataset_2745.column_1028
                    ,dataset_320.column_597
                    ,dataset_259.column_555
                    ,dataset_2746.column_7121
               ) dataset_333
                ,(select dataset_1643.column_10
                ,dataset_1643.column_599   
                 from dataset_1642                 dataset_1643
                 where column_07 = 
                 )dataset_1643,
            (select MAX(dataset_1271.column_1868) as column_7142 ,column_599   
            FROM dataset_2748                dataset_1271
           where dataset_1271.column_07 = 
           and dataset_1271.column_1868   in ('####_########','####_##########','####_######')
           AND dataset_1271.column_7147='#########'
           group by column_599
             ) dataset_1271

         where dataset_333.column_599 = dataset_318.column_599(+)
           and dataset_333.column_599 = dataset_790.column_599(+)
         and dataset_333.column_599 = dataset_1643.column_599 (+)
        and  dataset_333.column_599 = dataset_1271.column_599 (+)