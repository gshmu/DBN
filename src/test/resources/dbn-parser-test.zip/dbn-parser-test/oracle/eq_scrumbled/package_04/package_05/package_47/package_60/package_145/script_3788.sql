/******************************************************************************
    ##### #####: ########_#####_#######
    #########:   ########_#####
    ########:    ####### (###_#######)
    ######### #### ####### ##### ### ######## ##### ##### (####### ##### - ##### #########)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### #### (###########)
        - #######_######                   ####### ######
        - ##########_####                  ########## ####
        - ######_####                      ###### ####
        - #########                        #########
        - ####                             ####
        - ########_#########               ######## #########
        - ####                             ####
        - #####_####                       ##### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - #####_##                         ##### ## / #### ## / #### ##
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #############_######             ############# ######
        - ####_#####                       #### #####
        - ####_####_#                      #### #### #
        - #####_####                       ##### ####
        - ######                           ######
        - #####_##########                 ##### ##### (##### ##########)
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - #######                          #######
        - #############_########           ############# ########
        - ####_##                          ########### ##
        - ###########_##                   ########### ##
        - #####_######                     ##### ######/ #######/ ########## ######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####

    ###### ## ###########:  ##(######## #####)||###(#######)||<####### ##### ##>||<#########>||<###.########_#####_###########_##>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ########_##### ### ###### #####
    ##.#.#    ##.##.####   ### #####    ###-##### ### ###### ######
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ######-#########-####-## #### / ### #### (###### ######)
*******************************************************************************/

SELECT
    column_354,
    column_1117,
    column_2468,
    column_1328,
    column_567,
    NULL AS column_7074,
    column_7075,
    column_562,
    column_7077,
    NULL AS column_5861,
    column_3924,
    NULL AS column_7080,
    NULL AS column_7081,
    NULL AS column_5704,
    column_2329,
    column_5694,
    column_7083,
    column_874,
    NULL AS column_7084,
    column_7085,
    column_1477,
    NULL AS column_549,
    column_11799,
    column_7087,
    NULL AS column_11800,
    column_566,
    column_10,
    NULL AS column_11801,
    NULL AS column_7091,
    NULL AS column_7092,
    NULL AS column_7093,
    NULL AS column_7094,
    NULL AS column_7095,
    NULL AS column_7096,
    NULL AS column_7097,
    NULL AS column_7098,
    NULL AS column_7099,
    NULL AS column_7100,
    NULL AS column_7101,
    NULL AS column_7102,
    NULL AS column_8429,
    column_7078,
    NULL AS column_3816,
    column_1309,
    column_753,
    NULL AS column_534,
    NULL AS column_7106,
    NULL AS column_7107,
    NULL AS column_7108,
    NULL AS column_7109,
    NULL AS column_7110,
    NULL AS column_7111,
    NULL AS column_7112,
    NULL AS column_7113,
    NULL AS column_7114
FROM (
    WITH dataset_949                            as (
            select /*+ ########### */ column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_15 dataset_104
                WHERE column_2345 = 
                      and dataset_104.column_354= 
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),  
     dataset_260      AS (
        SELECT column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
     dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354 = )
    SELECT
        dataset_104.column_354                                                                      AS column_354,
        '#####'||dataset_104.column_122      ||'#'
               ||dataset_1578.column_14140                 
               ||ROW_NUMBER() OVER (
                    PARTITION BY dataset_1578.column_148,
                                 dataset_1578.column_567,
                                 dataset_1578.column_2266          
                        ORDER BY dataset_1578.column_567)                                     AS column_1117,
        '#'                                                                               AS column_2468,
        package_131.package_function_134(  
            CASE WHEN dataset_1578.column_3916 = '###'
                 THEN dataset_1573.column_2400                 
                 ELSE dataset_1573.column_1318               
            END    ,
            CASE WHEN dataset_1578.column_3916 = '###'
                 THEN dataset_1573.column_2401             
                 ELSE dataset_1573.column_1319           
            END     ,  
            CASE WHEN dataset_1578.column_3916 = '###'
                 THEN dataset_1573.column_2396            
                 ELSE dataset_1573.column_1320          
            END    ,dataset_2726.column_2344)                                                        AS column_1328,
        TO_CHAR(dataset_1578.column_567, '##/##/####')                                        AS column_567,
        '##########: #### - ##### ## ######'                                              AS column_7075,
        dataset_1578.column_562                                                                          AS column_562,
        dataset_1578.column_148                                                                    AS column_7077,
        dataset_1578.column_14141                                                                  AS column_3924,
        dataset_104.column_122                                                                      AS column_2329,
        dataset_1578.column_148                                                                    AS column_5694,
        '#####'                                                                           AS column_7083,
        '###'                                                                             AS column_874,
        CASE WHEN dataset_1578.column_3916 = '###' THEN dataset_1578.column_3917   ELSE NULL END               AS column_7085,
        CASE WHEN dataset_1578.column_3916 = '####' THEN dataset_1578.column_3917   ELSE NULL END              AS column_1477,
        dataset_1573.column_735                                                                       AS column_11799,
        dataset_1578.column_1479                                                                   AS column_7087,
        TO_CHAR(dataset_1578.column_566, '##/##/####')                                             AS column_566,
        '##### ## ######'                                                                 AS column_10,
        dataset_1578.column_532                                                                    AS column_7078,
        dataset_1578.column_148                                                                    AS column_1309,
        dataset_259.column_2348       ||'/'||
            package_381.package_function_413(
                            argument_01              => '#####',
                            argument_650             => dataset_1573.column_1058,
                            argument_73              => dataset_1573.column_76)||'/'||
             DECODE(dataset_1578.column_3916, '###',
                    dataset_1573.column_2442,
                    dataset_1573.column_2443)                                  AS column_753  
    FROM dataset_1579              dataset_1578,
         dataset_1057                dataset_1573,
         dataset_15 dataset_104,
         dataset_260      dataset_259,
         dataset_2723      dataset_2726,
         dataset_949                            dataset_964
    WHERE 1=1
        -- ##### ##### / ##########
        AND dataset_104.column_354 = dataset_1578.column_354
        AND dataset_1573.column_1050 = dataset_1578.column_148          
        AND dataset_1573.column_899 = dataset_1578.column_567     
        AND dataset_1573.column_1058 = '######-#########-####-##'
        AND dataset_1573.column_76 = dataset_259.column_76 (+)
        AND dataset_1573.column_76 = dataset_964.column_76     
        AND dataset_1578.column_1058 = '##########'
        AND dataset_1578.column_684               IN ('####', '####', '####')
        AND dataset_1578.column_10 = '####'
        AND CASE WHEN dataset_1578.column_3916 = '###' THEN dataset_1573.column_530  ELSE column_2440            END =dataset_2726.column_591
        and dataset_104.column_354 =dataset_2726.column_354
        -- ###### ###### / ####### ######
        AND dataset_1578.column_354 = 
        AND dataset_1573.column_204 >   
        AND dataset_1573.column_204 <=  
)


