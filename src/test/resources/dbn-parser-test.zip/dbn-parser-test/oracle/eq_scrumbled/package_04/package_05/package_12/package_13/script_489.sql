--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : ####_#_#_###########_#####_#########.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ########     ######: ## ####### ########### #### #######
--###  ##.#.#  ##.##.#### #######      ######_#### #####
--###  ##.#.#  ##.##.#### #######      ###### ####### ###
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######      ######
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######      ## ####
--###  ##.#.#  ##.##.#### ###########  ### ### #### ( ## ####)
--###  ####### ##
--###  ##.#.#  ##.##.#### ########### #### ### ####
--###  ####### ##
--###  ##.#.#  ##.##.#### ######## 	#### ###-####
--###  ####### ##
--###  ##.#.#  ##.##.#### ######## 	#### ###-####
--###  ##.#.#  ##.##.#### ######## 	#### ###-####
--###  ##.#.#  ##.##.#### ######## 	#### ###-####
--###  ####### ##.#
--###  ##.#.#	 ##.##.####	### ##### 	###-#### ####### ### ############# #########
--###  ####### ##.#
--###  ##.#.#	 ##.##.####	######## 	###-#### ##### #####_########_######_##,########_##,########_######_#####_##,#######_######,############_####_##,#######_######_#####,##############_###########,######_######,#######_#######
--###  ####### ##.#
--###	 ##.#.#  ##.##.#### ########    ###-##### ### ####### ### ###-#####- ### ### ###### ## #_###########_#####_#########
--###  ####### ##
--###	 ##.#.#  ##.##.#### ########    ###-##### ### ### ###### ## #_###########_#####_#########
--###  ##.#.#  ##.##.#### ########    ###-##### ### ### ###### ## #_###########_#####_#########
--###  ####### ##.#
--###  ##.#.#  ##.##.#### ########   ###-##### : ### ### ###-##### : ##### ###### ######### ### #########
--### *********************************************************************/




--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

DROP VIEW view_10
/

CREATE OR REPLACE FORCE VIEW view_10 (
    column_07,
    column_451,
    column_452,
    column_2721,
    column_7054,
    column_644,
    column_2728,
    column_2729,
    column_3759,
    column_7055,
    column_2560,
    column_3063,
    column_3048,
    column_2710,
    column_3128,
    column_598,
    column_4127,
    column_6637,
    column_601,
    column_3815,
    column_11,
    column_5253,
    column_986,
    column_714,
    column_604,
    column_4129,
    column_6620,
    column_7056,
    column_1446,
    column_5514,
    column_708,
    column_712,
    column_711,
    column_709,
    column_710,
    column_2725,
    column_2726,
    column_2730,
    column_4130,
    column_4128,
    column_4134,
    column_7057,
    column_4131,
    column_6381,
    column_7058,
    column_7059,
    column_4132,
    column_4133,
    column_2985,
    column_4126,
    column_2681,
    column_165,
    column_74,
    column_75,
    column_734,
    column_3147,
    column_3149,
    column_1025,
    column_7060,
    column_170,
    column_5248,
    column_2256,
    column_2661,
    column_3159,
    column_7061,
    column_3084,
    column_6951,
    column_3045,
    column_3056,
    column_6933,
    column_5283,
    column_4361,
    column_7062,
    column_7063,
    column_7064,
    column_3120,
    column_7065,
    column_6162,
    column_6160,
    column_3081,
    column_1425,
    column_6375,
    column_6376,
    column_6640,
    column_6377,
    column_6378,
    column_6379,
    column_6380,
    column_3160,
    column_5569,
    column_5284,
    column_2857,
    column_08,
    column_5280,
    column_76,
    column_2031,
    column_7066,
    column_5252,
    column_7067,
    column_3393,
    column_5518,
    column_3158,
    column_6382)
AS
    SELECT
        -- ########## ####
        dataset_102.column_07, dataset_102.column_451, dataset_102.column_452,
        dataset_102.column_2721, dataset_102.column_7054, dataset_102.column_644, dataset_102.column_2728,
        dataset_102.column_2729, dataset_102.column_3759, dataset_102.column_7055,
        dataset_102.column_2560, dataset_102.column_1899  column_3063, dataset_102.column_3048,
        dataset_102.column_2710, dataset_102.column_3128,
        -- #### ####
        dataset_102.column_598, dataset_102.column_4127, dataset_102.column_6637, dataset_102.column_601,
        dataset_102.column_3815,
        -- ####### ####
        dataset_102.column_11, dataset_102.column_5253, dataset_102.column_986,
        dataset_102.column_714, dataset_102.column_604, dataset_102.column_4129,
        dataset_102.column_6620, dataset_102.column_7056,
        dataset_102.column_1446,
        -- ######## ####
        dataset_102.column_5514, dataset_102.column_708,
        dataset_102.column_712, dataset_102.column_711,
        dataset_102.column_709, dataset_102.column_710, dataset_102.column_2725,
        dataset_102.column_2726, dataset_102.column_2730,
        dataset_102.column_7068      column_4130,
        dataset_102.column_2723 column_4128,
        -- ######## ### ##
        dataset_102.column_4134, column_7069     column_7057,
        column_7070    column_4131,
        column_6562         column_6381              -- #########
                                                  ,
        CASE
            WHEN dataset_102.column_986 = '######'
            THEN GREATEST(dataset_102.column_2726 * (dataset_102.column_4129 - column_2723), 0)
            ELSE dataset_102.column_2726 * dataset_102.column_4129  
        END AS column_7058,
        CASE
            WHEN dataset_102.column_986 = '######'
            THEN GREATEST(dataset_102.column_2730 * (dataset_102.column_4129 - column_2723), 0)
            ELSE dataset_102.column_2730 * dataset_102.column_4129  
        END AS column_7059,
        CASE
            WHEN dataset_102.column_986 = '######'
            THEN GREATEST(dataset_102.column_2726 * (dataset_102.column_4129 - column_2723), 0)
            ELSE dataset_102.column_2726 * dataset_102.column_4129  
        END * column_6562         AS column_4132,
        CASE
            WHEN dataset_102.column_986 = '######'
            THEN GREATEST(dataset_102.column_2730 * (dataset_102.column_4129 - column_2723), 0)
            ELSE dataset_102.column_2730 * dataset_102.column_4129  
        END * column_6562         AS column_4133,
        -- ######: ###### ##### ### ### ## ####### #### #######
        dataset_102.column_2985, dataset_102.column_4126, dataset_102.column_2681,
        dataset_102.column_165, dataset_102.column_74, dataset_102.column_75, dataset_102.column_734,
        dataset_102.column_3147,dataset_102.column_3149, dataset_102.column_1025,
        dataset_102.column_7060,
        dataset_102.column_170, dataset_102.column_5248,
        dataset_102.column_2256,
        dataset_102.column_2661,
        dataset_102.column_3159,
        CASE
            WHEN dataset_102.column_986 = '######'
            THEN GREATEST(dataset_102.column_2726 * (dataset_102.column_4129 - column_2723), 0)
            ELSE dataset_102.column_2726 * dataset_102.column_4129  
        END / column_7070    AS column_7061,                      -- ######
        dataset_102.column_3084, dataset_102.column_6951, dataset_102.column_3045,
        dataset_102.column_3056, dataset_102.column_6933, dataset_102.column_5283,
        dataset_102.column_4361, dataset_102.column_7062,
        dataset_102.column_7063, dataset_102.column_7064,
        dataset_102.column_3120, dataset_102.column_7065,
        dataset_102.column_6162, dataset_102.column_6160,
        dataset_102.column_3081,dataset_102.column_1425,
        dataset_102.column_6375, dataset_102.column_6376,
        dataset_102.column_6640, dataset_102.column_6377,
        dataset_102.column_6378,
        dataset_102.column_6379,dataset_102.column_6380,
        dataset_102.column_3160 ,
        dataset_102.column_5569 ,
        dataset_102.column_5284,
        dataset_102.column_2857,
        dataset_102.column_08,
        dataset_102.column_5280,
        dataset_102.column_76,
        dataset_102.column_2031,
        dataset_102.column_7066,
        dataset_102.column_5252,
        dataset_102.column_7067,
        dataset_102.column_3393,
        dataset_102.column_5518,
        dataset_102.column_3158,
        dataset_102.column_6382      
    FROM (SELECT
                -- ########## ####
                dataset_333.column_07, dataset_333.column_451, dataset_333.column_452,
                dataset_333.column_3063       AS column_1899, dataset_333.column_3048,
                dataset_333.column_2710, dataset_333.column_3128,
                -- #####
                dataset_333.column_2721,
                TO_CHAR (dataset_333.column_2721, '####') AS column_7054,
                dataset_333.column_644, dataset_333.column_2728, dataset_333.column_2729,
                GREATEST (column_644, column_2728, NVL (column_2729, column_2728) ) AS column_3759,
                TO_CHAR(GREATEST (column_644, column_2728, NVL (column_2729, column_2728) ), '####' ) AS column_7055,
                dataset_333.column_2560,
                -- #######_####
                dataset_333.column_11,
                NVL (dataset_275.column_742, dataset_333.column_11) AS column_5253,
                dataset_275.column_986, dataset_275.column_714, dataset_275.column_604,
                NVL (dataset_1554.column_2662, 0) AS column_4129,
                dataset_1554.column_3064 AS column_6620,
                dataset_275.column_500 AS column_7056, dataset_275.column_1446,
                dataset_275.column_5514,
                -- ## ############
                -- ##########: ###########_########## #### ####### #######_########, #### ###
                NVL (UPPER (TRIM (dataset_335.column_179)), dataset_2712.column_7071 ) AS column_4134,
                NVL (dataset_2713.column_738, dataset_2714.column_738) AS column_7069,
                dataset_2715.column_738 AS column_7070,
                NVL(dataset_2713.column_738, dataset_2714.column_738) / dataset_2715.column_738 AS column_6562,
                -- #### #####, ### ## ###### ####
                CASE
                    WHEN dataset_275.column_986 = '#######'
                    THEN NVL (dataset_275.column_5508, 0)
                    ELSE dataset_333.column_2662 + dataset_333.column_2708 
                END AS column_2723,
                -- ######## ####                                                            ,
                dataset_333.column_708, dataset_333.column_712,
                dataset_333.column_711, dataset_333.column_709,
                dataset_333.column_710,
                dataset_333.column_2725,
                -- ########### ########
                CASE
                    -- ####### #### ##### ## ## ####### #####_#### ### ###### ####
                    -- #########_######## ## ### ##########
                    WHEN package_48.package_function_190(dataset_1286.column_2955) BETWEEN TRUNC(dataset_333.column_2721) AND TRUNC(dataset_333.column_2560)
                    THEN dataset_333.column_708
                             - dataset_333.column_712
                             - dataset_333.column_711
                             - dataset_333.column_709
                             - dataset_333.column_710      
                     ELSE 0
                END AS column_2726,
                -- ######### ########
                CASE
                    -- ##### ## ## ######, ############ ## ##########
                    -- #### ####### ## ### #### (#####)
                    -- ######### ######## ## ##########!
                    WHEN package_48.package_function_190(dataset_1286.column_2955) >=
                         GREATEST
                              (TRUNC(dataset_333.column_644),
                               TRUNC(dataset_333.column_2728),
                               TRUNC(NVL (dataset_333.column_2729, dataset_333.column_2728)))
                    -- #### ###### ## ## ## ### ###### ####### #####_#### ### ######_####
                    AND package_48.package_function_190(dataset_1286.column_2955) BETWEEN TRUNC(dataset_333.column_2721) AND TRUNC(dataset_333.column_2560)
                    THEN   dataset_333.column_708
                             - dataset_333.column_712
                             - dataset_333.column_711
                             - dataset_333.column_709
                             - dataset_333.column_710
                             - dataset_333.column_2725       
                    ELSE 0
                END AS column_2730,
                -- ####### ########
                dataset_333.column_712
                    + dataset_333.column_711
                    + dataset_333.column_709
                    + dataset_333.column_710       AS column_7068,
                dataset_86.column_3815, dataset_320.column_500 AS column_6637,
                dataset_320.column_4126, dataset_320.column_601, dataset_86.column_598,
                NVL (dataset_320.column_742, dataset_320.column_598) AS column_4127,
                -- ######: ###### ##### ### ### ## ####### #### #######
                dataset_333.column_2681,
                dataset_333.column_2985,
                dataset_45.column_165,
                dataset_45.column_74,
                dataset_45.column_75,
                dataset_45.column_734,
                CASE
                    WHEN dataset_2716.column_1425 = '#####' AND dataset_2717.column_7072 = '#' THEN dataset_333.column_3147     
                    WHEN dataset_2716.column_1425 = '###########' AND dataset_2717.column_7073 = '#' THEN dataset_333.column_3147     
                    ELSE dataset_45.column_3147     
                END AS column_3147,
                CASE
                     WHEN dataset_2716.column_1425 = '#####' AND dataset_2717.column_7072 = '#' THEN dataset_333.column_3149          
                    WHEN dataset_2716.column_1425 = '###########' AND dataset_2717.column_7073 = '#' THEN dataset_333.column_3149          
                    ELSE dataset_45.column_3149          
                END AS column_3149,
                dataset_45.column_1025,
                NULL AS column_7060,
                -- ####### ### ####### #######!
                dataset_45.column_170, dataset_45.column_5248,
                NULL AS column_2256,
                -- ####### ### ####### #######!
                dataset_45.column_2661, dataset_86.column_213 AS column_3159,        -- ######
                dataset_333.column_3084,
                dataset_333.column_6951,
                dataset_333.column_3045,
                dataset_333.column_3056,
                dataset_333.column_6933,
                dataset_45.column_5283,
                dataset_45.column_4361,
                dataset_284.column_742  AS column_7062,
                dataset_2718.column_742  AS column_7063,
                dataset_1286.column_604       AS column_7064,
                dataset_86.column_3120, dataset_320.column_7065,
                dataset_86.column_6162, dataset_86.column_6160
                ,dataset_333.column_3081,dataset_2716.column_1425,
                dataset_333.column_6375,
                dataset_333.column_6376,
                dataset_333.column_6640,
                CASE WHEN dataset_333.column_6375            is not null and dataset_333.column_6640              is null
                    THEN  '#'
                    ELSE  '#'
                END AS column_6377,
                dataset_320.column_6378,
                dataset_320.column_6379,
                dataset_320.column_6380 ,
                dataset_333.column_3160 ,
                dataset_333.column_5569 ,
                dataset_333.column_5284,
                dataset_333.column_2857,
                dataset_333.column_08,
                dataset_333.column_5280,
                dataset_333.column_76,
                dataset_333.column_2031,
                dataset_333.column_7066,
                NVL(dataset_86.column_742,dataset_86.column_451) AS column_5252,
                dataset_333.column_7067,
                dataset_333.column_3393,
                dataset_275.column_5518,
                dataset_333.column_3158,
                package_48.package_function_190(dataset_1286.column_2955) AS column_6382      
        FROM dataset_336 dataset_333,
             dataset_276 dataset_275,
             dataset_1555   dataset_1554,
             dataset_738             dataset_335,
             dataset_315    dataset_86,
             dataset_50   dataset_45,
             dataset_269 dataset_320,
             dataset_1155   dataset_2713,
             dataset_1155   dataset_2714,
             dataset_1155   dataset_2715,                          -- ######
             dataset_476 dataset_284,
             dataset_476 dataset_2718,
             dataset_276 dataset_1286,
             dataset_1288          dataset_2716,
             (SELECT
                    CASE
                        WHEN (SELECT COUNT (*) FROM dataset_1384   WHERE column_221 = '#######_########') = 0 THEN '###'
                        ELSE (SELECT UPPER(TRIM (VALUE)) FROM dataset_1384   WHERE column_221 = '#######_########')
                    END AS column_7071     
                    FROM dataset_62) dataset_2712,
             (SELECT DECODE(package_11.package_function_49 (
                            '#####',
                            '###########_######',
                            '###_############',
                            '#######_###_#####'), '##########', '#', '#') AS column_7073,
                     DECODE(package_11.package_function_49 (
                            '#####',
                            '#####_######',
                            '###_############',
                            '#######_###_#####'), '##########', '#', '#') AS column_7072    
                     FROM dataset_62) dataset_2717
        WHERE 1 = 1
            AND dataset_333.column_10 <> '#######'
            AND dataset_45.column_07 = dataset_333.column_07     
            AND dataset_86.column_451 = dataset_333.column_451      
            AND dataset_320.column_598 = dataset_86.column_598
            AND dataset_275.column_11 = dataset_333.column_11
            AND dataset_1286.column_11 = dataset_275.column_1446       
            AND dataset_2716.column_3081 =dataset_333.column_3081            
            -- ##### #### ######## ## #### ## ##### ## #####
            AND dataset_1554.column_11(+) = dataset_333.column_11
            AND dataset_1554.column_2736(+) = '#######'
            -- ##### #### ######## ## #### ## ########## ## #####
            AND dataset_335.column_07(+) = dataset_333.column_07     
            AND dataset_335.column_1622(+) = '#########_########'
            -- #### ##_####_###: ### ## #########_########
            -- ##### #### ## #### ## ### #####
            AND dataset_2713.column_532(+) = UPPER (TRIM (dataset_335.column_179))
            AND dataset_2713.column_2674(+) = '###'
            AND dataset_2713.column_2677(+) = '####'
            -- #### ##_###_###: ### ## ####### ########
            -- ##### #### ## #### ## ### #####
            AND dataset_2714.column_532(+) = dataset_2712.column_7071     
            AND dataset_2714.column_2674(+) = '###'
            AND dataset_2714.column_2677(+) = '####'
            -- #### ##_###_###: ### ## #######_########
            -- ##### #### ## #### ## ### #####
            AND dataset_2715.column_532(+) = dataset_275.column_604      
            AND dataset_2715.column_2674(+) = '###'
            AND dataset_2715.column_2677(+) = '####'
            -- ## ### #### ########### ## ### ######
            AND TRUNC(dataset_333.column_2721) <= package_48.package_function_190(dataset_1286.column_2955)
            -- ## ### #### ########### #### ######### #### ## ###### ### ###### = #######
            AND TRUNC(dataset_333.column_216) <= package_48.package_function_190(dataset_1286.column_2955)
            -- ######
            AND dataset_45.column_2661 = dataset_284.column_213(+)
            AND dataset_86.column_213 = dataset_2718.column_213(+)
              ) dataset_102
/              


                  
COMMIT
/

COMMENT ON COLUMN dataset_1634.column_3759     IS '### #### #### ### ########## ####### ########## (############). ######## ## #######, ########### ### ######## ####'
/
COMMENT ON COLUMN dataset_1634.column_2730         IS '######### ######## ## ######## ## (######### ############)'
/
COMMENT ON COLUMN dataset_1634.column_4133               IS '##### ## ########## ######## ## ######### ########'
/
COMMENT ON COLUMN dataset_1634.column_7059              IS '##### ## ########## ######## ## ####### ########'
/
COMMENT ON COLUMN dataset_1634.column_7055     IS '### #### #### ### ########## ####### ########## (############)'
/
COMMENT ON COLUMN dataset_1634.column_2721 IS '### #### ### ########## ### #######, ### ##### ####, ##### ####'
/
COMMENT ON COLUMN dataset_1634.column_708     IS '### ###### ## ######## ######### (#######, #######) ### ### ########## (######)'
/
COMMENT ON COLUMN dataset_1634.column_7054 IS '### #### ### ########## ### #######, ### ##### ####, ##### ####'
/
COMMENT ON COLUMN dataset_1634.column_452          IS '### ### ## ###### ########## ########## (###########_##, #############_##, ##########_########)'
/
COMMENT ON COLUMN dataset_1634.column_3159   IS '####### ##### ### ########## ### ####### = ##############.#######'
/
COMMENT ON COLUMN dataset_1634.column_170 IS '##### ####'
/
COMMENT ON COLUMN dataset_1634.column_712         IS '### ### ## ######## ##### ### ######### #### #### ########## (#####)'
/
COMMENT ON COLUMN dataset_1634.column_3063       IS '#.#. #####, ######## ###.'
/
COMMENT ON COLUMN dataset_1634.column_4128       IS '#### ##### ## ###### #####'
/
COMMENT ON COLUMN dataset_1634.column_4132            IS ''
/
COMMENT ON COLUMN dataset_1634.column_7061       IS ''
/
COMMENT ON COLUMN dataset_1634.column_7058           IS ''
/
COMMENT ON COLUMN dataset_1634.column_2729   IS '### #### #### ### (########) ######## ## ###### (##### ## ###)'
/
COMMENT ON COLUMN dataset_1634.column_709           IS '### ### ## ######## ##### ### ########### (####, ########### ###.) #### #### ########## (#####)'
/
COMMENT ON COLUMN dataset_1634.column_1025       IS '########## ######'
/
COMMENT ON COLUMN dataset_1634.column_710       IS '### ### ## ######## ##### ####### #### #### ########## (#####)'
/
COMMENT ON COLUMN dataset_1634.column_2560 IS '### #### #### ### ########## #######'
/
COMMENT ON COLUMN dataset_1634.column_74  IS '##### ####'
/
COMMENT ON COLUMN dataset_1634.column_711         IS '### ### ## ######## ##### ### ######### #### #### ########## (#####)'
/
COMMENT ON COLUMN dataset_1634.column_7057        IS '## #### ### ## ######### ########'
/
COMMENT ON COLUMN dataset_1634.column_4131       IS '## #### ### ## ####### ########'
/
COMMENT ON COLUMN dataset_1634.column_6381            IS '## #### ####### ######## ## ######### ########'
/
COMMENT ON COLUMN dataset_1634.column_2681 IS '# #####-####### ##### ##########. ######### ######## ### ######### #########!'
/
COMMENT ON COLUMN dataset_1634.column_2661  IS '#### #######'
/
COMMENT ON COLUMN dataset_1634.column_3128          IS '?'
/
COMMENT ON COLUMN dataset_1634.column_75 IS '#### ####'
/
COMMENT ON COLUMN dataset_1634.column_2726          IS '######### ######## (############ #### ####### ## ######## ### ### ##########)'
/
COMMENT ON COLUMN dataset_1634.column_2256             IS '#### ## ####? ######## ### ### ## ####### ####'
/
COMMENT ON COLUMN dataset_1634.column_07      IS '###### ######## #+ ########### ##########. ### ### ## ###### ########## ########## (###########_##, #############_##, ##########_########)'
/
COMMENT ON COLUMN dataset_1634.column_165           IS '####### ######## ######## ##, #.#. ### ### ### ###'
/
COMMENT ON COLUMN dataset_1634.column_3815        IS ''
/
COMMENT ON COLUMN dataset_1634.column_451       IS '### ### ## ###### ########## ########## (###########_##, #############_##, ##########_########)'
/
COMMENT ON COLUMN dataset_1634.column_734 IS '#######_##'
/
COMMENT ON COLUMN dataset_1634.column_598 IS '### #### ########## (= #### ####)'
/
COMMENT ON COLUMN dataset_1634.column_4127      IS '########### ## ### ####'
/
COMMENT ON COLUMN dataset_1634.column_6637     IS '#### ## ##### ##### ## ########### #######'
/
COMMENT ON COLUMN dataset_1634.column_601 IS '#### #### ## ####, #.#. ############_####, ###, ### ###.'
/
COMMENT ON COLUMN dataset_1634.column_4134        IS '######### ######## ######## ## ###########'
/
COMMENT ON COLUMN dataset_1634.column_714   IS '# ####### #### ######## ## ####### ####### #####, #.#. #####, ###, #### ###.'
/
COMMENT ON COLUMN dataset_1634.column_2725        IS '## ##### ### ### ####### ############, #### ######### ### ######## ########'
/
COMMENT ON COLUMN dataset_1634.column_2728      IS '### #### #### ### (########) ########### ## ###### (##### ## ###)'
/
COMMENT ON COLUMN dataset_1634.column_3147      IS '#### ## ######## ####### ### ########'
/
COMMENT ON COLUMN dataset_1634.column_3149           IS '#### ## ######## ######## ### ########'
/
COMMENT ON COLUMN dataset_1634.column_3048 IS '#### ### ########## ## #####, #.#. ###_##_####, ###_##_######## ###.'
/
COMMENT ON COLUMN dataset_1634.column_7060   IS '#### ## ####? ######## ### ### ## ####### ####.'
/
COMMENT ON COLUMN dataset_1634.column_2710       IS '######### ## ########## ## ### #######, #.#. #, ##, ###'
/
COMMENT ON COLUMN dataset_1634.column_5248      IS '### #### #### ### ########### #### ##########'
/
COMMENT ON COLUMN dataset_1634.column_4130         IS '### ######## ####### #### ### #####_########, ### ## #########, ########### ### ####### ########'
/
COMMENT ON COLUMN dataset_1634.column_5514              IS '?'
/
COMMENT ON COLUMN dataset_1634.column_1446        IS '########### ### ##### ## ## ########## #######. ######### ### ########## ## ### ###### #### ## ########## ##.'
/
COMMENT ON COLUMN dataset_1634.column_11 IS '####### ########## ### #### '
/
COMMENT ON COLUMN dataset_1634.column_604       IS '####### ########'
/
COMMENT ON COLUMN dataset_1634.column_5253         IS '####### ###########'
/
COMMENT ON COLUMN dataset_1634.column_4129   IS '####### ##### ######### ## #######_###### '
/
COMMENT ON COLUMN dataset_1634.column_6620        IS '#### ## ### ####### #####'
/
COMMENT ON COLUMN dataset_1634.column_7056        IS '####### #### #####'
/
COMMENT ON COLUMN dataset_1634.column_986   IS '# ####### ## ## # ####### ####, #.#. #####, ######, #### ###.'
/
COMMENT ON COLUMN dataset_1634.column_644   IS '### #### #### ### ########## ##### (##### ## ###)'
/

--######
COMMENT ON COLUMN dataset_1634.column_3084    IS '######### ## ###_##_#### ########## ## ######## ### ### ##########'
/
COMMENT ON COLUMN dataset_1634.column_6951     IS '##### #### ## ######### ### ######## ### ##### #### ######'
/
COMMENT ON COLUMN dataset_1634.column_3045    IS '"##### #### #### #####" ##### #### ### ########## ########'
/
COMMENT ON COLUMN dataset_1634.column_3056           IS '### ####### #### ## ## ### #### ### ########## ### ######. ##### ## ######### ## ####### #### ### ## ########### #######'
/
COMMENT ON COLUMN dataset_1634.column_6933 IS '#### ## ### #####, ########## ########### ##### #### ####### ## ### ######'
/
COMMENT ON COLUMN dataset_1634.column_5283     IS '############## ######### ##### #### ## ############# #########, #####, ######## ###.'
/
COMMENT ON COLUMN dataset_1634.column_4361                IS '######### #### ### ########## ######'
/
COMMENT ON COLUMN dataset_1634.column_7062        IS '#### ## ##### #######, #.#. ## = ###########'
/
COMMENT ON COLUMN dataset_1634.column_7063       IS '#### ## #### #######, #.#. ## = ##### ######'
/
COMMENT ON COLUMN dataset_1634.column_7064            IS '### ######## ## ### ########## #######'
/

--###-####

COMMENT ON COLUMN dataset_1634.column_6375                         IS '########## ########### #### ##### ####### ## #### ########## #### ### ########### #### #### ########## ###### '
/
COMMENT ON COLUMN dataset_1634.column_6376                      IS '### ########## ########### #### ##### ####### ### ### ########### ## ## ########## '
/
COMMENT ON COLUMN dataset_1634.column_6640                       IS '##### ########### #### #### ### ########## ##### ###### ## ####### '
/
COMMENT ON COLUMN dataset_1634.column_6377                         IS '####### ########## ## ####### ## ########### ####### '
/
COMMENT ON COLUMN dataset_1634.column_6378                        IS '######### ### #####, ##### ########### ##### ### #######. ######## ###### ### ####, #############, #######, #############_#######_#######, ########## '
/
COMMENT ON COLUMN dataset_1634.column_6379                        IS '######### ### ######## ##### #### ##### ############ ## #######. ############ ## ###### ### ##, ####_##, #### '
/
COMMENT ON COLUMN dataset_1634.column_6380                        IS '######### ### ######## ##### #### #### ############ ## #######. ############ ## ###### ### ##, ####_##, #### '
/
COMMENT ON COLUMN dataset_1634.column_3160                      IS '### #### ########## ########## ## ####### ####### ###### ########## ### ##### ##########'
/
--### ####
COMMENT ON COLUMN dataset_1634.column_5280                     IS '###### ### ######## ########## #### ######### #### ##########'
/

COMMENT ON COLUMN dataset_1634.column_5518        IS '### ##### ##### ## ### ############# #######'
/
COMMENT ON COLUMN dataset_1634.column_3158        IS '##### ## ## ###### ###########' 
/

COMMIT
/





