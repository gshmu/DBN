--### *********************************************************
--### * #######         : #####_#####_##_####_#####
--### * #########       : ###_###_######_####
--### * ###### #########: ####
--### * ######### ####  : ###_########_###
--### * #### ####       : ##_###_#####_##_####_#####.###
--### *
--### * ########        : ########
--### * #######         : ########
--### * ###########     : ##########
--### * ######## ####   : #######
--### * ###### ####     : %
--### * ##### ####      : %
--### * ######## ####   : ######_##_####_#####
--### * #########       : ##-###-#### ##:##:##
--### *********************************************************


--### *********************************************************

DECLARE 
BEGIN

  package_07.method_231
    ( argument_190       => '##_###_#####_##_####_#####.###'
     ,argument_191       => '#######'
     ,argument_192       => '####### #### '||USER||', ####### ###### '||SYS_CONTEXT('#######','#######_######')
    );

END;
/

--###
--### ######### ## : ##-###-#### ##:##:##
--###

  DELETE dataset_114
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_####_#########_####','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_##########_#####','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_#########_####','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_####_####','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_####_#########','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_####_#######','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_#######','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_######_####','##','############ ####','###_#####_#########','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_#####_#####','?','#','#','#','#','#','#','#','#','')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_###########','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_############','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_###########_###','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_##############','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_#####','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_####','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  INSERT INTO dataset_114 (column_1520,column_274,column_4890,column_441,column_276,column_270,column_13367,column_13368,column_271,column_13369,column_272,column_13370,column_273,column_13371,column_404) VALUES 
  ('#######','###_########_#######','###','############ ####','###_##_########','?','#','#','#','#','#','#','#','#','######_#####_#####')
/

  -- ###### ## ###### ##########: ##
  COMMIT
/

DECLARE 
BEGIN

  package_07.method_231
    ( argument_190       => '##_###_#####_##_####_#####.###'
     ,argument_191       => '#########'
     ,argument_192       => '####### #### '||USER||', ####### ###### '||SYS_CONTEXT('#######','#######_######')
    );

END;
/


