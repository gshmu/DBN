/******************************************************************************
    ##### #####: ########_####_#######
    #########:   ########_####
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### ######## #### ##### (####### #####)

    #######:
          (####)                           (####)

        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### #### (###########)
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_####                      ###### ####
        - #########                        #########
        - ########_#########               ######## #########
        - ########_#########               ######## #########
        - ####                             ####
        - ###########_####                 ########### ####
        - #####                            #####
        - ###                              ###
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########                         ########
        - ########_######                  ######## ######
        - #######_#####                    ####### #####
        - #######_#####                    ####### #####
        - ########                         ########
        - #######                          #######
        - ####_#####                       #### #####
        - #######_####                     ####### ####
        - ####_####_#                      #### #### #
        - ####_#####                       #### #####
        - ####_#####                       #### #####
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ####_#                           #### #
        - ##_#########                     ## #########
        - ##_#######                       ## #######
        - ##_###                           ##_###
        - ######                           ######
        - ####_####                        #### ####
        - ####_###                         #### ###
        - #####_######                     ##### ######
        - ####_######                      #### ######
        - #######                          #######
        - ##########_######                ########## ######
        - ####_#######                     #### #######
        - ####_#######                     #### #######
        - ####_####_#                      #### #### #
        - ####_####_#                      #### #### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - ####_#######_#                   #### ####### #
        - #####_####                       ##### ####
        - #####_####                       ##### ####

    ###### ## ###########:  ##(######## ####)||###(#######)||<####### ##### ##>||<#########>||<####.###########_###########_##>

    ####### ##
    ##.#.#    ##.##.####   ### #####    ####### ####
    ##.#.#    ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##
    ##.#.#    ##.##.####   ### #####    ###-##### ########_#### ###########-####
    ##.#.#    ##.##.####   ### #####    ###-##### ########_#### ########-#########
    ##.#.#    ##.##.####   ### #####    ###-##### ########_#### ##### ######## - ######### #######
*******************************************************************************/

SELECT
    column_354                    AS column_354,
    column_1117                     AS column_1117,
    column_2468                   AS column_2468,
    column_1328                   AS column_1328,
    column_1056                   AS column_1056,
    NULL                          AS column_7074,
    column_7075                     AS column_7075,
    column_7076                   AS column_7076,
    NULL                          AS column_7077,
    column_5861                          AS column_5861,
    column_7079                   AS column_7079,
    NULL                          AS column_7080,
    NULL                          AS column_7081,
    column_5704                    AS column_5704,
    column_2329                   AS column_2329,
    NULL                          AS column_7082,
    column_7083                   AS column_7083,
    column_874                      AS column_874,
    NULL                          AS column_7084,
    column_7085                   AS column_7085,
    column_1477                   AS column_1477,
    NULL                          AS column_549,
    NULL                          AS column_7086,
    NULL                          AS column_7087,
    column_563                    AS column_563,
    NULL                          AS column_7088,
    NULL                          AS column_7089,
    NULL                          AS column_7090,
    NULL                          AS column_7091,
    NULL                          AS column_7092,
    NULL                          AS column_7093,
    NULL                          AS column_7094,
    NULL                          AS column_7095,
    NULL                          AS column_7096,
    NULL                          AS column_7097,
    NULL                          AS column_7098,
    NULL                          AS column_7099,
    NULL                          AS column_7100,
    NULL                          AS column_7101,
    NULL                          AS column_7102,
    column_18107                     AS column_18107,
    NULL                          AS column_7104,
    column_753                    AS column_753,
    NULL                          AS column_18108,
    column_7105                       AS column_7105,
    column_534                    AS column_534,
    NULL                          AS column_7106,
    NULL                          AS column_7107,
    NULL                          AS column_7108,
    NULL                          AS column_7109,
    NULL                          AS column_7110,
    NULL                          AS column_7111,
    NULL                          AS column_7112,
    NULL                          AS column_7113,
    NULL                          AS column_7114
FROM (

    WITH dataset_263 AS(
        SELECT
            package_11.package_function_04(
            argument_01             => '#####',
            argument_40             => '##############',
            argument_18             => dataset_899.column_354,
            argument_41             => '########_####',
            argument_42             => '#######_#####') as column_2343  
        FROM dataset_62, dataset_360  dataset_899),

    dataset_943   AS (
        SELECT TRIM(regexp_substr(dataset_263.column_2343,'[^,]+', 1, LEVEL)) AS column_533  
        FROM dataset_263
        CONNECT BY regexp_substr(dataset_263.column_2343, '[^,]+', 1, LEVEL) IS NOT NULL),
    
    dataset_944           as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),
                        
    dataset_227  AS (
        SELECT DISTINCT
            dataset_228.column_527                 AS column_527,
            dataset_228.column_528                 AS column_528,
            dataset_228.column_529                 AS column_529,
            dataset_228.column_530                 AS column_530,
            dataset_228.column_531                 AS column_531,
            dataset_228.column_532                 AS column_532,
            dataset_228.column_533                 AS column_533,
            dataset_228.column_534                 AS column_534,
            package_131.package_function_134(dataset_228.column_527,
                dataset_228.column_528,dataset_228.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_229                  dataset_228, dataset_944           dataset_948 where dataset_228.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_230.column_527                  AS column_527,
            dataset_230.column_528                  AS column_528,
            dataset_230.column_529                  AS column_529,
            dataset_230.column_530                  AS column_530,
            dataset_230.column_531                  AS column_531,
            dataset_230.column_532                  AS column_532,
            dataset_230.column_533                  AS column_533,
            dataset_230.column_534                  AS column_534,
            package_131.package_function_134(dataset_230.column_527,
                dataset_230.column_528,dataset_230.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_231          dataset_230,dataset_944           dataset_948 where dataset_230.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_232.column_538                 AS column_527,
            dataset_232.column_539                 AS column_528,
            dataset_232.column_540                 AS column_529,
            dataset_232.column_541                 AS column_530,
            dataset_232.column_531                 AS column_531,
            dataset_232.column_542                 AS column_532,
            '#######'                      AS column_533,
            dataset_232.column_534                 AS column_534,
            package_131.package_function_134(dataset_232.column_538,
                dataset_232.column_539,dataset_232.column_540,dataset_948.column_2344) as column_535        
        FROM dataset_233           dataset_232,dataset_944           dataset_948 where dataset_232.column_541=dataset_948.column_591),

    dataset_947       AS (
        SELECT DISTINCT * FROM dataset_227  dataset_333
         WHERE dataset_333.column_531 = '####'
           AND dataset_333.column_533   IN (select column_533   from dataset_943)
         ORDER BY column_533, column_528, column_527),

    dataset_2720 AS (
        SELECT dataset_235.column_544,
               dataset_235.column_545,
               max(dataset_235.column_525) as column_525
          FROM dataset_226     dataset_235
         WHERE column_525 <= 
         GROUP BY
               column_544,
               column_545),

    dataset_236 AS (
        SELECT dataset_235.*
          FROM dataset_226     dataset_235, dataset_2720 dataset_237
         WHERE dataset_235.column_544 = dataset_237.column_544 
           AND dataset_235.column_545 = dataset_237.column_545  
           AND dataset_235.column_525 = dataset_237.column_525
           AND dataset_235.column_545 = '##########_####'),

    dataset_238           AS (
        SELECT DISTINCT
               dataset_235.column_548,
               dataset_240.column_550         
          FROM dataset_236 dataset_235,
               dataset_241              dataset_240
         WHERE dataset_240.column_548 = dataset_235.column_548),

    dataset_242  AS (
        SELECT /*+ ########### */ dataset_235.column_548,
               dataset_235.column_544,
               dataset_235.column_525                                                   AS column_2353,
               greatest(dataset_235.column_525, )                                                               AS column_525,
               dataset_235.column_545,
               dataset_235.column_549,
               dataset_235.column_549                                                     AS column_551,
                       CASE
                  WHEN TRUNC(dataset_235.column_525) < 
                  THEN dataset_235.column_548
                  WHEN dataset_254.column_550          IS NULL THEN dataset_235.column_548
                  ELSE dataset_254.column_550         
               END                                                              AS column_550,
               CASE
                  WHEN TRUNC(dataset_235.column_525) < 
                  THEN dataset_235.column_549
                  WHEN dataset_254.column_550          IS NULL THEN 0
                  ELSE dataset_2721.column_549
               END                                                              AS column_575     
          FROM dataset_236 dataset_235,
               dataset_238           dataset_254,
               dataset_226     dataset_2721,
               dataset_247      dataset_244
         WHERE trunc(dataset_235.column_525) <= 
           AND dataset_235.column_545 = '##########_####'
           AND dataset_235.column_548 = dataset_254.column_548
           AND dataset_235.column_544 = dataset_244.column_544 
           AND EXISTS (SELECT NULL FROM dataset_947       dataset_956 WHERE dataset_956.column_535 = dataset_244.column_535)
           AND dataset_2721.column_548 = nvl(dataset_254.column_550, dataset_235.column_548)),

     dataset_949                            as (
         SELECT  /*+ ########### */ dataset_950.column_76     
         FROM dataset_951                      dataset_950
            ,dataset_360  dataset_104
         WHERE column_2345 = 
           AND DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),

    dataset_952          AS (
        SELECT dataset_259.column_555,
               dataset_953.column_2346 AS column_76,
               dataset_953.column_2347      AS column_2348       
          FROM dataset_954             dataset_953,
               dataset_260      dataset_259
         WHERE dataset_953.column_2349 = '###_#######'
           AND dataset_953.column_354 = '###_#########'
           AND dataset_953.column_2350 = '######+'
           AND dataset_953.column_2351 = '###_########_######'
           AND dataset_953.column_221 = '#######_######'
           AND dataset_953.column_2352 = '*'
           AND dataset_953.column_2346 = dataset_259.column_76),

    dataset_2722           AS (
        SELECT dataset_953.column_2346 AS column_3063,
               dataset_953.column_2347      AS column_7115          
          FROM dataset_954             dataset_953
         WHERE dataset_953.column_2349 = '###_#######'
           AND dataset_953.column_354 = '###_#########'
           AND dataset_953.column_2350 = '######+'
           AND dataset_953.column_2351 = '###_########_######'
           AND dataset_953.column_221 = '############_####'
           AND dataset_953.column_2352 = '*'),
    
    dataset_8477      AS(
            SELECT dataset_268.column_599, dataset_45.column_598, dataset_45.column_601, dataset_8478.column_21144  || '#' || to_char(dataset_8478.column_11786, '########') as column_7115          
              FROM dataset_269 dataset_45
                  ,dataset_270 dataset_268
                  ,dataset_7670          dataset_8478
             WHERE dataset_45.column_598 = dataset_268.column_598
               AND dataset_8478.column_599 = dataset_268.column_599   
               AND dataset_45.column_601 IN ('##_####', '##_####')
    ),    
    dataset_8479         AS(
    SELECT dataset_244.*,
            CASE WHEN dataset_45.column_601 IN ('##_####', '##_####') 
                THEN dataset_45.column_7115          
                WHEN dataset_244.column_606 = '*' 
                THEN  NULL   
                ELSE dataset_2727.column_7115           
            END AS column_7115          
     FROM dataset_247      dataset_244
        LEFT OUTER JOIN dataset_8477      dataset_45 
           ON (dataset_244.column_558 = dataset_45.column_598
           AND dataset_244.column_606 = dataset_45.column_599
           ) 
        LEFT OUTER JOIN dataset_2722           dataset_2727
           ON (dataset_244.column_606 = dataset_2727.column_3063)
         ),
           
    dataset_2723      as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_####:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '########_####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),        
    
    dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_360  dataset_899,dataset_946  dataset_945),
   
    dataset_2725     AS(
        SELECT
            dataset_899.column_354                                               AS column_354,
            '#####'||dataset_899.column_122      ||'#'
                   || 
                   ||dataset_243.column_556                                       AS column_1117,
            '#'                                                           AS column_2468,
            package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)                  AS column_1328,
            TO_CHAR(dataset_243.column_567, '##/##/####')                    AS column_1056,
            dataset_244.column_573                                                   AS column_7075,
            NVL(dataset_243.column_568, dataset_243.column_569)   AS column_7076,
            dataset_243.column_564                                                AS column_7079,
            DECODE(dataset_244.column_558, '*', null, dataset_244.column_558)                     AS column_5704,
            dataset_899.column_122                                               AS column_2329,
            '#####'                                                       AS column_7083,
            dataset_244.column_532                                                 AS column_874,
            DECODE(dataset_243.column_552, '#', dataset_243.column_549, NULL)        AS column_7085,
            DECODE(dataset_243.column_552, '#', dataset_243.column_549, NULL)        AS column_1477,
            CASE WHEN column_565   in('########_############',
                                      '####_#######_############',
                                      '###_#########_######_####') 
                 THEN TO_CHAR(dataset_243.column_563, '##/##/####') 
                 ELSE TO_CHAR(dataset_243.column_566, '##/##/####') END           AS column_563,
            dataset_244.column_7115                                                AS column_18107,
            dataset_259.column_2348                                                AS column_753,
            dataset_244.column_7116                                                AS column_7105,
            dataset_244.column_2355                                                AS column_534,
            NULL                                                          AS column_5861                
        FROM
            dataset_242  dataset_253,
            dataset_241              dataset_240,
            dataset_246                 dataset_243,
            dataset_8479         dataset_244,
            dataset_360  dataset_899,
            dataset_952          dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE 1=1
            AND dataset_253.column_2353 = dataset_253.column_525
            AND dataset_240.column_548 = dataset_253.column_548
            AND dataset_243.column_556 = dataset_240.column_556            
            AND dataset_244.column_544 = dataset_243.column_544 
            AND dataset_244.column_531 = '####'
            AND dataset_259.column_555 = dataset_244.column_555       
            AND dataset_964.column_76 = dataset_259.column_76     
            and dataset_244.column_2356=dataset_2726.column_591
            and dataset_244.column_2356=dataset_962.column_591),

    dataset_2728    AS (
        SELECT
            dataset_899.column_354                                            AS column_354,
            '#####'||dataset_899.column_122      ||'#'
                   ||
                   ||dataset_259.column_2348       
                   ||dataset_244.column_535        
                   ||dataset_244.column_532   
                   ||dataset_244.column_7116 
                   ||dataset_244.column_2355                                    AS column_1117,
            '#'                                                        AS column_2468,
            package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)            AS column_1328,
            TO_CHAR(dataset_253.column_525, '##/##/####')                       AS column_1056,
            '#### #####: ####### #######'                              AS column_7075,
            '####### '||dataset_899.column_122      ||' '
                      ||dataset_259.column_2348       ||' '
                      ||dataset_244.column_7116 ||' '
                      ||DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558||' ')
                      ||DECODE(dataset_244.column_606, '*', NULL,
                               dataset_244.column_7115          ||' ')
                      ||TO_CHAR(dataset_253.column_525, '######')               AS column_7076,
            NULL                                                       AS column_7079,
            DECODE(dataset_244.column_558, '*', null, dataset_244.column_558)                  AS column_5704,
            dataset_899.column_122                                            AS column_2329,
            '#####'                                                    AS column_7083,
            dataset_244.column_532                                              AS column_874,
            NULL                                                       AS column_7085,
            SUM(dataset_253.column_549)                                           AS column_1477,
            NULL                                                       AS column_563,
            dataset_244.column_7115                                             AS column_18107,
            dataset_259.column_2348                                             AS column_753,
            dataset_244.column_7116                                             AS column_7105,
            dataset_244.column_2355                                             AS column_534,
            NULL                                                       AS column_5861     
        FROM
            dataset_242  dataset_253,
            dataset_8479         dataset_244,
            dataset_360  dataset_899,
            dataset_952          dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE 1=1
            AND dataset_244.column_544 = dataset_253.column_544 
            AND dataset_244.column_531 = '####'
            AND dataset_259.column_555 = dataset_244.column_555       
            AND dataset_964.column_76 = dataset_259.column_76     
            AND (dataset_253.column_551      <> 0 OR dataset_253.column_575      <> 0)
            and dataset_244.column_2356=dataset_2726.column_591
            and dataset_244.column_2356=dataset_962.column_591
        GROUP BY
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_253.column_525,
            dataset_259.column_2348,
            dataset_244.column_532,
            dataset_244.column_7116,
            dataset_244.column_535,
            dataset_244.column_2355,
            dataset_244.column_558,
            dataset_244.column_606,
            dataset_244.column_7115,
            dataset_2726.column_2344,dataset_962.column_2354),

    dataset_2729    AS (
        SELECT
            dataset_899.column_354                                            AS column_354,
            '#####'||dataset_899.column_122      ||'#'
                   ||
                   ||dataset_259.column_2348       
                   ||dataset_244.column_535        
                   ||dataset_244.column_532   
                   ||dataset_244.column_7116 
                   ||dataset_244.column_2355                                    AS column_1117,
            '#'                                                        AS column_2468,
            package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354)             AS column_1328,
            TO_CHAR(dataset_253.column_525, '##/##/####')                       AS column_1056,
            '#### #####: ####### #######'                              AS column_7075,
            '####### '||dataset_899.column_122      ||' '
                      ||dataset_259.column_2348       ||' '
                      ||dataset_244.column_7116 ||' '
                      ||DECODE(dataset_244.column_558, '*', NULL, dataset_244.column_558||' ')
                      ||DECODE(dataset_244.column_606, '*', NULL,
                               dataset_244.column_7115          ||' ')
                      ||TO_CHAR(dataset_253.column_525-1, '######')             AS column_7076,
            NULL                                                       AS column_7079,
            DECODE(dataset_244.column_558, '*', null, dataset_244.column_558)                  AS column_5704,
            dataset_899.column_122                                            AS column_2329,
            '#####'                                                    AS column_7083,
            dataset_244.column_532                                              AS column_874,
            SUM(dataset_253.column_575)                                    AS column_7085,
            NULL                                                       AS column_1477,
            NULL                                                       AS column_563,
            dataset_244.column_7115                                             AS column_18107,
            dataset_259.column_2348                                             AS column_753,
            dataset_244.column_7116                                             AS column_7105,
            dataset_244.column_2355                                             AS column_534,
            NULL                                                       AS column_5861     
        FROM
            dataset_242  dataset_253,
            dataset_226     dataset_235,
            dataset_8479         dataset_244,
            dataset_360  dataset_899,
            dataset_952          dataset_259,
            dataset_949                            dataset_964,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE 1=1
            AND dataset_235.column_548 = dataset_253.column_550         
            AND dataset_244.column_544 = dataset_235.column_544 
            AND dataset_244.column_531 = '####'
            AND dataset_259.column_555 = dataset_244.column_555       
            AND dataset_964.column_76 = dataset_259.column_76     
            AND (dataset_253.column_551      <> 0 OR dataset_253.column_575      <> 0)
            and dataset_244.column_2356=dataset_2726.column_591
            and dataset_244.column_2356=dataset_962.column_591
        GROUP BY
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_253.column_525,
            dataset_259.column_2348,
            dataset_244.column_532,
            dataset_244.column_7116,
            dataset_244.column_535,
            dataset_244.column_2355,
            dataset_244.column_558,
            dataset_244.column_606,
            dataset_244.column_7115,
            dataset_2726.column_2344,
            dataset_962.column_2354),
    --### : #### ###### ### # ######## ### ###:#####
    dataset_8480 AS (
        SELECT  /*+ ########### */
            column_534               AS column_534,
            column_530               AS column_530,
            column_532               AS column_532,
            column_724               AS column_724,
            column_76               AS column_76,
            package_131.package_function_134(column_527,
                    column_528,column_529,dataset_2726.column_2344) as column_535        
        FROM
            (
                SELECT
                    dataset_228.column_527               AS column_527,
                    dataset_228.column_528               AS column_528,
                    dataset_228.column_529               AS column_529,
                    dataset_228.column_534               AS column_534,
                    dataset_228.column_530               AS column_530,
                    dataset_228.column_532               AS column_532,
                    dataset_228.column_724               AS column_724,
                    (select package_54.package_function_165 
                            (argument_01                => '#####',
                             argument_370               => dataset_228.column_724,
                             argument_17                    => '#'
                             ) from dataset_62) as column_76,
                    100 AS column_500,
                    RANK() OVER(
                        PARTITION BY dataset_228.column_532, dataset_228.column_724,column_534       
                        ORDER BY
                            dataset_228.column_1328
                    ) AS column_220
                FROM
                    dataset_229                  dataset_228
                WHERE
                    1 = 1
                    AND dataset_228.column_533 = '########'
                UNION ALL
                SELECT
                    dataset_230.column_527               AS column_527,
                    dataset_230.column_528               AS column_528,
                    dataset_230.column_529               AS column_529,
                    dataset_230.column_534               AS column_534,
                    dataset_230.column_530               AS column_530,
                    dataset_230.column_532               AS column_532,
                    dataset_230.column_724               AS column_724,
                     (select package_54.package_function_165 
                            (argument_01                => '#####',
                             argument_370               => dataset_230.column_724,
                             argument_17                    => '#'
                             ) from dataset_62) as column_76,
                    10 AS column_500,
                    RANK() OVER(
                        PARTITION BY column_532, column_724,column_534       
                        ORDER BY
                            column_896
                    ) AS column_220
                FROM
                    dataset_231          dataset_230
                WHERE
                    1 = 1
                    AND dataset_230.column_533 = '########'
                    AND NOT EXISTS (
                        SELECT
                            *
                        FROM
                            dataset_229                  dataset_8481
                        WHERE
                            1 = 1
                            AND dataset_8481.column_533 = '########'
                            AND dataset_8481.column_532 = dataset_230.column_532   
                            AND dataset_8481.column_724 = dataset_230.column_724
                            --### ####.##########_###### = ##.##########_######
                    )
            )dataset_4877, dataset_2723      dataset_2726
        WHERE dataset_4877.column_530=dataset_2726.column_591
            and column_220 = 1
        ORDER BY
            column_500 DESC
    ),
    dataset_8482 as(select  /*+ ########### */ 
                        column_642,
                        column_643,
                        column_2556,
                        column_7374,
                        column_724,
                        column_7373,
                        column_12732        
                from dataset_1247          dataset_1248 
                    where dataset_1248.column_204 >  
                         and dataset_1248.column_204 <=    ),
    dataset_899 as( select column_354,column_122, column_753   from dataset_360) ,
    dataset_8483        as (SELECT  /*+ ########### */ 
                                    dataset_7620.column_642,
                                    dataset_7620.column_643,
                                    dataset_1248.column_724,
                                     MAX(CASE 
                                        WHEN dataset_899.column_753 = '#############_##' AND
                                            package_54.package_function_165 
                                                (argument_01              => '#####',
                                                 argument_370             => dataset_1248.column_724,
                                                 argument_17                  => '#'
                                                 ) = '###_##_##' THEN
                                             DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                                         WHEN package_54.package_function_165 
                                                (argument_01              => '#####',
                                                 argument_370             => dataset_1248.column_724,
                                                 argument_17                  => '#'
                                                 ) = '###_##' THEN
                                              DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                                    END ) AS column_2332
                            FROM dataset_8482 dataset_1248,
                                 dataset_2340              dataset_7620,
                                 dataset_269 dataset_45,
                                 dataset_360  dataset_899
                            WHERE
                                1 = 1
                                AND dataset_7620.column_598 = dataset_45.column_598
                                AND dataset_7620.column_642 = dataset_1248.column_642 
                                AND dataset_7620.column_643 = dataset_1248.column_643     
                            GROUP BY
                                dataset_7620.column_642,
                                dataset_7620.column_643,
                                dataset_1248.column_724)
    ,dataset_8484 as(   
    SELECT 
            dataset_2821.column_642,
            dataset_2821.column_643,
            dataset_2821.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535         column_24038,
            dataset_228.column_534             AS column_16446,  
            to_number(package_131.package_function_140(,dataset_1246.column_7374,   sum(dataset_2821.column_12721) ))column_7704,
            dataset_1246.column_13942                  column_24039,
            '######## - ##### ########' column_7075,
            '#####' column_24040,
            '#' column_24041,
            dataset_86.column_598 
        FROM
            dataset_8482,
            dataset_654          dataset_1246,
            dataset_2822          dataset_2821,
            dataset_8480 dataset_228,
            dataset_315    dataset_86,
            dataset_8483        dataset_8485            
        WHERE
            dataset_1246.column_642 = dataset_2821.column_642 
            AND dataset_228.column_532 = dataset_1246.column_7374      
            AND dataset_228.column_76 = dataset_2821.column_76      
            AND dataset_1246.column_643 = dataset_2821.column_643     
            AND dataset_2821.column_451=dataset_86.column_451      
            AND dataset_8485.column_642=dataset_8482.column_642  
            AND dataset_8485.column_643=dataset_8482.column_643      
            AND nvl(dataset_8485.column_2332,dataset_228.column_534)=dataset_228.column_534       
            AND dataset_8485.column_724 = dataset_228.column_724            
            AND  dataset_2821.column_642=dataset_8482.column_642 
            AND dataset_2821.column_643=dataset_8482.column_643     
            AND dataset_2821.column_2556= dataset_8482.column_2556            
         GROUP BY
            dataset_2821.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535,
            dataset_1246.column_13942,
            dataset_2821.column_642,
            dataset_2821.column_643,dataset_228.column_534,
            dataset_86.column_598)
    ,dataset_8486 as(  
    select 
             dataset_2821.column_642,
            dataset_2821.column_643,
            dataset_2821.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535         column_24038,
            dataset_228.column_534             AS column_16446, 
            to_number(package_131.package_function_140(,dataset_1246.column_7374,   SUM(dataset_4790.column_2022)))column_7704,
            dataset_1246.column_13942                  column_24039,
            '######## - '||CASE WHEN dataset_4790.column_2023='###_###' THEN '###### ########### ###'
            when dataset_4790.column_2023='###_###' THEN '### ########### ###' 
            when dataset_4790.column_2023='#####' THEN '########### ###' ELSE dataset_4790.column_2023 END column_7075,
            CASE WHEN dataset_4790.column_2023='###_###' THEN '####'
            when dataset_4790.column_2023='###_###' THEN '###' 
            when dataset_4790.column_2023='#####' THEN '###########' ELSE dataset_4790.column_2023 END column_24040,
            '#' column_24041,
            NULL column_598
            from
            dataset_654          dataset_1246,
            dataset_2822          dataset_2821,
            dataset_4787               dataset_4790,
            dataset_8480 dataset_228,
            dataset_8482,
            dataset_8483        dataset_8485
            where 
            dataset_1246.column_642 = dataset_2821.column_642 
            AND dataset_228.column_532 = dataset_1246.column_7374      
            AND dataset_228.column_76 = dataset_2821.column_76      
            AND dataset_1246.column_642=dataset_8485.column_642  
            AND dataset_1246.column_643=dataset_8485.column_643      
            AND nvl(dataset_8485.column_2332,dataset_228.column_534)=dataset_228.column_534       
            AND dataset_8485.column_724 = dataset_228.column_724            
            AND dataset_1246.column_643 = dataset_2821.column_643     
            AND dataset_2821.column_642 = dataset_4790.column_642  
            AND dataset_2821.column_643 = dataset_4790.column_643      
            AND dataset_2821.column_07 = dataset_4790.column_07      
            AND dataset_2821.column_451 = dataset_4790.column_451       
            AND dataset_2821.column_452 = dataset_4790.column_452         
            AND dataset_2821.column_642=dataset_8482.column_642 
            AND dataset_2821.column_643=dataset_8482.column_643     
            AND dataset_2821.column_2556= dataset_8482.column_2556            
          GROUP BY
            dataset_2821.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535,
            dataset_1246.column_13942,
            dataset_2821.column_642,
            dataset_2821.column_643,dataset_228.column_534,
            column_2023)
           
    ,dataset_8487 as( 
    select        
             dataset_1248.column_642,
            dataset_1248.column_643,
            dataset_228.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535         column_24038,
            dataset_228.column_534             AS column_16446, 
             to_number(package_131.package_function_140(,dataset_1246.column_7374,SUM(nvl(dataset_4519.column_735, 0))))column_7704,
           dataset_1246.column_13942                  column_24039, 
           '######## - #### - '||dataset_4519.column_1418 column_7075,
           '####' column_24042,
           '#' column_24041,
           NULL column_598
           from
           dataset_654          dataset_1246,
           dataset_8482 dataset_1248,
           dataset_6207              dataset_4519,
           dataset_8480 dataset_228,
           dataset_8483        dataset_8485
            where
            dataset_1246.column_642 = dataset_1248.column_642 
            AND dataset_228.column_532 = dataset_1248.column_7374      
            AND dataset_228.column_724 = dataset_1248.column_724            
            AND dataset_1246.column_642=dataset_8485.column_642  
            AND dataset_1246.column_643=dataset_8485.column_643     
            AND nvl(dataset_8485.column_2332,dataset_228.column_534)=dataset_228.column_534        
            AND dataset_8485.column_724 = dataset_228.column_724                        
            AND dataset_1246.column_643 = dataset_1248.column_643     
            AND dataset_1248.column_2556 = dataset_4519.column_2556            
         GROUP BY
         dataset_228.column_76,
            dataset_1246.column_7374,
            dataset_228.column_535,
            dataset_1246.column_13942,
            dataset_1248.column_642,
            dataset_1248.column_643,dataset_228.column_534,
            dataset_4519.column_1418)
    ,dataset_8488 as(   
    select column_642,
        column_643,
        column_76,
        column_7374,
        column_24038,
        column_16446,
        to_number(package_131.package_function_140(,column_7374,SUM(column_7373)))column_7704,
        column_13942                  column_24039,
        column_24043  column_7075,
        column_24042,
        '#' column_24041,
        NULL column_598 
        from
        (select        
            dataset_1248.column_642,
            dataset_1248.column_643,
            dataset_228.column_76      column_76,
            dataset_1246.column_7374,
            dataset_228.column_535         column_24038,
            dataset_228.column_534             AS column_16446,  
            dataset_1248.column_7373                 column_7373,
            '######## - '||case when dataset_1246.column_2999 = '#' then ' ######## ######' 
           when dataset_1246.column_2999 = '#' and dataset_1248.column_12732='######' THEN '######## ########'
           WHEN dataset_1246.column_2999 = '#' and dataset_1248.column_12732       !='######'THEN '######## ########' ELSE NULL END column_24043,
           case when dataset_1246.column_2999 = '#' then ' ########' 
           when dataset_1246.column_2999 = '#' and dataset_1248.column_12732='######' THEN '########'
           WHEN dataset_1246.column_2999 = '#' and dataset_1248.column_12732       !='######'THEN '########' ELSE NULL END column_24042,
            dataset_1246.column_13942                 
           from
           dataset_654          dataset_1246,
           dataset_8482 dataset_1248,
           dataset_8480 dataset_228,
           dataset_8483        dataset_8485
            where
            dataset_1246.column_642 = dataset_1248.column_642 
            AND dataset_228.column_532 = dataset_1248.column_7374      
            AND dataset_228.column_724 = dataset_1248.column_724            
            AND dataset_1246.column_642=dataset_8485.column_642  
            AND dataset_1246.column_643=dataset_8485.column_643      
            AND nvl(dataset_8485.column_2332,dataset_228.column_534)=dataset_228.column_534         
            AND dataset_8485.column_724 = dataset_228.column_724                        
            AND dataset_1246.column_643 = dataset_1248.column_643)dataset_8489 
         GROUP BY
            column_76,
            column_7374,
            column_24038,
            column_13942,
            column_642,
            column_643,
            column_16446,
            column_24043,column_24042),
    dataset_8490                as(
    select * from  dataset_8484  UNION ALL
    select * from dataset_8486     UNION ALL
    select * from dataset_8487 UNION ALL
    select * from dataset_8488),
    dataset_8491   as( select  column_642,
      column_643, 
      column_76, 
      column_7374, 
      column_24038, 
      column_16446,
    column_24044 column_7704,
     column_24039, 
      '######## - ####### #######' column_7075, 
      '####### #######' column_24040, 
      CASE WHEN column_24044 < 0 THEN '#'
                ELSE '#'
            END column_24041,
      NULL column_598
      from (
      select column_642,
      column_643, 
      column_76, 
      column_7374, 
      column_24038, 
      column_16446, 
      (SUM(CASE WHEN column_24041='#' THEN column_7704     END)-SUM(CASE WHEN column_24041='#' THEN column_7704     END)) column_24044,
      column_24039
      from dataset_8490               
        GROUP BY
            column_76,
            column_7374,
            column_24038,
            column_24039 ,
            column_642,
            column_643,
            column_16446)where column_24044 <>0),
     dataset_8492 as(
    select * from  dataset_8490                UNION ALL
      SELECT * FROM  dataset_8491
      )
        SELECT dataset_201.*, 1 as column_24045 FROM dataset_2725     dataset_201 UNION ALL
        SELECT dataset_201.*, 2 as column_24045 FROM dataset_2729    dataset_201 UNION ALL
        SELECT dataset_201.*, 3 as column_24045 FROM dataset_2728    dataset_201 UNION ALL
    SELECT
        dataset_899.column_354                             AS column_354,
        '#####'||dataset_899.column_122      ||'#'||dataset_8493.column_642 ||dataset_8493.column_643                               AS column_1117,
        '#'                                         AS column_2468,
        dataset_8493.column_24038                         AS column_1328,
        TO_CHAR(nvl(dataset_8493.column_24039,sysdate), '##/##/####')       AS column_1056,
        dataset_8493.column_7075                               AS column_7075,
        column_24040||' '||dataset_259.column_2348       ||' '|| 
        package_381.package_function_413
        (argument_01            => , 
        argument_552 => NULL, 
        argument_650    => NULL, 
        argument_161      => '########_#######', 
        argument_680        => NULL, 
        argument_679          => NULL, 
        argument_73      => dataset_8493.column_76,
        argument_252   => dataset_899.column_753,
        argument_672        => column_16446) ||' '||column_598||' '||TO_CHAR(dataset_8493.column_24039, '##/##/####')       
                                                    AS column_7076,
        NULL                                        AS column_7077,
        DECODE(column_598, '*', null, column_598)                 AS column_5704,
        dataset_899.column_122                             AS column_2329,
        '#####'                                     AS column_7083,
        dataset_8493.column_7374                             AS column_874,
        DECODE(dataset_8493.column_24041, '#',dataset_8493.column_7704, NULL) AS column_7085,
        DECODE(dataset_8493.column_24041, '#',dataset_8493.column_7704, NULL) AS column_1477,
        TO_CHAR(SYSDATE, '##/##/####')              AS column_563,
        NULL                                        AS column_18107,
         dataset_259.column_2348                             AS column_753,
        --####                                        ##  ####,
        package_381.package_function_413
        (argument_01            => , 
        argument_552 => NULL, 
        argument_650    => NULL, 
        argument_161      
        => '########_#######', 
        argument_680        => NULL, 
        argument_679          => NULL, 
        argument_73      => dataset_8493.column_76,
        argument_252     => dataset_899.column_753,
        argument_672        => column_16446)
                                                   AS column_7105,
        column_16446                               AS column_534,
        DECODE(dataset_8493.column_7075,'######## - ####### #######','######',NULL) column_5861,
        4                                          AS column_24045
    FROM
        dataset_8492 dataset_8493,
        dataset_899,
        dataset_952          dataset_259,
        dataset_949                            dataset_964
    WHERE dataset_8493.column_76 = dataset_259.column_76     
      AND dataset_8493.column_76 = dataset_964.column_76)
    ORDER BY
        column_753,
        column_1328,
        column_874,
        column_534,
        column_7105,
        column_24045
