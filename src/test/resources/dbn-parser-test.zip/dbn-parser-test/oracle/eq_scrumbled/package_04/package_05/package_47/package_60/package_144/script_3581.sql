with dataset_1981 as (select /*+ ########### */ * 
                      FROM dataset_1634                  dataset_1981
                     WHERE dataset_1981.column_07 = )
select column_3118,column_6558,column_6383,
CASE WHEN column_10 = '########,###_########' THEN '###_########'
WHEN column_10 = '########' THEN '#####_########' ELSE '###_########'
END as column_10
FROM
(select column_3118,column_6558,column_6383,listagg(column_28041,',') WITHIN GROUP (ORDER BY column_28041) as column_10
FROM
(select dataset_2484.column_3118,
DECODE(dataset_461.column_6384,'######_####', dataset_1981.column_4126,'####', dataset_1981.column_598,'#############_####', dataset_1981.column_598 || dataset_1981.column_3120,'#############', dataset_1981.column_451 ) column_6383,
DECODE(dataset_461.column_6384,'######_####', NVL(dataset_2538.column_742, dataset_1981.column_4126),'####', NVL(dataset_1981.column_4127, dataset_1981.column_598), '#############_####', NVL(dataset_2539.column_742, nvl(dataset_1981.column_4127, dataset_1981.column_598) || ' ' || dataset_1981.column_3120),'#############', NVL(dataset_86.column_742, dataset_1981.column_451)) column_6558,
CASE
    WHEN dataset_461.column_3119 = '####'
         AND dataset_1981.column_2726 - dataset_1981.column_2725 = 0
         AND dataset_1981.column_709 + dataset_1981.column_2725 > 0 THEN '###_########'
    WHEN dataset_461.column_3119 = '####'
         AND ( dataset_8358.column_2985   IS NOT NULL
               OR ( dataset_8359.column_2985   IS NOT NULL
                    AND dataset_8359.column_1028 = '####_######_########' ) ) THEN '###_########'
    WHEN dataset_1981.column_6382 > dataset_1981.column_2560
         AND dataset_461.column_3119 = '####' THEN '###_########'
    WHEN dataset_1981.column_2726 - dataset_1981.column_2725 = 0 THEN '########'
    ELSE CASE
        WHEN dataset_1981.column_6382 < dataset_1981.column_3759     THEN '###_########'
        ELSE CASE
            WHEN dataset_1981.column_3084 = '#' AND  = '#'
                 THEN '###_########'
            ELSE '###_########'
        END
    END
END column_28041   
FROM dataset_1981 dataset_1981,dataset_2483      dataset_2484,dataset_2485 dataset_461,dataset_315    dataset_86,dataset_2544        dataset_2539,dataset_269 dataset_2538,
(SELECT
    dataset_8360.column_2985,dataset_1271.column_07     
FROM
    dataset_2748                dataset_1271,dataset_1299          dataset_8360
WHERE
    dataset_8360.column_1028 = dataset_1271.column_599   
    AND dataset_1271.column_7147 = '#########'
    AND dataset_8360.column_3466 = '####_#####_##'
    AND dataset_1271.column_1868   IN ('####_######','####_##########','####_########')
) dataset_8358,
(  SELECT dataset_8361.column_2985,dataset_8361.column_1028  FROM
            dataset_1299          dataset_8361
         WHERE
            dataset_8361.column_3466='##########_######') dataset_8359
where dataset_1981.column_07 = 
AND dataset_2484.column_598 = dataset_1981.column_598
AND NVL (dataset_2484.column_714, dataset_1981.column_714) = dataset_1981.column_714  
AND NVL (dataset_2484.column_1446,dataset_1981.column_1446) = dataset_1981.column_1446       
AND dataset_461.column_3118 = dataset_2484.column_3118   
AND dataset_461 .column_3119   != '########'
 AND (  (dataset_461.column_3119 = '####'
         AND (dataset_1981.column_710 > 0
        OR (dataset_1981.column_711>0
                 AND (dataset_8358.column_2985   IS NOT NULL OR dataset_8359.column_2985   is not null))
        OR (dataset_1981.column_2726 - dataset_1981.column_2725=0 AND  dataset_1981.column_709 + dataset_1981.column_2725 > 0)
        )
        )
        OR (dataset_461.column_6385 = '#' AND dataset_1981.column_2726 - dataset_1981.column_2725 = 0)
        OR (dataset_1981.column_2726 - dataset_1981.column_2725 > 0)
      )
AND dataset_1981.column_2985 = dataset_8358.column_2985(+)
AND dataset_1981.column_07 = dataset_8358.column_07(+)
AND dataset_1981.column_2985 = dataset_8359.column_2985(+)
AND dataset_1981.column_451 = dataset_86.column_451      
AND dataset_1981.column_598 = dataset_2539.column_598
AND dataset_1981.column_3120 = dataset_2539.column_3120       
AND dataset_1981.column_4126 = dataset_2538.column_598 (+)
GROUP BY dataset_2484.column_3118,
DECODE(dataset_461.column_6384,'######_####', dataset_1981.column_4126,'####', dataset_1981.column_598,'#############_####', dataset_1981.column_598 || dataset_1981.column_3120,'#############', dataset_1981.column_451 ),
DECODE(dataset_461.column_6384,'######_####', NVL(dataset_2538.column_742, dataset_1981.column_4126),'####', NVL(dataset_1981.column_4127, dataset_1981.column_598), '#############_####', NVL(dataset_2539.column_742, nvl(dataset_1981.column_4127, dataset_1981.column_598) || ' ' || dataset_1981.column_3120),'#############', NVL(dataset_86.column_742, dataset_1981.column_451)),
CASE
    WHEN dataset_461.column_3119 = '####'
         AND dataset_1981.column_2726 - dataset_1981.column_2725 = 0
         AND dataset_1981.column_709 + dataset_1981.column_2725 > 0 THEN '###_########'
    WHEN dataset_461.column_3119 = '####'
         AND ( dataset_8358.column_2985   IS NOT NULL
               OR ( dataset_8359.column_2985   IS NOT NULL
                    AND dataset_8359.column_1028 = '####_######_########' ) ) THEN '###_########'
    WHEN dataset_1981.column_6382 > dataset_1981.column_2560
         AND dataset_461.column_3119 = '####' THEN '###_########'
    WHEN dataset_1981.column_2726 - dataset_1981.column_2725 = 0 THEN '########'
    ELSE CASE
        WHEN dataset_1981.column_6382 < dataset_1981.column_3759     THEN '###_########'
        ELSE CASE
            WHEN dataset_1981.column_3084 = '#' AND  = '#'
            THEN '###_########'
            ELSE '###_########'
        END
    END
END)
GROUP BY column_3118,column_6558,column_6383)