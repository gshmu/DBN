--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_####_#########.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        #######
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_####_#########';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_####_######### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_05
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_5635
      ,column_2167
      ,column_5636
      ,column_5637
      ,column_5638
      ,column_5639
      ,column_2198
      ,column_5640
      ,column_5641
      ,column_5642
      ,column_2199
      ,column_5643
      ,column_5644
      ,column_2197
      ,column_5645
      ,column_5646
      ,column_5647            
  FROM dataset_913@dblink_02.EQ
/


COMMIT
/
       





