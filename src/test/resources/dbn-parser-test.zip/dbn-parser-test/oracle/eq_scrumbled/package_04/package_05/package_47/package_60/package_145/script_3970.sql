/******************************************************************************
    ##### #####: #######_#########_######
    #########:   #######_#########_######
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### #######_#########_###### ##### (####### #####)

    #######:
          (####)                           (####)

        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - #####_####					   ##### ## ####
        - #######_######                   ####### ######
        - #######_##                       ### ####### ##
        - #######_######                   ####### ######
        - ####                             ####
        - ####                             ####
        - ########                         ########
        - #######                          #######
        - ######_#                         ###### #
        - ######_#                         ###### #
        - ###########_#######              ########### #######
        - #######_######_#######           ####### ###### #######


    ###### ## ###########:  
							###(####### ######### ######)
							||###(#######)
							||<####### ##### ##>
							|| # (#########)
							|| :#_###_##
							|| ###.###_#######_######
							|| #.###_#######_######
							|| #.####_##
							|| #.####
							|| #.########_####
							|| #.#######_####
*******************************************************************************/

SELECT column_1117              AS column_1117,
       column_12270                   AS column_12270,
       column_354             AS column_354,
       column_1328            AS column_1328,
       column_76              AS column_76,
       column_598                   AS column_598,
       column_562                   AS column_562,
       column_874               AS column_874,
       column_7105                AS column_7105,
       column_12271               AS column_12271,
       column_21186               AS column_21186,
       column_21187           AS column_21187,
       column_12273           AS column_12273,
       column_12274           AS column_12274,
       column_12275           AS column_12275    
  FROM (WITH 
  
    dataset_263 AS(
        SELECT package_11.package_function_04(
                            argument_01             => '#####',
                            argument_40             => '##############',
                            argument_18             => dataset_899.column_354,
                            argument_41             => '########_#####',
                            argument_42             => '#######_#####') as column_2343  
        FROM dataset_62, dataset_360  dataset_899
    ),

    dataset_943   AS (
        SELECT TRIM(regexp_substr(dataset_263.column_2343,'[^,]+', 1, LEVEL)) AS column_533  
        FROM dataset_263 CONNECT BY regexp_substr(dataset_263.column_2343, '[^,]+', 1, LEVEL) IS NOT NULL
    ),
    
    dataset_944           as( SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                       FROM dataset_360  dataset_899,dataset_946  dataset_945 ),
                        
    dataset_2723      as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_#########_#####:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_#########_#####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                           FROM dataset_360  dataset_899,dataset_946  dataset_945),
    
       dataset_959        as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_########_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                            FROM dataset_360  dataset_899,dataset_946  dataset_945 ),                  

    dataset_227  AS (
        SELECT DISTINCT
            dataset_228.column_527                 AS column_527,
            dataset_228.column_528                 AS column_528,
            dataset_228.column_529                 AS column_529,
            dataset_228.column_530                 AS column_530,
            dataset_228.column_531                 AS column_531,
            dataset_228.column_532                 AS column_532,
            dataset_228.column_533                 AS column_533,
            dataset_228.column_534                 AS column_534,
            package_131.package_function_134(dataset_228.column_527,
                dataset_228.column_528,dataset_228.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_229                  dataset_228, dataset_944           dataset_948 where dataset_228.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_230.column_527                  AS column_527,
            dataset_230.column_528                  AS column_528,
            dataset_230.column_529                  AS column_529,
            dataset_230.column_530                  AS column_530,
            dataset_230.column_531                  AS column_531,
            dataset_230.column_532                  AS column_532,
            dataset_230.column_533                  AS column_533,
            dataset_230.column_534                  AS column_534,
            package_131.package_function_134(dataset_230.column_527,
                dataset_230.column_528,dataset_230.column_529,dataset_948.column_2344) as column_535        
        FROM dataset_231          dataset_230,dataset_944           dataset_948 where dataset_230.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_232.column_538                 AS column_527,
            dataset_232.column_539                 AS column_528,
            dataset_232.column_540                 AS column_529,
            dataset_232.column_541                 AS column_530,
            dataset_232.column_531                 AS column_531,
            dataset_232.column_542                 AS column_532,
            '#######'                      AS column_533,
            dataset_232.column_534                 AS column_534,
            package_131.package_function_134(dataset_232.column_538,
                dataset_232.column_539,dataset_232.column_540,dataset_948.column_2344) as column_535        
        FROM dataset_233           dataset_232,dataset_944           dataset_948 where dataset_232.column_541=dataset_948.column_591),

    dataset_947       AS (
        SELECT  /*+ ########### */  DISTINCT dataset_102.*
        FROM dataset_227  dataset_102,
             dataset_943   dataset_2719
        WHERE 1=1
               AND dataset_102.column_531 = '#####'
               AND dataset_102.column_533 = dataset_2719.column_533  
        ORDER BY dataset_102.column_533,
                   dataset_102.column_528
    ),   
  
    dataset_4869  AS  (
        select /*+ ########### */ 
        dataset_333.column_1065,
        dataset_333.column_1064,
        dataset_259.column_76,
        dataset_956.column_534,
        package_381.package_function_413 (
             argument_01              => '#####',
             argument_650             => dataset_333.column_1065,
             argument_161             => dataset_333.column_1064,
             argument_73              => dataset_259.column_76,
             argument_252             => dataset_899.column_753,
             argument_672             => dataset_956.column_534) as column_7116 
        from dataset_260      dataset_259,(
                  select distinct column_1065,column_1064      from dataset_323                   where column_694      NOT IN ('#######', '########', '#########')
                  union
                  select '##########',NULL from dataset_62
                  union
                  select NULL,NULL from dataset_62) dataset_333,(select distinct column_534        from dataset_947) dataset_956,dataset_360  dataset_899
    ),
     dataset_949                            as (
            select /*+ ########### */ column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_360  dataset_104
                WHERE column_2345 = 
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),
     dataset_952         
             AS (SELECT /*+ ########### */ dataset_259.column_555,
                        dataset_953.column_2346      AS column_76,
                        dataset_953.column_2347      AS column_2348       
                   FROM dataset_954             dataset_953, dataset_260      dataset_259,dataset_949                            dataset_964
                  WHERE     dataset_953.column_2349 = '###_#######'
                        AND dataset_953.column_354 = '###_#########'
                        AND dataset_953.column_2350 = '######+'
                        AND dataset_953.column_2351 = '###_########_######'
                        AND dataset_953.column_221 = '#######_######'
                        AND dataset_953.column_2352 = '*'
                        AND dataset_953.column_2346 = dataset_259.column_76     
                        AND dataset_259.column_76 = dataset_964.column_76
    ),
    
   
   
    dataset_242  AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_549) AS column_549,
            package_131.package_function_135(dataset_244.column_535, dataset_2726.column_2344, dataset_962.column_2354) AS column_535,
            dataset_244.column_555,
            dataset_244.column_571,
            dataset_244.column_558,
            dataset_244.column_562,
            dataset_244.column_532,
            dataset_244.column_7116 
        FROM 
            dataset_226     dataset_235, 
            dataset_247      dataset_244,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE     
            dataset_235.column_525 <= 
            AND dataset_235.column_545 = '##########_####'
            AND dataset_235.column_544 = dataset_244.column_544 
            AND dataset_244.column_531 = '#####'
            AND dataset_235.column_549 <> 0
            AND dataset_244.column_2356=dataset_2726.column_591
            AND dataset_244.column_2356=dataset_962.column_591
            AND EXISTS (SELECT NULL
                        FROM dataset_947      
                        WHERE column_535 = dataset_244.column_535)
            AND (dataset_235.column_544, dataset_235.column_545,  dataset_235.column_525) IN
                ( SELECT dataset_235.column_544,
                         dataset_235.column_545,
                         MAX (dataset_235.column_525)
                  FROM dataset_226     dataset_235
                  WHERE column_525 <= 
                      AND dataset_235.column_545 = '##########_####'
                  GROUP BY dataset_235.column_544, dataset_235.column_545)
        GROUP BY 
            dataset_244.column_535,
            dataset_244.column_555,
            dataset_244.column_571,
            dataset_244.column_558,
            dataset_244.column_562,
            dataset_244.column_532,
            dataset_244.column_7116,
            dataset_2726.column_2344,
            dataset_962.column_2354  
        ORDER BY column_558, column_562, column_535
    ),
    
    dataset_4871  AS (  
        SELECT /*+ ########### */ 
            SUM ( DECODE (dataset_4872.column_552,
                  '#', dataset_4872.column_549,
                  '#', -1 * dataset_4872.column_549)) AS column_549,
            package_131.package_function_135(dataset_244.column_535,dataset_2726.column_2344,dataset_962.column_2354) AS column_535,
            dataset_244.column_555,
            dataset_244.column_558,
            dataset_244.column_562,
            dataset_244.column_532,
            dataset_244.column_7116 
        FROM 
            dataset_246                 dataset_4872, 
            dataset_247      dataset_244,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE 1 = 1
            AND dataset_4872.column_10757 = 0
            AND dataset_4872.column_544 = dataset_244.column_544 
            AND dataset_244.column_571 = '###########'
            AND dataset_244.column_531 = '#####'
            AND dataset_4872.column_549 <> 0
            AND dataset_244.column_2356=dataset_2726.column_591
            AND dataset_244.column_2356=dataset_962.column_591
               AND EXISTS (SELECT NULL
                     FROM dataset_947      
                    WHERE column_535 = dataset_244.column_535)
        GROUP BY 
            dataset_244.column_535,
            dataset_244.column_555,
            dataset_244.column_558,
            dataset_244.column_562,
            dataset_244.column_532,
            dataset_244.column_7116,
            dataset_2726.column_2344,
            dataset_962.column_2354  
        ORDER BY column_558, column_562, column_535
    ),
    
    dataset_4874         AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_549) AS column_549,
            dataset_235.column_535,
              dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
              dataset_235.column_532,
              dataset_235.column_7116 
         FROM dataset_242  dataset_235
        WHERE 1=1
              AND dataset_235.column_571 = '###########'
        GROUP BY 
            dataset_235.column_535,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116 
        ORDER BY column_532, column_535
    ),
    
    dataset_4873       AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_549) AS column_549,
            dataset_235.column_535,
              dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
              dataset_235.column_532,
              dataset_235.column_7116 
         FROM dataset_242  dataset_235
        WHERE 1=1
              AND dataset_235.column_571 = '#########'
        GROUP BY 
            dataset_235.column_535,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116 
        ORDER BY column_532, column_535
    ),
    
    dataset_10421           AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_333.column_708
                 - dataset_333.column_709
                 - dataset_333.column_712
                 - dataset_333.column_710
                 - dataset_333.column_711)     AS column_549,
              package_131.package_function_134(dataset_232.column_538,
                dataset_232.column_539,dataset_232.column_540,dataset_2726.column_2344)    AS column_535,
              dataset_259.column_555                   AS column_555,
              dataset_45.column_598                           AS column_558,
              dataset_275.column_562                            AS column_562,
              dataset_275.column_604                     AS column_532,
              dataset_268.column_7116                  AS column_7116 
        FROM dataset_336                  dataset_333,
            dataset_315                  dataset_2347,
            dataset_269                        dataset_45,
            dataset_276                     dataset_275,
            dataset_674                    dataset_3243,
            dataset_233                  dataset_232,
            dataset_260                  dataset_259,
            dataset_4869                 dataset_268,
            dataset_2723                 dataset_2726  
        WHERE 1 = 1
            AND dataset_333.column_451 = dataset_2347.column_451      
            AND dataset_45.column_598 = dataset_2347.column_598
            AND dataset_333.column_11 = dataset_275.column_11
            AND dataset_333.column_76 = dataset_259.column_76     
            AND dataset_3243.column_07 = dataset_333.column_07     
            AND dataset_3243.column_451 = dataset_333.column_451      
            AND dataset_3243.column_2260 = '#####'
            AND dataset_232.column_1327 = dataset_3243.column_8429
            AND dataset_232.column_531 = '#####'            
            AND dataset_268.column_76=dataset_259.column_76     
            and dataset_268.column_1065='##########'
            AND dataset_232.column_541=dataset_2726.column_591
            and dataset_268.column_1064      is null    
            and dataset_268.column_534=dataset_232.column_534       
        GROUP BY dataset_232.column_539,
        dataset_232.column_538,
        dataset_232.column_540,
        dataset_2726.column_2344,
            dataset_259.column_76,
            dataset_259.column_555,
            dataset_45.column_598,
            dataset_275.column_562,
            dataset_275.column_604,
            dataset_268.column_7116    
        ORDER BY column_558, column_562, column_535
    ),
                 
    dataset_10422            AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_666.column_1485)     AS column_549,
            package_131.package_function_134(dataset_322.column_2400,
                dataset_322.column_2401 ,dataset_322.column_2396,dataset_2726.column_2344)                AS column_535,
            dataset_259.column_555,
            dataset_45.column_598                                         AS column_558,
            dataset_275.column_562,
            dataset_275.column_604                                   AS column_532,
            dataset_268.column_7116                              AS column_7116 
        FROM dataset_323                   dataset_322,
            dataset_563                 dataset_503,
            dataset_668                 dataset_666,
            dataset_336                 dataset_333,
            dataset_315                 dataset_2347,
            dataset_269                       dataset_45,
            dataset_260                 dataset_259,
            dataset_276                    dataset_275,
            dataset_4869                dataset_268,
            dataset_2723                dataset_2726  
        WHERE 1 = 1
            AND dataset_322.column_694      NOT IN ('#######', '########', '#########')
            AND dataset_503.column_1321 = dataset_322.column_1321              
            AND dataset_666.column_148 = dataset_322.column_148          
            AND dataset_666.column_718 = dataset_322.column_718        
            AND dataset_666.column_1485 = dataset_322.column_549
            AND dataset_666.column_2723 = dataset_322.column_2723
            AND TRUNC (dataset_333.column_2721) = TRUNC (dataset_503.column_2721)
            AND dataset_666.column_07 = dataset_333.column_07     
            AND dataset_666.column_451 = dataset_333.column_451      
            AND dataset_666.column_452 = dataset_333.column_452         
            AND dataset_2347.column_451 = dataset_333.column_451      
            AND dataset_45.column_598 = dataset_2347.column_598
            AND dataset_259.column_76 = dataset_503.column_76     
            AND dataset_275.column_11 = dataset_322.column_11
            AND dataset_268.column_76 = dataset_259.column_76     
            and dataset_268.column_1065 = dataset_322.column_1065  
            and dataset_268.column_1064 = dataset_322.column_1064     
            AND dataset_503.column_3753=dataset_2726.column_591
            and dataset_268.column_534=dataset_503.column_534       
        GROUP BY 
            dataset_322.column_2401,
            dataset_322.column_2400,
            dataset_322.column_2396,
            dataset_2726.column_2344,
            dataset_259.column_555,
            dataset_45.column_598,
            dataset_275.column_562,
            dataset_275.column_604,
            dataset_268.column_7116
    ),  
    
    dataset_4888 AS (
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            dataset_235.column_549         AS column_12271,
            0                    AS column_21186,
            0                    AS column_21187,
            0                    AS column_12273,
            0                    AS column_12274,
            0                    AS column_12275    
        FROM dataset_4871  dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            -1*abs(dataset_235.column_549) AS column_21186,
            0                    AS column_21187,
            0                    AS column_12273,
            0                    AS column_12274,
            0                    AS column_12275    
        FROM dataset_10422            dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_21186,
            dataset_235.column_549         AS column_21187,
            0                    AS column_12273,
            0                    AS column_12274,
            0                    AS column_12275    
        FROM dataset_10421           dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_21186,
            0                     AS column_21187,
            dataset_235.column_549          AS column_12273,
            0                    AS column_12274,            
            0                    AS column_12275    
        FROM dataset_4874         dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_21186,
            0                     AS column_21187,
            0                    AS column_12273,
            dataset_235.column_549        AS column_12274,            
            0                    AS column_12275    
        FROM dataset_4873       dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_558,
            dataset_235.column_562,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_21186,
            0                    AS column_21187,
            0                    AS column_12273,
            0                    AS column_12274,
            dataset_235.column_549         AS column_12275    
        FROM dataset_242  dataset_235, dataset_360  dataset_899
    )
                   
                   
    SELECT    '######'
         || dataset_1317.column_122      
         || '#'
         || 
         || dataset_4889.column_2348       
         || dataset_1317.column_535        
         || dataset_1317.column_558
         || dataset_1317.column_562
         || dataset_1317.column_532   
         || dataset_1317.column_7116                AS column_1117,
         '#####'                      AS column_5035,
         dataset_1317.column_535                 AS column_1328,
         dataset_1317.column_122                 AS column_12270,
         dataset_1317.column_354                 AS column_354,
         dataset_4889.column_2348              AS column_76,
         dataset_1317.column_558                    AS column_598,
         dataset_1317.column_562                       AS column_562,
         dataset_1317.column_532                 AS column_874,
         dataset_1317.column_7116                AS column_7105,
         SUM (dataset_1317.column_12271)             AS column_12271,
         SUM (dataset_1317.column_21186)             AS column_21186,
         SUM (dataset_1317.column_21187)  AS column_21187,
         SUM (dataset_1317.column_12273) AS column_12273,
         SUM (dataset_1317.column_12274)   AS column_12274,
         SUM (dataset_1317.column_12275)         AS column_12275    
    FROM dataset_4888 dataset_1317, dataset_952          dataset_4889
    WHERE dataset_4889.column_555 = dataset_1317.column_555       
    GROUP BY dataset_1317.column_122,
         '#####',
         dataset_1317.column_535,
         dataset_1317.column_354,
         dataset_1317.column_122,
         dataset_4889.column_2348,
         dataset_1317.column_558,
         dataset_1317.column_562,
         dataset_1317.column_532,
         dataset_1317.column_7116 
    ORDER BY column_598, column_562, column_1328)
        