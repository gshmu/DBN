--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : ####_#_##_##############.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######         ###### ####### #### ## ###
--###                                     ###### #######
--### *********************************************************************/




--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

CREATE OR REPLACE FORCE VIEW view_09
(column_6154
,column_6155
,column_6156
,column_451
,column_598
,column_213
,column_3815
,column_742
,column_3111
,column_749
,column_6157
,column_6158
,column_6159
,column_2910
,column_530
,column_06
,column_204
,column_609
,column_229
,column_610
,column_6160
,column_6161
,column_1287
,column_1288
,column_1289
,column_1290
,column_6162
,column_6163
)
AS
SELECT column_6154
      ,column_6155
      ,column_6156
      ,column_451
      ,column_598
      ,column_213
      ,column_3815
      ,column_742
      ,column_3111
      ,column_749
      ,column_6157
      ,column_6158
      ,column_6159
      ,column_2910
      ,column_530
      ,column_06
      ,column_204
      ,column_609
      ,column_229
      ,column_610
      ,column_6160
      ,column_6161
      ,column_1287
      ,column_1288
      ,column_1289
      ,column_1290
      ,column_6162
      ,column_6163    
  FROM dataset_2385     
 WHERE column_6155 <= dataset_2386.column_6164   
   AND NVL (column_6163, dataset_2386.column_6164 + 1) >
         dataset_2386.column_6164   
   AND column_6155 <= dataset_2386.column_6164   
   AND column_6156   != '#'
/      

COMMIT
/






