--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  #### ####   : ####_#_#_#######_############.###
--###  ###### #####: ####### ###### ## ####### #### ########
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##.#
--###  ##.#.#  ##.##.#### #######         ###### ####### ## ## ####### ##.#
--###                                       ####### #### ### ###### ######
--###  ####### ##
--###  ##.#.#  ##.##.####  #####          ####### ## #### ###
--### *********************************************************************/


--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####


CREATE OR REPLACE VIEW view_33
(column_07
,column_734
,column_724
,column_16229
,column_165
,column_75
,column_74
,column_3115
,column_2682
,column_567
,column_2265
,column_2688
,column_14985
,column_16230
,column_16231
,column_16232
,column_16233
,column_16234
,column_16235
,column_16236
,column_16237
,column_16238
,column_16239
,column_16240
,column_16241
,column_16242
,column_8821
,column_16243
,column_16244
,column_5007
,column_16245
,column_2839
,column_714
,column_16246
,column_16247
)
AS 
SELECT column_07
      ,column_734
      ,column_724
      ,column_16229
      ,column_165
      ,column_75
      ,column_74
      ,column_2721
      ,column_2682
      ,column_567
      ,column_2265
      ,column_2688
      ,(column_14988 * column_16248)  column_14985
      ,((  column_16249
         + column_16250
         + column_16251
         + column_16252
         + column_16253
         + column_16254
         + column_16255
         + column_16256
         + column_16257
         + column_16258
         + column_16259
        ) * column_16248
       )  column_16230
      ,(column_16249 * column_16248)  column_16231
      ,(column_16250 * column_16248)  column_16232
      ,(column_16251 * column_16248)  column_16233
      ,(column_16252 * column_16248)  column_16234
      ,(column_16253 * column_16248)  column_16235
      ,(column_16254 * column_16248)  column_16236
      ,(column_16255 * column_16248)  column_16237
      ,(column_16256 * column_16248)  column_16238
      ,(column_16257 * column_16248)  column_16239
      ,(column_16258 * column_16248)  column_16240
      ,(column_16259 * column_16248)  column_16241
      ,(column_16242 * column_16248)  column_16242
      ,(column_8821 * column_16248)  column_8821
      ,(column_16243 * column_16248)  column_16243
      ,((  column_14988
         - column_16249
         - column_16250
         - column_16251
         - column_16252
         - column_16253
         - column_16254
         - column_16255
         - column_16256
         - column_16257
         - column_16258
         - column_16259
         - column_16242
         - column_8821
         - column_16243
        ) * column_16248
       )  column_16244
      ,(column_5007 * column_16248)  column_5007
      ,(column_16245 * column_16248)  column_16245
      ,column_2839
      ,column_714
      ,column_16246
      ,column_16247            
  FROM (SELECT /*+ ###_#### */
               MAX (dataset_1209.column_07) column_07
              ,MAX (dataset_1209.column_734) column_734
              ,MAX (dataset_1209.column_165) column_165
              ,MAX (dataset_1209.column_75) column_75
              ,MAX (dataset_1209.column_74) column_74
              ,dataset_312.column_724             column_724
              ,MAX (dataset_665.column_900) column_2682
              ,MAX (dataset_665.column_567) column_567
              ,CASE
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_666.column_1482,0))
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_666.column_1483,0))
                 WHEN MAX (dataset_665.column_1064) = '###' THEN 
                   SUM(  NVL(dataset_666.column_1482,0)
                       + NVL(dataset_666.column_1483,0)
                      )
               END column_2265
              ,SUM (dataset_666.column_1483) column_2688
              ,CASE
                 WHEN dataset_6074.column_714 = '####' THEN 
                   dataset_666.column_5245
                 ELSE CASE
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM((   NVL(dataset_314.column_1484,0) 
                         - NVL(dataset_666.column_2708,0)
                       ) * NVL(dataset_666.column_1482,0)
                      )
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM((   NVL(dataset_665.column_1479,0)
                         - NVL(dataset_666.column_2708,0)
                       ) * NVL(dataset_666.column_1483,0)
                      )
                 WHEN MAX (dataset_665.column_1064) = '###' THEN
                   SUM((   NVL(dataset_314.column_1484,0)
                         - NVL(dataset_666.column_2708,0)
                       ) * NVL(dataset_666.column_1482,0)
                      )
                 + SUM((   NVL(dataset_665.column_1479,0)
                         - NVL(dataset_666.column_2708,0)
                       ) * NVL(dataset_666.column_1483,0)
                      )
                 END
               END column_14988
              ,MAX(dataset_5357.column_2268) column_16242
              ,MAX(  dataset_5357.column_2689
                    + dataset_5357.column_2690
                    + dataset_5357.column_2691
                    + dataset_5357.column_2269
                    + dataset_5357.column_16260
                  ) column_8821
              ,MAX(NVL (dataset_663.column_735, 0)) column_16243
              ,  SUM(NVL(dataset_1156.column_16261, 0)) 
               + SUM(NVL(dataset_1156.column_8637, 0)) column_16249
              ,SUM (NVL (dataset_1156.column_16262, 0)) column_16252
              ,SUM (NVL (dataset_1156.column_16263, 0)) column_16253
              ,SUM (NVL (dataset_1156.column_2358, 0)) column_16250
              ,SUM (NVL (dataset_1156.column_16264, 0)) column_16254
              ,SUM (NVL (dataset_1156.column_16265, 0)) column_16255
              ,SUM (NVL (dataset_1156.column_16266, 0)) column_16256
              ,SUM (NVL (dataset_1156.column_16267, 0)) column_16257
              ,SUM (NVL (dataset_1156.column_16268, 0)) column_16258
              ,SUM (NVL (dataset_1156.column_16269, 0)) column_16259
              ,SUM (NVL (dataset_1156.column_16251, 0)) column_16251
              ,MAX (dataset_976.column_2721) column_2721
              ,CASE
                 WHEN MAX (dataset_1209.column_3206) = '#####_######'
                   OR MAX (dataset_1209.column_734) NOT IN ('#####', '##-#####', '###', '##-###')
                 THEN '#'
                 WHEN NVL(MAX (dataset_1209.column_3206), '###') != '#####_######'
                  AND     MAX (dataset_1209.column_734) = '#####' 
                 THEN '#'
                 WHEN NVL(MAX (dataset_1209.column_3206), '###') != '#####_######'
                  AND     MAX (dataset_1209.column_734) IN ('###') 
                 THEN '#'
                 ELSE NULL
               END column_16229
              ,CASE
                 WHEN MAX (dataset_312.column_532) = '###' THEN 
                   package_909.package_function_1189
                       (argument_01            => SYS_CONTEXT('###_#######_###', '#######') 
                       ,argument_219           => dataset_666.column_148
                       ,argument_220           => dataset_666.column_718
                        ,argument_476          => MAX (dataset_1209.column_734)
                       )
                 ELSE 1
               END column_16248
              ,CASE
                 WHEN dataset_6074.column_714 = '####' THEN 
                   CASE
                     WHEN MAX(dataset_665.column_1064) = '########' THEN 
                       SUM(NVL(dataset_666.column_1484,0))
                     WHEN MAX(dataset_665.column_1064) = '########' THEN 
                       SUM(NVL(dataset_666.column_2711,0))
                     WHEN MAX(dataset_665.column_1064) = '###' THEN 
                       SUM(NVL(dataset_666.column_1484,0) + NVL(dataset_666.column_2711,0))
                   END
                 ELSE CASE
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_314.column_1484,0) * NVL(dataset_666.column_1482,0))
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_665.column_1479,0) * NVL(dataset_666.column_1483,0))
                 WHEN MAX (dataset_665.column_1064) = '###' THEN   
                   SUM(NVL(dataset_314.column_1484,0) * NVL(dataset_666.column_1482,0))
                 + SUM(NVL(dataset_665.column_1479,0) * NVL(dataset_666.column_1483,0))
                 END
               END column_5007
              ,CASE
                 WHEN dataset_6074.column_714 = '####' THEN 0
                 ELSE CASE
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_666.column_1482,0) * NVL(dataset_666.column_2708,0))
                 WHEN MAX (dataset_665.column_1064) = '########' THEN 
                   SUM(NVL(dataset_666.column_1483,0) * NVL(dataset_666.column_2708,0))
                 WHEN MAX (dataset_665.column_1064) = '###' THEN 
                   SUM((   NVL(dataset_666.column_1482,0)
                         + NVL(dataset_666.column_1483,0)
                       ) * NVL(dataset_666.column_2708,0)
                      )
                 END
               END column_16245
              ,column_2839
              ,dataset_6074.column_714
              ,SUM(dataset_666.column_1478 + dataset_666.column_1485) column_16246
              ,MAX(column_16247) column_16247            
          FROM dataset_311        dataset_312
              ,dataset_313                   dataset_314
              ,dataset_667           dataset_665
              ,dataset_668                 dataset_666
              ,dataset_336 dataset_976
              ,dataset_50   dataset_1209
              ,(SELECT column_148
                     ,column_718
                     ,column_2021
                     ,NVL(MAX(DECODE(column_2023
                                    ,'#######',column_2022
                                    ))
                         ,0) column_16261
                     ,NVL(MAX(DECODE(column_2023
                                    ,'#####', column_2022
                                    ))
                          ,0) column_8637
                     ,MAX(DECODE(column_2023
                                ,'######_########', column_2022
                                )) column_16262
                     ,MAX(DECODE(column_2023
                                ,'########', column_2022
                                )) column_16263
                     ,MAX(DECODE(column_2023
                                ,'#####', column_2022
                                )) column_2358
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16264
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16265
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16266
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16267
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16268
                     ,MAX(DECODE(column_2023
                                ,'######', column_2022
                                )) column_16269
                     ,MAX(DECODE(column_2023
                                ,'#####_#', column_2022
                                )) column_16251
                 FROM dataset_1157           
                GROUP BY column_148
                     ,column_718
                     ,column_2021
               ) dataset_1156
              ,dataset_276 dataset_6074
              ,dataset_664                dataset_663
              ,(SELECT column_148
                      ,column_718
                      ,SUM(CASE
                             WHEN column_1466 = '########'
                              AND column_1464 = '#####_###' 
                             THEN column_735
                             ELSE 0
                           END) column_2268
                      ,SUM(NVL (DECODE (column_1464
                                       ,'####', column_735
                                       ), 0)) column_2689
                      ,SUM(NVL (DECODE (column_1464
                                       ,'####', column_735
                                       ), 0)) column_2690
                      ,SUM(NVL (DECODE (column_1464
                                       ,'####', column_735
                                       ), 0)) column_2691
                      ,SUM(NVL (DECODE (column_1464
                                       ,'###_###', column_735
                                       ), 0)) column_16260
                      ,SUM(NVL (DECODE (column_1464
                                       ,'########_####', column_735
                                       )
                               ,0)) column_2269
                      ,SUM(NVL (DECODE (column_1464
                                       ,'###_#####', column_735
                                       )
                               ,0)) column_16247            
                 FROM dataset_664               
                GROUP BY column_148
                     ,column_718
               ) dataset_5357
        WHERE dataset_312.column_148 = dataset_665.column_148          
          AND dataset_314.column_148 = dataset_666.column_148          
          AND dataset_314.column_07 = dataset_666.column_07     
          AND dataset_314.column_451 = dataset_666.column_451      
          AND dataset_314.column_452 = dataset_666.column_452         
          AND dataset_665.column_148 = dataset_666.column_148          
          AND dataset_665.column_718 = dataset_666.column_718        
          AND dataset_665.column_148 = dataset_663.column_148(+)
          AND dataset_665.column_718 = dataset_663.column_718(+)
          AND dataset_663.column_1464(+) = '#########'
          AND dataset_666.column_07 = dataset_1209.column_07     
          AND dataset_666.column_148 = dataset_5357.column_148          
          AND dataset_666.column_718 = dataset_5357.column_718        
          AND dataset_976.column_07 = dataset_666.column_07     
          AND dataset_976.column_451 = dataset_666.column_451      
          AND dataset_976.column_452 = dataset_666.column_452         
          AND dataset_666.column_148 = dataset_1156.column_148(+)
          AND dataset_666.column_718 = dataset_1156.column_718(+)
          AND dataset_666.column_2021 = dataset_1156.column_2021(+)
          AND dataset_666.column_11 = dataset_6074.column_11
          AND dataset_6074.column_986 = '######'
          AND dataset_312.column_724 = '###_##_##'
        GROUP BY dataset_666.column_148
             ,dataset_666.column_718
             ,dataset_312.column_724
             ,dataset_1209.column_2839
             ,dataset_6074.column_714
             ,dataset_666.column_5245
       )
/       

COMMIT
/






