/******************************************************************************
    ##### #####: #########_########_########
    #########:   #########
    ########:    #######
    ######## ######## ##### ### ####### ######
    
    #######:
      (####)                           (####)
    - #######_######_##
    - ###########_##          
    - #########_######_##     
    - ###_#######_######      
    - ###_#######_###_######  
    - ###_#######_####_###### 
    - #######_######_####     
    - ####                    
    - ########                
    - #####_####              
    - ##########_####         
    - ######_#####_####       
    - ########                
    - #####_######            
    - #####_######_######_##  
    - #####_######_#########  
    - #####_###########_####  
    - ########                
    - #######_####

    ####### ##.#
    ##.#.#    ##.##.####   ##### ######    ####### ####, ###-#####
*******************************************************************************/
SELECT 
rowid column_14818,
    column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    sum(column_549)  over(partition by   column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    '######### #### ###########',
    column_568,
    column_564,
    '######### #### ###########',
    column_7116
) as column_549,
    row_number() over(partition by  column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    '######### #### ###########',
    column_568,
    column_564,
    '######### #### ###########',
    column_7116 
order by rowid )column_5369,
    nvl(column_565,'###########')                          AS column_565,
    '######### #### ###########'                                                                                    AS column_569,
    nvl(column_568,'######### #### ###########') AS column_568,
    nvl(column_564,'#########')                  AS column_564,
    '######### #### ###########'                                                             AS column_189,
    column_7116 
FROM dataset_7292              
WHERE 1=1
    AND column_10 = '###'
    AND column_531 = '#####'
    AND column_568 = '######### #### ###########'

UNION ALL    
    
SELECT 
rowid column_14818,
    column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    sum(column_549)  over(partition by  column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    column_569,
    column_568,
    column_564,
    column_189,
    column_7116) as column_549,
    row_number() over(partition by column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    column_569,
    column_568,
    column_564,
    column_189,
    column_7116  order by rowid )column_5369,
    nvl(column_565,'######### ## #### ########')           AS column_565,
    nvl(column_569,'######### ## #### ########') AS column_569,
    nvl(column_568,'######### #### #####')                  AS column_568,
    nvl(column_564,'#########')                  AS column_564,
    nvl(column_189,'######### ## #### ########')               AS column_189,
    column_7116 
FROM dataset_7292              
WHERE 1=1
    AND column_10 = '###'
    AND column_531 = '#####'
    AND column_568 = '######### #### #####'
    
UNION ALL

SELECT 
rowid column_14818,
    column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    sum(column_549)  over(partition by column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    column_569,
    column_568,
    column_564,
    column_189,
    column_7116) as column_549,
    row_number() over(partition by column_555,      
    column_07,
    column_165,
    column_560,
    column_535,
    column_2355,
    column_2356,
    column_531,
    column_562,
    column_532,
    column_558,
    column_3063,
    column_566,
    column_567,
    column_552,
    column_565,
    column_569,
    column_568,
    column_564,
    column_189,
    column_7116  order by rowid )column_5369,
    nvl(column_565,'####')                                                                                                                AS column_565,
    nvl(column_569,'######### ####')                                                    AS column_569,
    nvl(column_568,'######### ####')                                         AS column_568,
    nvl(column_564,'#########')                         AS column_564,
    nvl(column_189,'######### ####')                                                                                                 AS column_189,
    column_7116 
FROM dataset_7292              
WHERE 1=1
    AND column_10 = '###'
    AND column_531 = '####'