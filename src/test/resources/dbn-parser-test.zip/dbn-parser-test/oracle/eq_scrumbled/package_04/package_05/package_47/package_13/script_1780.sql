--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_####_####.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        #######
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ ####  ###_####_####';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_####_#### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_03
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_962
      ,column_4142
      ,column_964
      ,column_4143
      ,column_4144
      ,column_4145
      ,column_2200
      ,column_4146
      ,column_976
      ,column_977
  FROM dataset_1640@dblink_02.EQ
/  
COMMIT
/
       





