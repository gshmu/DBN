--### /********************************************************************
--###  ######### (#) ####,#### ###, ### ##
--###  ######....: ######## #######
--###  #### ####.: #####_##_######_####_#######.###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ##.#.#     ##.##.#### ###########  ## ###  
--### *********************************************************************/













DECLARE
  any_08              CONSTANT VARCHAR2(30) := '###_' || '########_' || '#######';
  any_09              VARCHAR2(30) := sys_context('#######','#######_######');
  any_10              VARCHAR2(3)  := '###';
  any_05              VARCHAR2(4000);
  any_12              schema_03.dataset_18%TYPE;

BEGIN

  method_58   := '##_######_####_#######';
  
  if column_33!=column_34          then
     method_05   := substr(column_33,-3);
  end if;
  
  IF column_33 != column_34          THEN
    method_05   := SUBSTR(column_33,13,3);
  END IF;
  
  BEGIN
    method_04   := '#### ############ #### ### ## ' || column_37;
    EXECUTE IMMEDIATE column_27;
    
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;
  BEGIN
    method_04   := 
         '###### ############ #### ### ## ' 
      || column_37    
      || ' ########## ###_' || column_35   || '_####_#### '
      || ' #### ####### ### ######### ### ###### '
      ;
    EXECUTE IMMEDIATE column_27;
    
  EXCEPTION
    WHEN OTHERS THEN NULL;
      package_06.method_08('###### ######## ## ' || column_37    || ': ' || SUBSTR(REPLACE(SQLERRM,'###-','###-#:'),1,200));
      package_07.method_09(column_37,'##### = '||SQLERRM,sys_context( '#######','#######_######'));
  END;
  
END;
/

COMMIT
/





