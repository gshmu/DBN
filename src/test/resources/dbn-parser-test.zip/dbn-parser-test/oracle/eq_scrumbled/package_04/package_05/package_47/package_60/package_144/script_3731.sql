/*  ####### ########
####### #######:
####### ##
##.##.####   ########   ###-##### : ##### ########
##.##.####   ########   ###-##### : ####### #### ########## #### ##### ##### ## #####
*/
SELECT column_6383,
  column_3759,
  column_4132           
FROM
  (SELECT DECODE(dataset_461.column_6384,
  '######_####', dataset_1981.column_4126,
  '####', dataset_1981.column_598,
  '#############_####', dataset_1981.column_598 || dataset_1981.column_3120,
  '#############', dataset_1981.column_451
  ) column_6383,
    dataset_1981.column_3759,
    dataset_1981.column_4132           
  FROM dataset_1634                  dataset_1981,
    dataset_2483      dataset_2484,
    dataset_2485 dataset_461
  WHERE dataset_1981.column_07                                 = 
  AND dataset_2484.column_598                                              = dataset_1981.column_598
  AND NVL (dataset_2484.column_714, dataset_1981.column_714)             = dataset_1981.column_714  
  AND NVL (dataset_2484.column_1446, dataset_1981.column_1446) = dataset_1981.column_1446       
  AND dataset_2484.column_3118                                    = 
  AND dataset_461.column_3118                                     = dataset_2484.column_3118   
  AND dataset_461.column_3119                                       != '########'
  AND trunc(dataset_1981.column_3759)                           > dataset_1981.column_6382      
  AND ( (dataset_461.column_6385                        = '#'
  AND dataset_1981.column_2726 - dataset_1981.column_2725   = 0)
  OR (dataset_1981.column_2726 - dataset_1981.column_2725   > 0) )
  )