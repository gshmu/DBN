--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_#####_#########.###
--###
--###  ####### ####        ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        ########
--###  ##.#.#  ##.##.####  ########        ###-##### : ##### ##### ###_#####_######### ###### ######.
--### *********************************************************************/

begin
execute immediate '#### ############ #### ###_#####_#########';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_#####_######### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_12
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT 
  column_960,
  column_17727,
  column_17728,
  column_3353,
  column_17729,
  column_07,
  column_8823,
  column_8824,
  column_8825,
  column_17730,
  column_17731,
  column_17732,
  column_17733,
  column_17734,
  column_17735,
  column_17736,
  column_17737,
  column_17738,
  column_17739,
  column_17740,
  column_17741,
  column_17742,
  column_17743,
  column_17744,
  column_17745,
  column_17746,
  column_17747,
  column_976,
  column_977,
  column_17748
FROM dataset_1364@dblink_02.EQ
/

COMMIT
/

COMMENT ON MATERIALIZED VIEW materialized_view_12 IS '######## ##### ### ######## ###_#######.###_#####_#########'
/
