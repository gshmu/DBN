--### *********************************************************************
--###  ######### (#) ####,#### ###, ### ## 
--###
--###  #### #### : #####_########_###_#########_##.###
--###
--###  ####### ##: ##_########_########_####.###_########_#######
--###
--###  ########  : ########
--###  ######    : ####
--###
--###  ####                 ########
--### *********************************************************************
--###  ##.##.#### ##:##:##  ####### ######## #### ########## ####### ########  
--###
--### *********************************************************************

--### *********************************************************************
--### #### ## ######                                      ######
--###
--### ####_#######.                 ###_#########       #####
--### *********************************************************************
--### ####### ###########
--### ######## ######
--### ###### ###########
--### ###### ####
--### ###### ####, ## ...
--### *********************************************************************


DECLARE
BEGIN

  package_07.method_231
    (argument_190       => '#####_########_###_#########_##.###'
    ,argument_191       => '#######'
    ,argument_192       => '####### ####: '|| USER || ', ####### ######: ' || sys_context( '#######','#######_######' ) 
    );

END;
/


--###
--### ######### ## : ##.##.#### ##:##:##
--###
DECLARE
  any_05        VARCHAR2(1000);
  any_1274       VARCHAR2(30) := sys_context('#######','#######_######');
BEGIN
  FOR cursor_82 IN (SELECT dataset_1132.column_264 AS column_264
                    ,dataset_1132.column_265      AS column_265
                    ,dataset_1133.column_263 AS column_263
                    ,NULL AS column_2607       
                FROM dataset_145     dataset_1132
                    ,dataset_145     dataset_1133
               WHERE dataset_1132.column_263 = dataset_1133.column_263
                 AND dataset_1132.column_1343 = dataset_1133.column_265     
                 AND dataset_1132.column_2608 = '#'
                 AND dataset_1132.column_263 = column_2609
                 AND dataset_1133.column_2608     IN ('#','#')
                 AND dataset_1133.column_264 IN
                    ('###_#########'
                    )
             UNION
             SELECT dataset_1134.column_264 AS column_264
                    ,dataset_1135.column_265      AS column_265
                    ,dataset_1135.column_263 AS column_263
                    ,dataset_1135.column_264 AS column_2607       
                FROM dataset_145     dataset_1135
                    ,dataset_137 dataset_1134
               WHERE dataset_1134.column_407 = dataset_1135.column_1343      
                 AND dataset_1135.column_2610 = dataset_1134.column_263
                 AND dataset_1135.column_263 != dataset_1134.column_263
                 AND dataset_1135.column_2610 = column_2609
                 AND dataset_1134.column_264 IN
                    ('###_#########'
                    )
             )
  LOOP
    BEGIN
      IF dataset_354.column_2607        IS NOT NULL THEN
        method_04   := '##### ##### ' || dataset_354.column_263 || '.' || dataset_354.column_2607        || ' ####### ########## ' || dataset_354.column_265;
      ELSE
        method_04   := '##### ##### ' || dataset_354.column_263 || '.' || dataset_354.column_264         || ' ####### ########## ' || dataset_354.column_265;
      END IF;

      EXECUTE IMMEDIATE column_27;

    EXCEPTION
      WHEN others THEN
        package_06.method_08(substr(replace(SQLERRM,'###-','###-#:'),1,230) );
    END;
  END LOOP;
END;
/


--###
--### ######### ## : ##.##.#### ##:##:##
--###
DECLARE
  any_1275               EXCEPTION;
  PRAGMA EXCEPTION_INIT(exception_07, -01031);
BEGIN

  EXECUTE IMMEDIATE '######## ##### ###_#########';
  package_06.method_08('### ###_######### #########!');

EXCEPTION
  WHEN exception_07           THEN
  EXECUTE IMMEDIATE '###### ###_#########';
  package_06.method_08('### ###########, ###: ###### #### ###_######### ########!');

  WHEN others THEN
  EXECUTE IMMEDIATE '###### ###_#########';
  package_06.method_08('### ######: ###### #### ###_######### ########!');
END;
/


--###
--### ######### ## : ##.##.#### ##:##:##
--###
DECLARE
  any_05        VARCHAR2(1000);
  any_1274       VARCHAR2(30) := sys_context('#######','#######_######');
BEGIN
  FOR cursor_82 IN (SELECT dataset_1132.column_264 AS column_264
                    ,dataset_1132.column_265      AS column_265
                    ,dataset_1133.column_263 AS column_263
                    ,NULL AS column_2607       
                FROM dataset_145     dataset_1132
                    ,dataset_145     dataset_1133
               WHERE dataset_1132.column_263 = dataset_1133.column_263
                 AND dataset_1132.column_1343 = dataset_1133.column_265     
                 AND dataset_1132.column_2608 = '#'
                 AND dataset_1132.column_263 = column_2609
                 AND dataset_1133.column_2608     IN ('#','#')
                 AND dataset_1133.column_264 IN
                    ('###_#########'
                    )
             UNION
             SELECT dataset_1134.column_264 AS column_264
                    ,dataset_1135.column_265      AS column_265
                    ,dataset_1135.column_263 AS column_263
                    ,dataset_1135.column_264 AS column_2607       
                FROM dataset_145     dataset_1135
                    ,dataset_137 dataset_1134
               WHERE dataset_1134.column_407 = dataset_1135.column_1343      
                 AND dataset_1135.column_2610 = dataset_1134.column_263
                 AND dataset_1135.column_263 != dataset_1134.column_263
                 AND dataset_1135.column_2610 = column_2609
                 AND dataset_1134.column_264 IN
                    ('###_#########'
                    )
             )
  LOOP
    BEGIN
      IF dataset_354.column_2607        IS NOT NULL THEN
        method_04   := '##### ##### ' || dataset_354.column_263 || '.' || dataset_354.column_2607        || ' ###### ########## ' || dataset_354.column_265;
      ELSE
        method_04   := '##### ##### ' || dataset_354.column_263 || '.' || dataset_354.column_264         || ' ###### ########## ' || dataset_354.column_265;
      END IF;

      EXECUTE IMMEDIATE column_27;

    EXCEPTION
      WHEN others THEN
        package_06.method_08(substr(replace(SQLERRM,'###-','###-#:'),1,230) );
    END;
  END LOOP;
END;
/


COMMIT
/


--### ###### #### ##### ###_######### 
 
DECLARE
  any_214        VARCHAR2(30);
  any_298        VARCHAR2(2000);
  any_1276       NUMBER;
  any_1277       NUMBER;
 
  CURSOR cursor_304 
  IS
   SELECT column_2611  
    ,column_181  
    ,column_354  
    ,column_611  
    ,column_616  
    ,column_10  
    ,column_613   
    FROM schema_57.dataset_1470     
    WHERE 1=1
    AND column_2619 = '######'
    AND column_354 = (SELECT column_354 FROM dataset_360) 
    ;
  any_1278     cursor_304%ROWTYPE;
-- ### ## #######
BEGIN
  package_06.method_756();
  package_06.method_757(1000000);
  package_06.method_08('### ###### #### ##### ###_#########'); 
 
  method_128    := SYS_CONTEXT('#######','#######_######');
  method_932  := 0;
  method_933   := 0;
 
  method_212 := 
       '###### #### '
    || column_356    ||'.###_#########' 
    || ' (###########_####' 
    || ' ,###_###' 
    || ' ,#######_##' 
    || ' ,########' 
    || ' ,######' 
    || ' ,######' 
    || ' ,###########' 
    || ' )' 
    || ' ###### ' 
    || '  (:#_###########_####' 
    || '  ,:#_###_###' 
    || '  ,:#_#######_##' 
    || '  ,:#_########' 
    || '  ,:#_######' 
    || '  ,:#_######' 
    || '  ,:#_###########' 
    || '  )' 
    ;
 
  OPEN cursor_304;
  LOOP
    FETCH any_1279    INTO any_1278;
    EXIT WHEN column_2620%NOTFOUND;
    BEGIN
      EXECUTE IMMEDIATE column_486
      USING dataset_1137.column_2611 
      ,dataset_1137.column_181 
      ,dataset_1137.column_354 
      ,dataset_1137.column_611 
      ,dataset_1137.column_616 
      ,dataset_1137.column_10 
      ,dataset_1137.column_613 
      ;
      method_933   := column_2621 +1;
 
    EXCEPTION
      WHEN others THEN
        method_932  := column_2622 +1;
        IF column_2622 < 100 THEN
          package_06.method_08('### ' || TO_CHAR(column_2622,'##') || ': '
            || SUBSTR(SUBSTR(SQLERRM,1,30)
            || ': ' || (dataset_1137.column_2611      
            || ', ' || dataset_1137.column_181 
            || ', ' || dataset_1137.column_354 
            || ', ' || dataset_1137.column_611 
            ),1,245)
          );
        END IF;
    END;
  END LOOP;
  IF column_2620%ISOPEN THEN CLOSE any_1279; END IF;
  IF column_2622 > 0 THEN
    package_06.method_08('### ##### ######: ' || column_2622);
  END IF;
  package_06.method_08('### #### #######: ' || column_2621);
 
EXCEPTION
  WHEN others THEN
    IF column_2620%ISOPEN THEN CLOSE any_1279; END IF;
    package_06.method_08(SUBSTR(SQLERRM,1,200));
END;
/
 

COMMIT
/




DECLARE
BEGIN

  package_07.method_231
    (argument_190       => '#####_########_###_#########_##.###'
    ,argument_191       => '#########'
    ,argument_192       => '####### ####: '|| USER || ', ####### ######: ' || sys_context( '#######','#######_######' ) 
    );

END;
/

