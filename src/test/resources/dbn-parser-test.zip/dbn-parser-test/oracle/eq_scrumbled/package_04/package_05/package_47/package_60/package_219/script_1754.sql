/******************************************************************************
    ##### #####: #########_########_########
    #########:   #########
    ########:    #######
    ######## ######## ##### ### ####### ######
    
    #######:
      (####)                           (####)
    - #######_######_##
    - ###########_##          
    - #########_######_##     
    - ###_#######_######      
    - ###_#######_###_######  
    - ###_#######_####_###### 
    - #######_######_####     
    - ####                    
    - ########                
    - #####_####              
    - ##########_####         
    - ######_#####_####       
    - ########                
    - #####_######            
    - #####_######_######_##  
    - #####_######_#########  
    - #####_###########_####  
    - ########                
    - #######_####

    ####### ##.#
    ##.#.#    ##.##.####   ##### ######    ####### ####, ###-#####
*******************************************************************************/

WITH 

dataset_6462 AS (
    SELECT 
    CASE
        WHEN column_07 IS NULL THEN
            dataset_899.column_6838     
        ELSE           
            to_DATE(column_07, '##.###.#### ####:##:##')
        END  AS column_17275
    FROM dataset_360  dataset_899
),
dataset_4870       as (
SELECT
            column_548,
            column_573,
            column_571,
            column_898,
            column_555,
            column_599,
            column_533,
            column_545,
            column_735,
            column_532   
FROM
    (
        SELECT
            column_548,
            column_573,
            column_571,
            column_898,
            column_555,
            column_599,
            column_533,
            column_545,
            column_735,
            column_532 ,
            ROW_NUMBER() OVER(
                PARTITION BY column_573, column_599, column_533, column_555       
                ORDER BY
                    column_8599       desc,column_8598         DESC
            ) AS column_5369
        FROM
            dataset_3311            dataset_3310 where column_545='#####_####'
    )
WHERE
    column_5369 = 1),

dataset_2723      as( SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                            FROM dataset_360  dataset_899,dataset_946  dataset_945 ),
dataset_4864 as (
    SELECT
        *
    FROM (
       SELECT
            dataset_228.column_527                 AS column_527,
            dataset_228.column_528                 AS column_528,
            dataset_228.column_530                 AS column_530,
            dataset_228.column_531                 AS column_531,
            dataset_228.column_532                 AS column_532,
            dataset_228.column_533                 AS column_533,
            dataset_228.column_534                 AS column_534,
            dataset_228.column_598                       AS column_598,
            package_131.package_function_134(dataset_228.column_527,
                dataset_228.column_528,dataset_228.column_529,dataset_2726.column_2344)as column_535,
            dataset_228.column_724                 AS column_724,
            package_54.package_function_165 
                        (argument_01              => '#####',
                         argument_370             => dataset_228.column_724,
                         argument_17=> '#')    AS column_76 ,
            1                              AS column_500
        FROM dataset_229                  dataset_228,dataset_2723      dataset_2726
        WHERE (column_1328, column_1446, column_533, column_531, column_534, NVL(column_598, '$_$')) IN (
            SELECT
                 max(column_1328) column_1328
                ,max(column_1446) column_1446
                ,column_533
                ,column_531
                ,column_534
                ,NVL(column_598, '$_$')
            FROM dataset_229                  dataset_2079
            WHERE dataset_2079.column_533   in ('########_##########','########_#######_#########','########')
                AND dataset_2079.column_531  = '####' --###_#########.#_####
            GROUP BY
                dataset_2079.column_531,
                dataset_2079.column_532,
                dataset_2079.column_533,
                dataset_2079.column_724,
                dataset_2079.column_534,
                NVL(dataset_2079.column_598, '$_$')
            ) AND dataset_228.column_530 = dataset_2726.column_591
        UNION ALL      
        SELECT 
            dataset_230.column_527                  AS column_527,
            dataset_230.column_528                  AS column_528,
            dataset_230.column_530                  AS column_530,
            dataset_230.column_531                  AS column_531,
            dataset_230.column_532                  AS column_532,
            dataset_230.column_533                  AS column_533,
            dataset_230.column_534                  AS column_534,
            NULL                           AS column_598,
            package_131.package_function_134(dataset_230.column_527,
                dataset_230.column_528,dataset_230.column_529,dataset_2726.column_2344) as column_535,
            dataset_230.column_724                  AS column_724,
            package_54.package_function_165 
                        (argument_01            => '#####',
                         argument_370             => dataset_230.column_724,
                         argument_17=>'#')     AS column_76 ,
            2                              AS column_500        
        FROM dataset_231          dataset_230,dataset_2723      dataset_2726
        WHERE column_896 IN (
            SELECT DISTINCT
                max(column_896)
            FROM dataset_231          dataset_4865
            WHERE dataset_4865.column_533   in ('########_##########', '########_#######_#########', '########')
                AND dataset_4865.column_531  = '####' --###_#########.#_####
            GROUP BY
                dataset_4865.column_531,
                dataset_4865.column_532,
                dataset_4865.column_533,
                dataset_4865.column_724,
                dataset_4865.column_534
            ) AND dataset_230.column_530=dataset_2726.column_591
    )
    ORDER BY column_724, column_532, column_500 ASC
),

dataset_4866     as (
select * from dataset_4864 where column_500 = 1
),

dataset_4867     as (
select * from dataset_4864 dataset_4868 where column_500 = 2
and not exists (
    select * from dataset_4866     dataset_3346
    where dataset_3346.column_532 = dataset_4868.column_532   
    and dataset_3346.column_724 = dataset_4868.column_724            
    and dataset_3346.column_533 = dataset_4868.column_533  
    AND dataset_3346.column_531 = dataset_4868.column_531
    --### ##.##########_###### = ##.##########_######
    )
),

dataset_227  as (
    select * from dataset_4866    
    union all
    select * from dataset_4867
),

--#### ####### ####
dataset_4869  AS  (
          SELECT /*+ ########### */
         column_76,
        package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => NULL,
                argument_650             => NULL,
                argument_679              => NULL,
                argument_73              => column_76) as column_7116 
          FROM(SELECT '###_##' as column_76      FROM dataset_62
            UNION ALL
            SELECT '###_##' as column_76      FROM dataset_62
            UNION ALL
            select '###_##' as column_76       FROM dataset_62)),
-- ### ######## ####
dataset_6463           as (
    SELECT 
        NULL                                                AS column_4785,--### ## ### ### ######_#### 
        column_555                                               AS column_555,
        column_07                                              AS column_07,
        column_165                                           AS column_165,
        NULL                                                 AS column_560,
        column_535                                             AS column_535,
        column_534                                              AS column_2355,
        column_530                                          AS column_2356,
        '####'                                                 AS column_531,
        NULL                                                 AS column_562,
        column_532                                            AS column_532,
        column_598                                                 AS column_558,
        column_04                                              AS column_3063,
        TRUNC(column_17275)                                        AS column_566,
        TRUNC(column_17275)                                        AS column_567,
        '#'                                                 AS column_552,
        column_09                                               AS column_549,
        0                                                   AS column_6332 ,--### ## ### ### ######_#### 
        '###########_#########_######'                         AS column_565,
        column_08   || '.' || column_07      || '.' || column_04                  || '.' || column_12           AS column_569,
        '######### ######## ####'                             AS column_568,
        '#########'                                         AS column_564,
        NULL                                                 AS column_189,
        package_381.package_function_413(
            argument_01             => '#####'
            ,argument_552               => '####_######'
            ,argument_650           => '########-############-##'
            ,argument_679           => '########_#######_#########' --###_#########.#_########_####_#######
            ,argument_73            => column_597
            ,argument_252           => column_753
            ,argument_672           => column_534)   AS column_7116 
    FROM
        (
        SELECT 
        dataset_259.column_555,
        dataset_1185.column_07,
        dataset_86.column_165,
        dataset_333.column_535,
        dataset_333.column_534,
        dataset_333.column_530,
        dataset_1185.column_532,
        dataset_45.column_598,
        dataset_1185.column_04,
        dataset_899.column_17275,
        dataset_1185.column_09,
        dataset_1185.column_08,
        dataset_1185.column_12,
        dataset_318.column_597,
        dataset_104.column_753,
        dataset_45.column_601, 
        RANK() OVER (PARTITION BY dataset_45.column_598 ORDER BY dataset_333.column_598 NULLS LAST) as column_5369
        FROM
         dataset_13                   dataset_1185
           ,dataset_317                  dataset_318
           ,dataset_270 dataset_268
           ,dataset_269 dataset_45
        ,dataset_260      dataset_259
        ,dataset_50   dataset_86
        ,dataset_227  dataset_333
        ,dataset_6462 dataset_899
        ,dataset_360  dataset_104
    WHERE 1=1
        AND (dataset_1185.column_4359               IS NULL OR dataset_1185.column_4359 = '####_##_##_########') --###_#########.#_########_####_##_##_########  
        AND dataset_1185.column_09 > 0
        AND dataset_318.column_07 = dataset_1185.column_07     
        AND dataset_318.column_04 = dataset_1185.column_04                 
        AND dataset_318.column_12 = dataset_1185.column_12      
        AND dataset_268.column_599 = dataset_318.column_599   
        AND dataset_268.column_598 = dataset_45.column_598
        AND dataset_333.column_76 = dataset_318.column_597                    
        AND dataset_333.column_532 = dataset_1185.column_532   
        AND dataset_86.column_07 = dataset_1185.column_07     
        AND dataset_259.column_76 = dataset_318.column_597                    
        AND dataset_333.column_533 = '########_#######_#########'
        AND NVL(dataset_333.column_598, dataset_45.column_598) = dataset_45.column_598
        AND CASE WHEN dataset_104.column_753 = '#############_##' AND dataset_318.column_597 = '###_##_##' THEN
                     DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                 WHEN dataset_318.column_597 = '###_##' THEN 
                    DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                 ELSE dataset_333.column_534       
            END = dataset_333.column_534             
          AND dataset_1185.column_189 = '#########'
          AND dataset_1185.column_204 >= dataset_899.column_17275
        ) 
      WHERE column_5369 = 1          
),


-- ### ############ ####

dataset_6464      as (
    SELECT 
        NULL                                                AS column_4785, --### ## ### ### ######_#### 
        column_555                                            AS column_555,
        column_07                                              AS column_07,
        column_165                                           AS column_165,
        NULL                                                 AS column_560,
        column_535                                             AS column_535,
        column_534                                            AS column_2355,
        column_530                                                AS column_2356,
        '####'                                                 AS column_531,
        NULL                                                 AS column_562,
        column_5434                                         AS column_532,
        column_598                                                AS column_558,
        column_04                                              AS column_3063,
        TRUNC(column_17275)                                         AS column_566,
        TRUNC(column_17275)                                         AS column_567,
        '#'                                                 AS column_552,
        CASE WHEN column_1785           <> column_5434                 
            THEN column_4358                   
            ELSE column_4357               
        END                                                    AS column_549,
        0                                                   AS column_6332, --### ## ### ### ######_#### 
        '###########_########_#######'                         AS column_565,
        column_07      || '.' || column_12       || '.' || column_04                      AS column_569,
        '######### ########### ####'                         AS column_568,
        '#########'                                         AS column_564,
        NULL                                                 AS column_189,
        package_381.package_function_413(
            argument_01            => '#####'
            ,argument_552               => '####_######'
            ,argument_650           => '########-############-##'
            ,argument_679           => '########_#######_#########' --###_#########.#_########_####_#######
            ,argument_73            => column_597
            ,argument_1105            => column_601
            ,argument_252           => column_753
            ,argument_672           => column_534)    AS column_7116 
    FROM (
            SELECT 
            dataset_259.column_555,
            dataset_318.column_07,
            dataset_86.column_165,
            dataset_333.column_535,
            dataset_333.column_530,
            dataset_318.column_5434 ,
            dataset_45.column_598,
            dataset_318.column_04,
            dataset_899.column_17275,
            dataset_318.column_1785,
            dataset_318.column_4358,
            dataset_318.column_4357,
            dataset_318.column_12,
            dataset_318.column_597,
            dataset_104.column_753,
            dataset_333.column_534,
            dataset_45.column_601,
            RANK() OVER (PARTITION BY dataset_45.column_598 ORDER BY dataset_333.column_598 NULLS LAST) as column_5369
         FROM dataset_260      dataset_259
            , dataset_317                  dataset_318
            , dataset_50   dataset_86
            , dataset_270 dataset_268
            , dataset_269 dataset_45
            , dataset_227  dataset_333
            , dataset_6462 dataset_899
            , dataset_360  dataset_104            
        WHERE 1=1
            AND dataset_318.column_04 = '###########_############'
            AND dataset_318.column_10 in ('####_########', '####_##_##_########')
            AND dataset_45.column_601 NOT IN ('##_####', '##_####')
            AND dataset_318.column_4357 > 0
            AND dataset_333.column_76 = dataset_318.column_597                    
            AND dataset_333.column_532 = dataset_318.column_5434                 
            AND dataset_259.column_76 = dataset_318.column_597                    
            AND dataset_86.column_07 = dataset_318.column_07     
            AND dataset_268.column_599 = dataset_318.column_599   
            AND dataset_45.column_598 = dataset_268.column_598
            AND dataset_333.column_533 = '########_#######_#########'
            AND NVL(dataset_333.column_598, dataset_45.column_598) = dataset_45.column_598
            AND CASE WHEN dataset_104.column_753 = '#############_##' AND dataset_318.column_597 = '###_##_##' THEN
                        DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                     WHEN dataset_318.column_597 = '###_##' THEN 
                        DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                     ELSE dataset_333.column_534        
                END = dataset_333.column_534       
              AND dataset_318.column_189 = '#########'
              AND dataset_318.column_204 >= dataset_899.column_17275
              ) 
      WHERE column_5369 = 1
),

--######## ######## #### 
dataset_6465               as(
    SELECT 
        NULL                                                AS column_4785, --### ## ### ### ######_#### 
        dataset_259.column_555                                        AS column_555,
        dataset_4876.column_07                                      AS column_07,
        dataset_86.column_165                                       AS column_165,
        NULL                                                 AS column_560,
        dataset_228.column_535                                        AS column_535,
        dataset_228.column_534                                      AS column_2355, 
        dataset_228.column_530                                      AS column_2356,
        '####'                                                 AS column_531,
        NULL                                                 AS column_562,
        dataset_4876.column_532                                        AS column_532,
        NULL                                                 AS column_558,
        NULL                                                 AS column_3063,
        TRUNC(dataset_899.column_17275)                                     AS column_566,
        TRUNC(dataset_899.column_17275)                                     AS column_567,
        '#'                                                 AS column_552,
        dataset_4876.column_09                                        AS column_549,
        0                                                   AS column_6332, --### ## ### ### ######_####
        '###_############_#########'                         AS column_565,
        to_char(dataset_4876.column_13552)                                  AS column_569,
        '######### ### ######## ####'                         AS column_568,
        '#########'                                         AS column_564,
        NULL                                                 AS column_189,
        package_381.package_function_413(
                argument_01            => '#####',
                argument_552               => NULL,
                argument_650           => NULL,
                argument_161           => '########_#######',
                argument_680           => NULL,
                argument_73            => dataset_4876.column_76,
                argument_1105            => dataset_45.column_601,
                argument_252           => dataset_104.column_753,
                argument_672           => dataset_228.column_534) AS column_7116 
    FROM
        dataset_4878               dataset_4876,
        dataset_260      dataset_259,
        dataset_50   dataset_86,
        dataset_227  dataset_228,
        dataset_360  dataset_104,
        dataset_6462 dataset_899,
        dataset_269 dataset_45
    WHERE 1=1
        AND dataset_259.column_76 = dataset_4876.column_76      
        AND dataset_86.column_07 = dataset_4876.column_07     
        AND dataset_228.column_532 = dataset_4876.column_532   
          AND dataset_228.column_76 = dataset_4876.column_76     
        AND dataset_4876.column_598=dataset_45.column_598
        AND CASE WHEN dataset_104.column_753 = '#############_##' AND dataset_4876.column_76 = '###_##_##' THEN
                         DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                 WHEN dataset_4876.column_76 = '###_##' THEN 
                        DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                 ELSE dataset_228.column_534        
            END = dataset_228.column_534       
          AND dataset_228.column_533  = '########'
          AND dataset_4876.column_655 = '###########'
          AND dataset_4876.column_189 = '#########'
          AND dataset_4876.column_204 >= dataset_899.column_17275

),
--#### ####
dataset_6466       AS (select 
        NULL                                                AS column_4785, --### ## ### ### ######_#### 
        dataset_259.column_555                                        AS column_555,
        dataset_3310.column_573                                         AS column_07,
        dataset_86.column_165                                       AS column_165,
        NULL                                                 AS column_560,
        dataset_333.column_535                                         AS column_535,
        dataset_333.column_534                                        AS column_2355,
        dataset_333.column_530                                          AS column_2356,
        '####'                                                 AS column_531,
        NULL                                                 AS column_562,
        dataset_3310.column_532                                      AS column_532,
        dataset_45.column_598                                                 AS column_558,
        dataset_3310.column_599                                      AS column_3063,
        TRUNC(dataset_899.column_17275)                                     AS column_566,
        TRUNC(dataset_899.column_17275)                                     AS column_567,
        '#'                                                 AS column_552,
        dataset_3310.column_735                                             AS column_549,
        0                                                   AS column_6332 ,--### ## ### ### ######_####
        '#######_######_########'                             AS column_565,
        dataset_3310.column_573 || '.' || dataset_3310.column_599    || '.' 
        ||dataset_3310.column_533  ||'.'|| dataset_3310.column_555               AS column_569,
        '#### ######### ########### ####'                     AS column_568,
        '#########'                                         AS column_564,
        NULL                                                 AS column_189,
        dataset_4885.column_7116                                     AS column_7116 

FROM
         dataset_260      dataset_259
        ,dataset_4870       dataset_3310
        ,dataset_50   dataset_86
        ,dataset_270 dataset_268
        ,dataset_269 dataset_45
        ,dataset_227  dataset_333
        ,dataset_4869  dataset_4885
        ,dataset_6462 dataset_899
 WHERE 1=1
         AND dataset_45.column_601 IN ('##_####', '##_####')
         AND dataset_259.column_555 = dataset_3310.column_555       
         --######## ####
        AND dataset_333.column_76 = dataset_259.column_76     
        AND dataset_333.column_532 = dataset_3310.column_532   
        AND dataset_333.column_533   IN ('########_##########', '########_#######_#########' )
        and DECODE(dataset_333.column_533,'########_##########','##########','########_#######_#########','#########') = dataset_3310.column_533  
        AND dataset_86.column_07 = dataset_3310.column_573
        AND dataset_268.column_599 = dataset_3310.column_599   
        AND dataset_45.column_598 = dataset_268.column_598
        AND dataset_4885.column_76=dataset_259.column_76
)
  
select * from dataset_6463          

UNION ALL

select * from dataset_6464     

union all

select * from dataset_6465              

UNION ALL

select * from dataset_6466      