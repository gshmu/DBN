WITH dataset_1981 AS
(SELECT dataset_1981.column_07,
       dataset_1981.column_451,
       dataset_1981.column_3063,
       dataset_1981.column_452,
       dataset_1981.column_4127,
       dataset_1981.column_604,
       dataset_1981.column_708,
       dataset_1981.column_714,
       dataset_1981.column_1446,
       dataset_1981.column_3084,
       dataset_1981.column_2730,
       dataset_1981.column_2726,
       dataset_1981.column_2725,
       dataset_1981.column_3759,
       dataset_1981.column_6375,
       dataset_647.column_2055,
       dataset_268.column_18072,
       dataset_1981.column_4128,
       DECODE (dataset_461.column_6384,
               '######_####', dataset_1981.column_4126,
               '####', dataset_1981.column_598,
               '#############_####', dataset_1981.column_598 || dataset_1981.column_3120,
               '#############', dataset_1981.column_451,
               '#########_####', dataset_647.column_2055)
           column_6383,
       DECODE (
           dataset_461.column_6384,
           '######_####', NVL (dataset_2538.column_742, dataset_1981.column_4126),
           '####', NVL (dataset_1981.column_4127, dataset_1981.column_598),
           '#############_####', NVL (
                                     dataset_2539.column_742,
                                        NVL (dataset_1981.column_4127,
                                             dataset_1981.column_598)
                                     || ' '
                                     || dataset_1981.column_3120),
           '#############', NVL (dataset_86.column_742, dataset_1981.column_451),
           '#########_####', dataset_268.column_18072)
           AS column_6558,
       dataset_1981.column_2985,
       dataset_259.column_962,
       dataset_259.column_76,
       dataset_460.column_3154,
       dataset_1981.column_6377,
       dataset_1981.column_5280,
       dataset_1981.column_11
  FROM dataset_1634                   dataset_1981
       INNER JOIN dataset_2483      dataset_2484
           ON     dataset_2484.column_598 = dataset_1981.column_598
             AND NVL (dataset_2484.column_1446, dataset_1981.column_1446) =
                  dataset_1981.column_1446       
       INNER JOIN dataset_2485 dataset_461 ON dataset_461.column_3118 = dataset_2484.column_3118   
       INNER JOIN dataset_646        dataset_647
           ON dataset_647.column_2031 = dataset_1981.column_2031         
       INNER JOIN dataset_6746    dataset_268 ON dataset_647.column_2055 = dataset_268.column_2055   
       INNER JOIN dataset_260      dataset_259
           ON dataset_1981.column_76 = dataset_259.column_76     
       INNER JOIN dataset_315    dataset_86
           ON dataset_1981.column_451 = dataset_86.column_451      
       INNER JOIN dataset_2544        dataset_2539
           ON     dataset_1981.column_598 = dataset_2539.column_598
              AND dataset_1981.column_3120 = dataset_2539.column_3120       
       LEFT OUTER JOIN dataset_459                    dataset_460
           ON (    dataset_1981.column_451 = dataset_460.column_451      
               AND dataset_1981.column_11 = dataset_460.column_11
               AND dataset_1981.column_3063 = dataset_460.column_3063)
       LEFT OUTER JOIN dataset_269 dataset_2538
           ON dataset_1981.column_4126 = dataset_2538.column_598
WHERE     1 = 1
       AND dataset_1981.column_07 = 
       AND dataset_2484.column_3118 = 
       AND dataset_1981.column_714 = '#####'
       AND dataset_461.column_3119   != '########'
       AND dataset_1981.column_714=nvl(dataset_2484.column_714,dataset_1981.column_714)
       AND dataset_1981.column_1446=nvl(dataset_2484.column_1446,dataset_1981.column_1446)
       AND ((dataset_461.column_6385 = '#' AND dataset_1981.column_2726 - dataset_1981.column_2725 = 0)
                                            OR (dataset_1981.column_2726 - dataset_1981.column_2725 > 0))
       )
SELECT DENSE_RANK () OVER (ORDER BY dataset_333.column_6383, dataset_333.column_6555, dataset_333.column_714, dataset_333.column_1446) AS column_6557,
       dataset_333.*
FROM ( SELECT column_1056,
       column_1420,
       CASE WHEN column_18073 = '######'
        THEN column_598
       ELSE NULL
       END AS column_598,
       CASE WHEN column_6555 = '#####'
        THEN '####'
       ELSE column_6555   
       END AS column_6555,
       column_15029,
       column_874,
       column_714,
       column_1446,
       column_2055,
       column_18072,
       column_6383,
       column_6558,
       column_1309,
       column_18073,
       DECODE (column_18073,  '######', column_549,  '#####', -column_549)
           AS column_549,
       column_962,
       column_76,
       column_3154,
       CASE
           WHEN column_1420 IN ('############', '##########')
           THEN  '###########'
           ELSE  '######'
       END  AS column_18074,
       CASE
           WHEN column_6563 > 0
            AND column_6555 = '#####'
            AND column_1420 NOT IN ('############', '##########')
            THEN '#'
           ELSE '#'
       END  AS column_6578
       ,column_11
  FROM (SELECT dataset_977.column_1056,
               CASE

                   WHEN dataset_977.column_1064 = '##########'
                   THEN  dataset_1981.column_3063      
                   WHEN dataset_977.column_1064 = '############' AND dataset_977.column_6175 = '#####'
                   THEN '#####'
                   ELSE  dataset_977.column_1064     
               END AS column_1420,
               dataset_1981.column_4127      AS column_598,
               CASE
                   WHEN dataset_977.column_1064 = '##########' THEN dataset_1981.column_4128      
               END  AS column_15029,
               dataset_1981.column_604        AS column_874,
               CASE
                   WHEN dataset_977.column_1064 = '##########'
                   THEN  dataset_1981.column_708    
                   ELSE  dataset_977.column_549
               END  AS column_549,
               dataset_1981.column_714,
               dataset_1981.column_1446,
               dataset_1981.column_6383,
               dataset_1981.column_6558,
               dataset_1981.column_2055,
               dataset_1981.column_18072,
               CASE
                   WHEN dataset_977.column_1064      IN
                            ('############', '##########')
                   THEN
                       TO_CHAR (dataset_977.column_3816)
                   ELSE
                       dataset_1981.column_2985  
               END
                   AS column_1309,
               DECODE (dataset_977.column_552, '#', '######', '#####')
                   AS column_18073,
                dataset_259.column_962,
                dataset_259.column_76,
               dataset_1981.column_3154,
               CASE
                   WHEN  = '#' AND dataset_1981.column_3084 = '#' THEN 0
                   ELSE dataset_1981.column_2730        
               END
                   AS column_6563,
               CASE
                   /* ####### ###### ## ###/###_#### #### ### ########### ######## ####### # */
                   WHEN dataset_1981.column_2726 - dataset_1981.column_2725 =
                        0
                   THEN
                       NVL2 (dataset_1981.column_6375, '###_####', '###')
                   ELSE
                       '#####'
               END
                   AS column_6555
                   ,dataset_1981.column_11 AS column_11
          FROM dataset_978                  dataset_977
            INNER JOIN dataset_1981
                ON (    dataset_977.column_07 = dataset_1981.column_07     
                         AND dataset_977.column_451 = dataset_1981.column_451      
                         AND dataset_977.column_452 = dataset_1981.column_452)
            INNER JOIN dataset_260      dataset_259
                ON  dataset_977.column_76 = dataset_259.column_76     
         WHERE     dataset_977.column_07 = 
               AND dataset_977.column_1064      <> '##########'
               AND dataset_977.column_5289     IS NULL
               AND dataset_977.column_148           IS NULL
               AND NOT EXISTS
                       (SELECT 1
                          FROM dataset_978                 dataset_6747
                         WHERE     1 = 1
                               AND dataset_6747.column_5289 = dataset_977.column_3816
                               AND dataset_6747.column_1064      LIKE '####_%'))
UNION ALL
SELECT dataset_665.column_1056,
         dataset_665.column_1420,
         NULL  AS column_598,
         column_6555,
         dataset_665.column_15029,
         dataset_665.column_874,
         dataset_665.column_714,
         dataset_665.column_1446,
         dataset_665.column_2055,
         dataset_665.column_18072,
         dataset_665.column_6383,
         dataset_665.column_6558,
         dataset_665.column_1309,
         '#####'                        AS column_18073,
         SUM (column_18075 + column_18076) * -1 AS column_549,
         dataset_665.column_962,
         dataset_665.column_76,
         '######'                           AS column_3154,
         '###########' AS column_18074,
         '#'                           AS column_6578,
         column_11

    FROM (SELECT dataset_665.column_900    
                     AS column_1056,
                 dataset_312.column_1064     
                     AS column_1420,
                 dataset_665.column_1479   
                     AS column_15029,
                 dataset_665.column_532   
                     AS column_874,
                 NVL (dataset_666.column_1482, 0) column_18075,
                 NVL (dataset_666.column_1483, 0) column_18076,
                 dataset_1981.column_714,
                 dataset_312.column_1446,
                 dataset_1981.column_2055,
                 dataset_1981.column_18072,
                 dataset_1981.column_6383,
                 dataset_1981.column_6558,
                 dataset_665.column_148           AS column_1309,
                 dataset_665.column_718         AS column_718,
                 dataset_1981.column_962,
                 dataset_1981.column_76,
                  CASE
                   /* ####### ###### ## ###/###_#### #### ### ########### ######## ####### # */
                   WHEN dataset_1981.column_2726 - dataset_1981.column_2725 =
                        0
                   THEN
                       NVL2 (dataset_1981.column_6375, '###_####', '###')
                   ELSE
                       '####'
               END
                   AS column_6555,
                   dataset_1981.column_11 AS column_11,
                 DENSE_RANK ()
                 OVER (
                     ORDER BY
                         dataset_1981.column_6383,
                         dataset_1981.column_714,
                         dataset_312.column_1446,
                         dataset_665.column_148)
                     AS column_18077
            FROM dataset_667           dataset_665
                 INNER JOIN dataset_311        dataset_312
                     ON (dataset_665.column_148 = dataset_312.column_148)
                 INNER JOIN dataset_668                 dataset_666
                     ON (    dataset_665.column_148 = dataset_666.column_148          
                         AND dataset_666.column_718 = dataset_665.column_718)
                 INNER JOIN dataset_1981
                     ON (    dataset_666.column_07 = dataset_1981.column_07     
                         AND dataset_666.column_451 = dataset_1981.column_451      
                         AND dataset_666.column_452 = dataset_1981.column_452)
           WHERE dataset_665.column_07 = 
                AND dataset_665.column_10 <> '####'
               )
         dataset_665
GROUP BY dataset_665.column_1056,
         dataset_665.column_1420,
         dataset_665.column_15029,
         dataset_665.column_874,
         dataset_665.column_714,
         dataset_665.column_1446,
         dataset_665.column_2055,
         dataset_665.column_18072,
         dataset_665.column_6383,
         dataset_665.column_6558,
         dataset_665.column_1309,
         dataset_665.column_718,
         dataset_665.column_962,
         dataset_665.column_76,
         dataset_665.column_6555,
         dataset_665.column_11,
         dataset_665.column_18077
UNION ALL
SELECT dataset_333.column_1056,
         dataset_333.column_1420,
         dataset_333.column_598,
         column_6555,
         dataset_333.column_15029,
         dataset_333.column_874,
         dataset_333.column_714,
         dataset_333.column_1446,
         dataset_333.column_2055,
         dataset_333.column_18072,
         dataset_333.column_6383,
         dataset_333.column_6558,
         dataset_333.column_1309,
         '#######_#####' AS column_18073,
         SUM (column_549) * -1 column_549, -- #### ## ######## (####### #####) ########
         dataset_333.column_962,
         dataset_333.column_76,
         '######' AS column_3154,
         '###########' AS column_18074,
         '#' AS column_6578,
         column_11
    FROM (SELECT dataset_312.column_2264          AS column_1056,
                 dataset_312.column_1064      AS column_1420,
                 NULL AS column_598,
                 dataset_312.column_2963             AS column_15029,
                 dataset_312.column_532    AS column_874,
                 (  dataset_314.column_3881
                    + dataset_314.column_3880
                    - NVL (dataset_314.column_712, 0))
                 - (NVL (dataset_666.column_549, 0)) column_549,
                 dataset_1981.column_714,
                 dataset_312.column_1446,
                 dataset_1981.column_2055,
                 dataset_1981.column_18072,
                 dataset_1981.column_6383,
                 dataset_1981.column_6558,
                 dataset_312.column_148           AS column_1309,
                 dataset_1981.column_962,
                 dataset_1981.column_76,
                  CASE
                   /* ####### ###### ## ###/###_#### #### ### ########### ######## ####### # */
                   WHEN dataset_1981.column_2726 - dataset_1981.column_2725 =
                        0
                   THEN
                       NVL2 (dataset_1981.column_6375, '###_####', '###')
                   ELSE
                       '####'
               END
                   AS column_6555,
                   dataset_1981.column_11 as column_11,
                 DENSE_RANK () OVER ( ORDER BY
                         dataset_1981.column_6383,
                         dataset_1981.column_714,
                         dataset_312.column_1446,
                         dataset_312.column_148)
                     AS column_18077
           FROM dataset_311        dataset_312
                 INNER JOIN dataset_313                   dataset_314
                     ON (dataset_312.column_148 = dataset_314.column_148)
                 INNER JOIN dataset_1981
                     ON (dataset_314.column_07 = dataset_1981.column_07     
                         AND dataset_314.column_451 = dataset_1981.column_451      
                         AND dataset_314.column_452 = dataset_1981.column_452)
                 LEFT OUTER JOIN
                 (SELECT dataset_666.column_148,
                           dataset_666.column_07,
                           dataset_666.column_451,
                           dataset_666.column_452,
                           SUM ( NVL (dataset_666.column_1483, 0) + NVL (dataset_666.column_1482, 0)) AS column_549
                      FROM dataset_668                 dataset_666
                     WHERE dataset_666.column_07 = 
                  GROUP BY dataset_666.column_148,
                           dataset_666.column_07,
                           dataset_666.column_451,
                           dataset_666.column_452) dataset_666
                     ON (dataset_314.column_148 = dataset_666.column_148          
                         AND dataset_314.column_07 = dataset_666.column_07     
                         AND dataset_314.column_451 = dataset_666.column_451      
                         AND dataset_314.column_452 = dataset_666.column_452)
           WHERE     dataset_312.column_07 = 
                 AND (dataset_312.column_684               IN ('####', '####')
                        OR ( dataset_312.column_684               IN ('####')
                            AND NOT EXISTS (SELECT 1 FROM dataset_667           dataset_665 WHERE dataset_665.column_148 = dataset_312.column_148)
                            )
                    ) ) dataset_333
            GROUP BY dataset_333.column_1056,
                     dataset_333.column_1420,
                     dataset_333.column_598,
                     dataset_333.column_15029,
                     dataset_333.column_874,
                     dataset_333.column_714,
                     dataset_333.column_1446,
                     dataset_333.column_2055,
                     dataset_333.column_18072,
                     dataset_333.column_6383,
                     dataset_333.column_6558,
                     dataset_333.column_1309,
                     dataset_333.column_962,
                     dataset_333.column_76,
                     dataset_333.column_6555,
                     dataset_333.column_11,
                     column_18077 ) dataset_333
ORDER BY dataset_333.column_6383,
     dataset_333.column_714,
     dataset_333.column_1446,
     dataset_333.column_1056      desc,
     dataset_333.column_1420