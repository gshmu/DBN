--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_#########_####.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        #######
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ ####  ###_#########_####';
exception
when others then null;
end;
/

begin
execute immediate '#### #####  ###_#########_#### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW  materialized_view_13
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_1640
      ,column_2200
      ,column_961
      ,column_31
      ,column_976
      ,column_977
  FROM dataset_920@dblink_02.EQ
/

COMMIT
/
       





