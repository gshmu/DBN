/******************************************************************************
    ##### #####: #######_#########_######
    #########:   #######_#########_######
    ########:    ####### (###_##########)
    ######### #### ####### ##### ### #######_#########_###### ##### (####### #####)

    #######:
          (####)                           (####)

        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - #####_####					   ##### ## ####
        - #######_######                   ####### ######
        - #######_##                       ### ####### ##
        - #######_######                   ####### ######
        - ####                             ####
        - ####                             ####
        - ########                         ########
        - #######                          #######
        - ######_#                         ###### #
        - ######_#                         ###### #
        - ###########_#######              ########### #######
        - #######_######_#######           ####### ###### #######


    ###### ## ###########:  
							###(####### ######### ######)
							||###(#######)
							||<####### ##### ##>
							|| # (#########)
							|| :#_###_##
							|| ###.###_#######_######
							|| #.###_#######_######
							|| #.####_##
							|| #.####
							|| #.########_####
							|| #.#######_####
*******************************************************************************/
SELECT column_1117              AS column_1117,
       column_354             AS column_354,
       column_12270                  AS column_12270,
       column_1328            AS column_1328,
       column_76              AS column_76,
       column_874               AS column_874,
       column_7105                AS column_7105,
       column_12271               AS column_12271,
       column_12272           AS column_12272,
       column_12273           AS column_12273,
       column_12274           AS column_12274,
       column_12275           AS column_12275    
  FROM (
    WITH 
    dataset_263 AS(
        SELECT package_11.package_function_04(
                            argument_01             => '#####',
                            argument_40             => '##############',
                            argument_18             => dataset_899.column_354,
                            argument_41             => '########_####',
                            argument_42             => '#######_#####') as column_2343  
        FROM dataset_62, dataset_360  dataset_899
    ),

    dataset_943   AS (
        SELECT TRIM(regexp_substr(dataset_263.column_2343,'[^,]+', 1, LEVEL)) AS column_533  
        FROM dataset_263 CONNECT BY regexp_substr(dataset_263.column_2343, '[^,]+', 1, LEVEL) IS NOT NULL),

     dataset_944           as(SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                       FROM dataset_360  dataset_899,dataset_946  dataset_945 ),
      dataset_2723      as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_#########_####:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_#########_####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                           FROM dataset_360  dataset_899,dataset_946  dataset_945),
             
       dataset_959        AS (SELECT /*+ ########### */ dataset_945.column_530  as column_591,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '###_####_#######:#######',
                                            argument_42             => '#######_######'))as column_2354  
                           FROM dataset_360  dataset_899,dataset_946  dataset_945),                  
                        
    dataset_4863          AS (
        SELECT DISTINCT
            dataset_228.column_527                 AS column_527,
            dataset_228.column_528                 AS column_528,
            dataset_228.column_529                 AS column_529,
            dataset_228.column_530                 AS column_530,
            dataset_228.column_531                 AS column_531,
            dataset_228.column_532                 AS column_532,
            dataset_228.column_533                 AS column_533,
            dataset_228.column_534                 AS column_534,
            package_131.package_function_134
                (dataset_228.column_527,
                 dataset_228.column_528,
                 dataset_228.column_529,
                 dataset_948.column_2344)        AS column_535,
            package_54.package_function_165 
                (argument_01              => '#####',
                 argument_370             => dataset_228.column_724,
                 argument_17                  => '#'
                 )                         AS column_76     
        FROM dataset_229                  dataset_228,
             dataset_944           dataset_948 
       WHERE dataset_228.column_530 = dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_230.column_527                  AS column_527,
            dataset_230.column_528                  AS column_528,
            dataset_230.column_529                  AS column_529,
            dataset_230.column_530                  AS column_530,
            dataset_230.column_531                  AS column_531,
            dataset_230.column_532                  AS column_532,
            dataset_230.column_533                  AS column_533,
            dataset_230.column_534                  AS column_534,
            package_131.package_function_134
                (dataset_230.column_527,
                 dataset_230.column_528,
                 dataset_230.column_529,
                 dataset_948.column_2344)        AS column_535,
            package_54.package_function_165 
                (argument_01              => '#####',
                 argument_370             => dataset_230.column_724,
                 argument_17                  => '#'
                 )                         AS column_76     
        FROM dataset_231          dataset_230,
             dataset_944           dataset_948 
       WHERE dataset_230.column_530=dataset_948.column_591
        UNION ALL
        SELECT DISTINCT
            dataset_232.column_538                 AS column_527,
            dataset_232.column_539                 AS column_528,
            dataset_232.column_540                 AS column_529,
            dataset_232.column_541                 AS column_530,
            dataset_232.column_531                 AS column_531,
            dataset_232.column_542                 AS column_532,
            '#######'                      AS column_533,
            dataset_232.column_534                 AS column_534,
            package_131.package_function_134
                (dataset_232.column_538,
                 dataset_232.column_539,
                 dataset_232.column_540,
                 dataset_948.column_2344)        AS column_535,
            package_54.package_function_165 
                (argument_01              => '#####',
                 argument_370             => dataset_232.column_724,
                 argument_17                  => '#'
                )                           AS column_76     
        FROM dataset_233           dataset_232,
             dataset_944           dataset_948 
       WHERE dataset_232.column_541 = dataset_948.column_591),

    dataset_947       AS (
        SELECT DISTINCT 
            dataset_102.*
          FROM dataset_4863          dataset_102,
               dataset_943   dataset_2719
         WHERE 1=1
           AND dataset_102.column_531 = '####'
           AND dataset_102.column_533 = dataset_2719.column_533  
      ORDER BY dataset_102.column_533,
               dataset_102.column_528
    ),  
    
    dataset_4864 AS (
        SELECT *
          FROM (
               SELECT 
                    dataset_228.column_527                 AS column_527,
                    dataset_228.column_528                 AS column_528,
                    dataset_228.column_530                 AS column_530,
                    dataset_228.column_531                 AS column_531,
                    dataset_228.column_532                 AS column_532,
                    dataset_228.column_533                 AS column_533,
                    dataset_228.column_534                 AS column_534,
                    dataset_228.column_598                       AS column_598,
                   package_131.package_function_134
                       (dataset_228.column_527,
                     dataset_228.column_528,
                     dataset_228.column_529,
                     dataset_2726.column_2344)             AS column_535,
                    dataset_228.column_724                 AS column_724,
                    package_54.package_function_165 
                    (argument_01              => '#####',
                     argument_370             => dataset_228.column_724,
                     argument_17                  => '#'
                     )                             AS column_76,
                    1                              AS column_500
             FROM dataset_229                  dataset_228, dataset_2723      dataset_2726 
            WHERE (column_1328, column_1446, column_533, column_531, column_534, NVL(column_598, '$_$')) IN (
                SELECT 
                     MAX(column_1328) column_1328
                    ,MAX(column_1446) column_1446
                    ,column_533
                    ,column_531
                    ,column_534
                    ,NVL(column_598, '$_$')
                 FROM dataset_229                  dataset_2079
                WHERE dataset_2079.column_533   IN ('########_##########', '########_#######_#########', '########', '#######_###')
                  AND dataset_2079.column_531 = '####'
                GROUP BY
                    dataset_2079.column_531,
                    dataset_2079.column_532,
                    dataset_2079.column_533,
                    dataset_2079.column_724,
                    dataset_2079.column_534,
                    NVL(dataset_2079.column_598, '$_$')
                ) AND  dataset_228.column_530 = dataset_2726.column_591                  
            UNION ALL      
            SELECT 
                dataset_230.column_527                  AS column_527,
                dataset_230.column_528                  AS column_528,
                dataset_230.column_530                  AS column_530,
                dataset_230.column_531                  AS column_531,
                dataset_230.column_532                  AS column_532,
                dataset_230.column_533                  AS column_533,
                dataset_230.column_534                  AS column_534,
                NULL                           AS column_598,
                package_131.package_function_134
                (dataset_230.column_527,
                 dataset_230.column_528,
                 dataset_230.column_529,dataset_2726.column_2344
                 )                                AS column_535,
                dataset_230.column_724                  AS column_724,
                package_54.package_function_165 
                (argument_01              => '#####',
                 argument_370             => dataset_230.column_724,
                 argument_17                  => '#'
                 )                             AS column_76,
                2                              AS column_500        
            FROM dataset_231          dataset_230, dataset_2723      dataset_2726
            WHERE column_896 IN (
                SELECT DISTINCT MAX(column_896)
                 FROM dataset_231          dataset_4865
                WHERE dataset_4865.column_533   IN ('########_##########', '########_#######_#########', '########', '#######_###')
                  AND dataset_4865.column_531  = '####'
                GROUP BY
                    dataset_4865.column_531,
                    dataset_4865.column_532,
                    dataset_4865.column_533,
                    dataset_4865.column_724,
                    dataset_4865.column_534
                ) AND dataset_230.column_530 = dataset_2726.column_591
            )
        ORDER BY column_724, column_532, column_500 ASC
    ),
    
    dataset_4866     AS (
        SELECT *
          FROM dataset_4864
         WHERE column_500 = 1
    ),
    
    dataset_4867     AS (
        SELECT *
          FROM dataset_4864 dataset_4868
         WHERE column_500 = 2
           AND NOT EXISTS (
                    SELECT *
                      FROM dataset_4866     dataset_3346
                     WHERE dataset_3346.column_532 = dataset_4868.column_532   
                       AND dataset_3346.column_724 = dataset_4868.column_724            
                       AND dataset_3346.column_533 = dataset_4868.column_533  
                       AND dataset_3346.column_531 = dataset_4868.column_531
                       --### ##.##########_###### = ##.##########_######
                )
    ),
    
    dataset_227  as (
        select * from dataset_4866    
        union all
        select * from dataset_4867
    ),    
      dataset_4869  AS  (
          SELECT /*+ ########### */ 
              dataset_333.column_12935,
              dataset_333.column_1065,
              dataset_333.column_1064,
              dataset_333.column_12936,
              dataset_333.column_76, 
            dataset_333.column_534,
              package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => dataset_333.column_12935,
                argument_650             => dataset_333.column_1065,
                argument_161             => dataset_333.column_1064,
                argument_679              => dataset_333.column_12936,
                argument_73              => dataset_333.column_76,
                argument_252             => dataset_899.column_753,
                argument_672             => dataset_333.column_534) as column_7116 
        FROM 
        (
            -- #######_########
              SELECT DISTINCT 
                  '####_####'                     AS column_12935, 
                  dataset_331.column_1065, 
                  dataset_331.column_1064, 
                  '######'                             AS column_12936,
                  dataset_331.column_76 ,
                dataset_331.column_2442                    as column_534       
              FROM dataset_330                  dataset_331
              WHERE dataset_331.column_10 = '#######'
                  
              -- ####
              UNION
              SELECT
                  NULL                as column_12935, 
                NULL                as column_1065, 
                NULL                as column_1064, 
                NULL                as column_12936,
                '###_##'            as column_76 ,
                NULL                as column_534       
            FROM dataset_62     
            
            UNION
            SELECT
                NULL                as column_12935, 
                NULL                as column_1065, 
                NULL                as column_1064, 
                NULL                as column_12936,
                '###_##'            as column_76,
                NULL                as column_534       
            FROM dataset_62     
            
            UNION
            SELECT
                NULL                as column_12935, 
                NULL                as column_1065, 
                NULL                as column_1064, 
                NULL                as column_12936,
                '###_##'            as column_76,
                NULL                as column_534       
            FROM dataset_62     
              -- #### ###
          ) dataset_333,dataset_360  dataset_899
    ),
     dataset_949                            as (
            select /*+ ########### */ column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_360  dataset_104
                WHERE column_2345 = 
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),
             
    dataset_952          AS (
        SELECT /*+ ########### */ dataset_259.column_555,
            dataset_953.column_2346      AS column_76,
            dataset_953.column_2347      AS column_2348       
           FROM dataset_954             dataset_953, dataset_260      dataset_259,dataset_949                            dataset_964
          WHERE  dataset_953.column_2349 = '###_#######'
            AND dataset_953.column_354 = '###_#########'
            AND dataset_953.column_2350 = '######+'
            AND dataset_953.column_2351 = '###_########_######'
            AND dataset_953.column_221 = '#######_######'
            AND dataset_953.column_2352 = '*'
            AND dataset_953.column_2346 = dataset_259.column_76     
            AND dataset_259.column_76 = dataset_964.column_76
    ),
    
   dataset_4870       as (
        SELECT
            column_548,
            column_573,
            column_571,
            column_898,
            column_555,
            column_599,
            column_533,
            column_545,
            column_735,
            column_532   
        FROM
        (
        SELECT
            column_548,
            column_573,
            column_571,
            column_898,
            column_555,
            column_599,
            column_533,
            column_545,
            column_735,
            column_532 ,
            column_8599,
            column_8598,
            ROW_NUMBER() OVER(
                PARTITION BY column_573, column_599, column_533, column_555       
                ORDER BY
                    column_8599       DESC ,column_8598         DESC
            ) AS column_5369
        FROM
            dataset_3311            dataset_3310 WHERE column_545='#####_####' 
        )
        WHERE column_5369 = 1),
    dataset_242  AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_549) AS column_735,
            package_131.package_function_135(dataset_244.column_535, dataset_2726.column_2344, dataset_962.column_2354) AS column_535,
              dataset_244.column_555,
              dataset_244.column_532,
              dataset_244.column_7116,
              dataset_244.column_571
         FROM 
             dataset_226     dataset_235, 
             dataset_247      dataset_244,
             dataset_2723      dataset_2726,
             dataset_959        dataset_962
        WHERE     dataset_235.column_525 <= 
              AND dataset_235.column_545 = '##########_####'
              AND dataset_235.column_544 = dataset_244.column_544 
              AND dataset_244.column_531 = '####'
            AND dataset_235.column_549 <> 0
            AND dataset_244.column_2356=dataset_2726.column_591
            AND dataset_244.column_2356=dataset_962.column_591  
               AND EXISTS (SELECT NULL
                         FROM dataset_947       dataset_956
                        WHERE dataset_956.column_535 = dataset_244.column_535)
            AND (dataset_235.column_544, dataset_235.column_545, dataset_235.column_525) IN
                 ( SELECT 
                     dataset_235.column_544,
                    dataset_235.column_545,
                    MAX (dataset_235.column_525)
                  FROM dataset_226     dataset_235
                  WHERE column_525 <= 
                       AND dataset_235.column_545 = '##########_####'
                    GROUP BY dataset_235.column_544, dataset_235.column_545)
         GROUP BY 
             dataset_244.column_535,
            dataset_244.column_555,
            dataset_244.column_532,
            dataset_244.column_7116,
              dataset_244.column_571,
            dataset_2726.column_2344,
            dataset_962.column_2354  
         ORDER BY column_532, column_535
    ),
             
    dataset_4871  AS (  
        SELECT /*+ ########### */ 
            SUM (DECODE (dataset_4872.column_552,
                                     '#', dataset_4872.column_549,
                                     '#', -1 * dataset_4872.column_549))
                             AS column_735,
            package_131.package_function_135(dataset_244.column_535, dataset_2726.column_2344, dataset_962.column_2354) AS column_535,
            dataset_244.column_555,
            dataset_244.column_532,
            dataset_244.column_7116 
        FROM 
            dataset_246                 dataset_4872, 
            dataset_247      dataset_244,
            dataset_2723      dataset_2726,
            dataset_959        dataset_962
        WHERE 1 = 1
            AND dataset_4872.column_10757 = 0
            AND dataset_4872.column_544 = dataset_244.column_544 
              AND dataset_244.column_571 = '###########'
            AND dataset_244.column_531 = '####'
            AND dataset_4872.column_549 <> 0
            AND dataset_244.column_2356 = dataset_2726.column_591
            AND dataset_244.column_2356 = dataset_962.column_591           
            AND EXISTS (SELECT NULL
                        FROM dataset_947      
                        WHERE column_535 = dataset_244.column_535)
        GROUP BY 
            dataset_244.column_535,
            dataset_244.column_555,
            dataset_244.column_532,
            dataset_244.column_7116,
            dataset_2726.column_2344,
            dataset_962.column_2354  
        ORDER BY column_532, column_535
    ),
                 
    dataset_4873       AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_735) AS column_735,
            dataset_235.column_535         AS column_535,
              dataset_235.column_555,
              dataset_235.column_532,
              dataset_235.column_7116 
         FROM 
             dataset_242  dataset_235
        WHERE 1=1
              AND dataset_235.column_571 = '#########'
         GROUP BY 
             dataset_235.column_535,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116 
         ORDER BY column_532, column_535
    ),
    
    dataset_4874         AS (  
        SELECT /*+ ########### */ 
            SUM (dataset_235.column_735) AS column_735,
            dataset_235.column_535         AS column_535,
              dataset_235.column_555,
              dataset_235.column_532,
              dataset_235.column_7116 
         FROM 
             dataset_242  dataset_235
        WHERE 1=1
              AND dataset_235.column_571 = '###########'
         GROUP BY 
             dataset_235.column_535,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116 
         ORDER BY column_532, column_535
    ),      
    
    dataset_4875              AS (
        SELECT /*+ ########### */ 
            SUM(dataset_4876.column_09)                                 AS column_735,
            dataset_4877.column_535                                           AS column_535,
              dataset_259.column_555                                           AS column_555,
              dataset_4876.column_532                                           AS column_532,
              package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => NULL,
                argument_650             => NULL,
                argument_161             => '########_#######',
                argument_679              => NULL,
                argument_73              => dataset_4876.column_76,
                argument_1105              => dataset_45.column_601,
                argument_252             => dataset_104.column_753,
                argument_672             => dataset_4877.column_534)     AS column_7116 
        FROM
            dataset_4878               dataset_4876,
            dataset_227  dataset_4877,
            dataset_260      dataset_259,
            dataset_269 dataset_45,
            dataset_360  dataset_104
        WHERE 1=1
            AND dataset_259.column_76 = dataset_4876.column_76     
            AND dataset_4876.column_598 = dataset_45.column_598
            AND dataset_4876.column_655 = '###########' 
            AND dataset_4877.column_533 = '########'
            AND dataset_4877.column_532 = dataset_4876.column_532   
              AND dataset_4877.column_76 = dataset_4876.column_76     
            AND CASE WHEN dataset_104.column_753 ='#############_##' AND dataset_4876.column_76 = '###_##_##' THEN
                         DECODE(dataset_45.column_11330 ,'#########_#######','###','#########_#####','###','###')
                     WHEN dataset_4876.column_76 = '###_##' THEN
                         DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                     ELSE dataset_4877.column_534        
                END = dataset_4877.column_534                          
        GROUP BY 
            dataset_4877.column_535,
              dataset_259.column_555,
              dataset_4876.column_532,
              dataset_4876.column_76,
              dataset_104.column_753,
              dataset_4877.column_534,
              dataset_45.column_601
    ),
    
    dataset_4879             AS (  
        SELECT /*+ ########### */ 
            SUM(dataset_331.column_735)                                     AS column_735,
            package_131.package_function_134
                (dataset_331.column_2400,
                 dataset_331.column_2401,
                 dataset_331.column_2396,
                 dataset_2726.column_2344)                                 AS column_535,
            dataset_259.column_555                                       AS column_555,
            dataset_331.column_532                                       AS column_532,
            dataset_268.column_7116                                      AS column_7116 
        FROM 
            dataset_330                  dataset_331,
            dataset_260      dataset_259,
            dataset_4869  dataset_268,
            dataset_2723      dataset_2726
        WHERE 1 = 1
            AND dataset_331.column_10 IN ('#######', '##########')
            AND dataset_259.column_76 = dataset_331.column_76     
            AND dataset_268.column_12935 = '####_####'
            AND dataset_268.column_1065 = dataset_331.column_1065  
            AND dataset_268.column_1064 = dataset_331.column_1064     
            AND dataset_268.column_76 = dataset_259.column_76       
            and dataset_268.column_534=dataset_331.column_2442                   
            AND dataset_331.column_530=dataset_2726.column_591
        GROUP BY 
            dataset_331.column_2400,
            dataset_331.column_2401,
            dataset_331.column_2396,
            dataset_2726.column_2344,
            dataset_259.column_555,
            dataset_331.column_532,
            dataset_268.column_7116
    ), 
    
    dataset_4880         AS (  
        SELECT /*+ ########### */
            SUM(dataset_67.column_721)                                         AS column_735,
            dataset_4881.column_535                                                AS column_535,
            dataset_259.column_555                                               AS column_555,
            dataset_67.column_152                                               AS column_532,
            package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => NULL,
                argument_650             => '#######-###-##',
                argument_161             => NULL,
                argument_679              => NULL,
                argument_73              => dataset_312.column_76,
                argument_252             => dataset_899.column_753,
                argument_672             => dataset_4881.column_534)     AS column_7116 
        FROM dataset_667           dataset_665,
             dataset_68                    dataset_67,
             dataset_311        dataset_312,
             dataset_227  dataset_4881,
             dataset_260      dataset_259,
             dataset_360  dataset_899
        WHERE 1 = 1
            AND dataset_67.column_719 = '##_###_########'
            AND dataset_665.column_148 = dataset_67.column_148          
            AND dataset_665.column_718 = dataset_67.column_718        
            AND dataset_665.column_1490 = '#'
            AND dataset_312.column_148 = dataset_67.column_148          
            AND dataset_259.column_76 = dataset_312.column_76     
            AND dataset_4881.column_532 = dataset_67.column_152   
            AND dataset_4881.column_533 = '#######_###'
            AND dataset_4881.column_76 = dataset_259.column_76     
        GROUP BY 
            dataset_4881.column_535,
            dataset_259.column_555,
            dataset_67.column_152,
            dataset_312.column_76,
            dataset_899.column_753,
            dataset_4881.column_534
    ),
    dataset_4882 AS (    
        SELECT /*+ ########### */ 
            SUM(
                CASE WHEN column_1785           <> column_5434                 
                    THEN column_4358                   
                    ELSE column_4357                
                END
            )                                                         AS column_735,
            column_535                                                 AS column_535,
            column_555                                               AS column_555,
            column_5434                                              AS column_532,
            package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => '####_######',
                argument_650             => '########-############-##',
                argument_161             => NULL,
                argument_679              => '########_#######_#########',
                argument_73              => column_597,
                argument_1105              => column_601,
                argument_252             => column_753,
                argument_672             => column_534)         AS column_7116 
         FROM(
                SELECT
                dataset_318.column_1785,
                dataset_318.column_5434,
                dataset_318.column_4358,
                dataset_318.column_4357, 
                dataset_333.column_535,
                dataset_259.column_555,
                dataset_318.column_597,
                dataset_104.column_753,
                dataset_333.column_534,
                dataset_45.column_601,
                RANK() OVER (PARTITION BY dataset_45.column_598 ORDER BY dataset_333.column_598 NULLS LAST) as column_5369
            FROM
                dataset_317                  dataset_318,
                dataset_260      dataset_259,
                dataset_227  dataset_333,
                dataset_270 dataset_319,
                dataset_269 dataset_45,
                dataset_360  dataset_104
            WHERE 1=1
                AND dataset_259.column_76 = dataset_318.column_597                    
                AND dataset_318.column_04 = '###########_############'
                AND dataset_318.column_10 IN ('####_########', '####_##_##_########')
                AND dataset_318.column_4357 > 0
                AND dataset_318.column_599 = dataset_319.column_599   
                AND dataset_319.column_598 = dataset_45.column_598
                AND dataset_45.column_601 NOT IN ('##_####', '##_####')
                AND dataset_333.column_533 = '########_#######_#########'
                AND dataset_333.column_76 = dataset_318.column_597                    
                AND dataset_333.column_532 = dataset_318.column_5434                 
                AND NVL(dataset_333.column_598, dataset_45.column_598) = dataset_45.column_598
                AND CASE WHEN dataset_104.column_753 ='#############_##' AND dataset_318.column_597 = '###_##_##' THEN
                             DECODE(dataset_45.column_11330 ,'#########_#######','###','#########_#####','###','###')
                         WHEN dataset_318.column_597 = '###_##' THEN
                             DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                         ELSE dataset_333.column_534        
                    END = dataset_333.column_534
            )
            WHERE column_5369 = 1
        GROUP BY
            column_535,
            column_555,
            column_5434,
            column_597,
            column_753,
            column_534,
            column_601
    ),
    dataset_4883       AS(
        SELECT DISTINCT column_76, column_7116  
          FROM dataset_4869 
         WHERE column_76      IN ('###_##', '###_##', '###_##')
    ),
    dataset_4884             AS(
        SELECT 
            SUM(dataset_3310.column_735)                                     AS column_735,
            dataset_333.column_535                                         AS column_535,
            dataset_3310.column_555                                        AS column_555,
            dataset_3310.column_532                                      AS column_532,
            dataset_4885.column_7116                                     AS column_7116 
          FROM
             dataset_260      dataset_259
            ,dataset_4870       dataset_3310
            ,dataset_50   dataset_86
            ,dataset_270 dataset_268
            ,dataset_269 dataset_45
            ,dataset_227  dataset_333
            ,dataset_4883       dataset_4885
           WHERE 1=1
             AND dataset_45.column_601 IN ('##_####', '##_####')
            AND nvl(dataset_3310.column_735,0) <> 0
            AND dataset_259.column_555 = dataset_3310.column_555       
            AND dataset_333.column_533   IN ('########_##########','########_#######_#########')
            AND dataset_333.column_76 = dataset_259.column_76     
            AND dataset_333.column_532 = dataset_3310.column_532   
            AND DECODE(dataset_333.column_533,'########_##########','##########','########_#######_#########','#########') = dataset_3310.column_533  
            AND dataset_86.column_07 = dataset_3310.column_573
            AND dataset_268.column_599 = dataset_3310.column_599   
            AND dataset_45.column_598 = dataset_268.column_598
            AND dataset_4885.column_76 = dataset_259.column_76     
            GROUP BY
                dataset_333.column_535,
                dataset_3310.column_555,
                dataset_3310.column_532,
                dataset_4885.column_7116
        )
    ,
    dataset_4886 AS (    
        SELECT /*+ ########### */ 
            SUM(column_09)                                                 AS column_735,
            column_535                                                         AS column_535,
            column_555                                                       AS column_555,
            column_532                                                       AS column_532,
            package_381.package_function_413 (
                argument_01              => '#####',
                 argument_552                 => '####_######',
                argument_650             => '########-############-##',
                argument_161             => NULL,
                argument_679              => '########_#######_#########',
                argument_73              => column_597,
                argument_1105              => column_601,
                argument_252             => column_753,
                argument_672             => column_534)                AS column_7116         
            FROM(
                SELECT
                    dataset_1185.column_09,
                    dataset_333.column_535,
                    dataset_259.column_555,
                    dataset_1185.column_532,
                    dataset_1185.column_597,
                    dataset_104.column_753,
                    dataset_333.column_534,
                    dataset_45.column_601,
                    RANK() OVER (PARTITION BY dataset_45.column_598 ORDER BY dataset_333.column_598 NULLS LAST) as column_5369
                FROM
                    dataset_13                   dataset_1185,
                    dataset_272 dataset_2397,
                    dataset_270 dataset_268,
                    dataset_269 dataset_45,
                    dataset_260      dataset_259,
                    dataset_227  dataset_333,
                    dataset_360  dataset_104
                WHERE 1=1
                    AND dataset_259.column_76 = dataset_1185.column_597                    
                    AND (dataset_1185.column_4359               IS NULL OR dataset_1185.column_4359 = '####_##_##_########')   
                    AND dataset_1185.column_09 > 0
                    AND dataset_1185.column_08 = dataset_2397.column_08  
                    AND dataset_2397.column_599 = dataset_268.column_599   
                    AND dataset_268.column_598 = dataset_45.column_598
                    AND dataset_333.column_533 = '########_#######_#########'
                    AND dataset_333.column_76 = dataset_1185.column_597                    
                    AND dataset_333.column_532 = dataset_1185.column_532   
                    AND NVL(dataset_333.column_598, dataset_45.column_598) = dataset_45.column_598
                    AND CASE WHEN dataset_104.column_753 ='#############_##' AND dataset_1185.column_597 = '###_##_##' THEN
                                 DECODE(dataset_45.column_11330 ,'#########_#######','###','#########_#####','###','###')
                             WHEN dataset_1185.column_597 = '###_##' THEN
                                   DECODE(dataset_45.column_11330,'#########_#######','###','#########_#####','###','###')
                                ELSE dataset_333.column_534        
                        END = dataset_333.column_534
              )
              WHERE column_5369 = 1
        GROUP BY 
            column_535,
            column_555,
            column_532,
            column_597,
            column_753,
            column_534,
            column_601
    ), 
    dataset_4887       AS (
        SELECT  /*+ ########### */ 
            column_535,
            column_555,
            column_532,
            column_7116,        
            SUM(column_735)         AS column_735
        FROM (
            SELECT * FROM dataset_4875             
            UNION ALL
            SELECT * FROM dataset_4879            
            UNION ALL
            SELECT * FROM dataset_4882
            UNION ALL
            SELECT * FROM dataset_4886                
            UNION ALL
            SELECT * FROM dataset_4880        
            UNION ALL
            SELECT * FROM dataset_4884            
        )    
        GROUP BY 
            column_535,
            column_555,
            column_532,
            column_7116        
    ),
 
    dataset_4888 AS (
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116,
            dataset_235.column_735             AS column_12271,
            0                    AS column_12272,
            0                    AS column_12273,
            0                    AS column_12274,
            0                    AS column_12275    
        FROM dataset_4871  dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            dataset_235.column_735             AS column_12272,
            0                    AS column_12273,
            0                    AS column_12274,
            0                    AS column_12275    
        FROM dataset_4887       dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_12272,
            dataset_235.column_735          AS column_12273,
            0                      AS column_12274,
            0                    AS column_12275    
        FROM dataset_4874         dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_12272,
            0                    AS column_12273,
            dataset_235.column_735          AS column_12274,
            0                    AS column_12275    
        FROM dataset_4873       dataset_235, dataset_360  dataset_899
        UNION ALL
        SELECT dataset_235.column_535,
            dataset_899.column_354,
            dataset_899.column_122,
            dataset_235.column_555,
            dataset_235.column_532,
            dataset_235.column_7116,
            0                    AS column_12271,
            0                    AS column_12272,
            0                    AS column_12273,
            0                    AS column_12274,
            dataset_235.column_735           AS column_12275    
        FROM dataset_242  dataset_235, dataset_360  dataset_899

    )
   
    SELECT    '######'
        || dataset_1317.column_122      
        || '#'
        || 
        || dataset_4889.column_2348       
        || dataset_1317.column_535        
        || dataset_1317.column_532   
        || dataset_1317.column_7116 
            AS column_1117,
        '####'                          AS column_5035,
        dataset_1317.column_535                     AS column_1328,
        dataset_1317.column_122                    AS column_12270,
        dataset_1317.column_354                      AS column_354,
        dataset_4889.column_2348                  AS column_76,
        dataset_1317.column_532                     AS column_874,
        dataset_1317.column_7116                    AS column_7105,
        SUM (dataset_1317.column_12271)                AS column_12271,
        SUM (dataset_1317.column_12272)        AS column_12272,
        SUM (dataset_1317.column_12273)  AS column_12273,
        SUM (dataset_1317.column_12274)      AS column_12274,
        SUM (dataset_1317.column_12275)         AS column_12275    
    FROM dataset_4888 dataset_1317, dataset_952          dataset_4889
    WHERE dataset_4889.column_555 = dataset_1317.column_555       
    GROUP BY 
        '####',
        dataset_1317.column_535,
        dataset_1317.column_122,
        dataset_1317.column_354,
        dataset_4889.column_2348,
        dataset_1317.column_532,
        dataset_1317.column_7116 
    ORDER BY column_874, column_1328)
        