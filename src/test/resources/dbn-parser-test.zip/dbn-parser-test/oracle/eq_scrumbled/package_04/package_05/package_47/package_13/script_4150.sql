
--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_#########.###
--###
--###  ####### ####       ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  #######        ###-##### | ###### ##### ## ###_######_#### ######
--### *********************************************************************/



--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_#########';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_######### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_14
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_22357
      ,column_22358
      ,column_22359
      ,column_22360
      ,column_13355
      ,column_13352
      ,column_22361
      ,column_22362
      ,column_22363
      ,column_22364
      ,column_22365
      ,column_22366
      ,column_22367
      ,column_22368
      ,column_22369
      ,column_22370
      ,column_22371
      ,column_22372
      ,column_22373
      ,column_22374
      ,column_973
      ,column_974
      ,column_976
      ,column_977
      ,column_17748
      ,column_22375  
  FROM dataset_8086@dblink_02.EQ
/

COMMIT
/

COMMENT ON MATERIALIZED VIEW materialized_view_14 IS '######## ##### ### ######## ###_######_####.###_#########'
/

CREATE INDEX index_423       
  ON table_359 (column_22357,column_13355)
  TABLESPACE tablespace_03
/






