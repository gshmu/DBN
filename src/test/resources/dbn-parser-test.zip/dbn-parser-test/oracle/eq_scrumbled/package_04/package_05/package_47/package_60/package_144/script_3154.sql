/* ####### #### ######## #####
####### ##.#
##.#.#  ##.##.####  #######   ########
##.#.#  ##.##.####	#######	##### ######
##.#.#  ##.##.####	#######	##### ######
##.#.#	##.##.####	####### ##### ##### ## ######
##.#.#  ##.##.####	####### ####### ##### ### ###-#####
##.#.#	##.##.####	#######	####### ##### ### ###-#####
*/
SELECT '############/########'       AS column_25267,
  TRUNC (dataset_2397.column_2748)           AS column_3566 ,
  '############/########'            AS column_4996 ,
  dataset_318.column_4358                    AS column_25268,
  dataset_1185.column_05            AS column_549 ,
  dataset_275.column_742  as column_6479 ,
  dataset_318.column_5434                  AS column_604      
FROM dataset_317                  dataset_318,
  dataset_1171           dataset_3837 ,
  dataset_270 dataset_319 ,
  dataset_269 dataset_320 ,
  dataset_276 dataset_275 ,
  dataset_13                   dataset_1185 ,
  dataset_272 dataset_2397,
  dataset_2483      dataset_2484
WHERE 1                 = 1
AND dataset_320.column_598             = dataset_319.column_598
AND dataset_1185.column_11         = dataset_275.column_11
AND dataset_2397.column_599    = dataset_319.column_599   
AND dataset_1185.column_08     =dataset_2397.column_08  
AND dataset_1185.column_07  =dataset_318.column_07     
AND dataset_1185.column_12 =dataset_318.column_12      
AND dataset_318.column_12 = dataset_3837.column_12      
AND dataset_318.column_599   = dataset_319.column_599   
AND dataset_318.column_10          = '#########'
  -- ######
AND dataset_1185.column_08          = dataset_2397.column_08  
AND dataset_318.column_07       = 
AND dataset_2484.column_3118  = 
AND dataset_320.column_598   = dataset_2484.column_598
AND dataset_320.column_601             = '#######_####'
AND dataset_1185.column_12       NOT IN
  (SELECT dataset_8932.column_12      
  FROM dataset_269 dataset_8933 ,
    dataset_270 dataset_8934 ,
    dataset_317                  dataset_8932 ,
    dataset_311        dataset_8935
  WHERE 1                             = 1
  AND dataset_8933.column_598                       = dataset_8934.column_598
  AND dataset_8933.column_601                  = '#######_####'
  AND dataset_8934.column_599             = dataset_8932.column_599   
  AND dataset_8932.column_3846     = dataset_8935.column_148          
  AND dataset_8932.column_07            = dataset_1185.column_07
  )
UNION
SELECT DISTINCT '###########' AS column_25267
  -- ###### ######
  ,
  TRUNC (dataset_665.column_900) AS column_3566 ,
  '###########'             AS column_4996 ,
  dataset_665.column_2266            AS column_25268 ,
  dataset_665.column_2265            AS column_549 ,
  dataset_275.column_742  as column_6479,
  dataset_312.column_532    AS column_604      
FROM dataset_276 dataset_275 ,
  dataset_311        dataset_312 ,
   dataset_667           dataset_665,
  dataset_668                 dataset_666,
  dataset_269 dataset_320,
  dataset_315    dataset_86,
  dataset_2483      dataset_2484
WHERE 1 = 1
  -- #####
AND dataset_312.column_148       = dataset_665.column_148          
AND dataset_665.column_1446         = dataset_275.column_11
AND dataset_312.column_07             = 
AND dataset_666.column_148=dataset_665.column_148          
AND dataset_666.column_451=dataset_86.column_451      
ANd dataset_86.column_598=dataset_320.column_598
AND dataset_2484.column_3118  = 
AND dataset_320.column_598   = dataset_2484.column_598
and dataset_320.column_601= '#######_####'
UNION
SELECT '########### ###' AS column_25267
       -- ###### ######
       ,TRUNC (dataset_2397.column_2748) AS column_3566
       ,'########### ###' AS column_4996
       ,dataset_665.column_2266           AS column_25268
       ,dataset_1185.column_05        AS column_549
       ,dataset_8936.column_742  as column_6479
       ,dataset_8936.column_604       AS column_604      
     FROM dataset_13                   dataset_1185
       ,dataset_272 dataset_2397
       ,dataset_276 dataset_8936
       ,dataset_276 dataset_8937
       ,dataset_270 dataset_319
       ,dataset_269 dataset_320
       ,dataset_317                  dataset_318
       ,dataset_311        dataset_312
       ,dataset_667           dataset_665,
        dataset_2483      dataset_2484
  WHERE 1 = 1
    -- #####
    AND dataset_320.column_598 = dataset_319.column_598
    AND dataset_1185.column_08 = dataset_2397.column_08  
    AND dataset_1185.column_11 = dataset_8936.column_11
    AND dataset_2397.column_599 = dataset_319.column_599   
    AND dataset_1185.column_07 = dataset_318.column_07     
    AND dataset_1185.column_12 = dataset_318.column_12      
    AND dataset_1185.column_04 = dataset_318.column_04                 
    AND dataset_312.column_148 = dataset_665.column_148          
    AND dataset_665.column_1446 = dataset_8937.column_11
    AND dataset_312.column_148 = dataset_318.column_3846          
    -- ######
    AND dataset_1185.column_07 = 
     AND dataset_2484.column_3118  = 
    AND dataset_320.column_598   = dataset_2484.column_598
    AND dataset_320.column_601             = '#######_####'
AND nvl(,'#')=nvl(,'#')
 ORDER BY column_3566 desc