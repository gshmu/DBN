/******************************************************************************
    ##### #####: #######_####_#######
    #########:   #######_####
    ########:    ####### (###_#######)
    ######### #### ####### ##### ### ####### #### ##### (####### ##### - ##### #########)

    #######:
          (####)                           (####)

        - #######_##                       ### ####### ##
        - ######_##                        ######### ###### ###### ########## - ####### ####-####
        - ######_####                      ###### ####
        - ######_####_####                 ###### #### ####
        - ######_#######_######            ###### ####### ######
        - ###########_####                 ########### ####
        - ########_####                    ######## ####
        - #########                        #########
        - ########_#########               ######## #########
        - ###########_####_####            ########### #### ####
        - ###########_#######_######       ########### ####### ######
        - ###########_####                 ########### ####
        - #####_##                         ##### (#/#)
        - ###_######                       ### ######
        - #####_####                       ##### ####
        - #######_####                     ####### ####
        - ####_#########                   #### #########
        - ######_####                      ###### ####
        - ########_####                    ######## ####
        - #######_#######_####             ####### ####### ####
        - #######_#####                    ####### #####
        - #######_######                   ####### ######
        - ###########_####                 ########### ####
        - ######_#######                   ###### #######
        - ###########_#######              ########### #######
        - ########                         ########
        - ######_#####_######              ###### ##### ######
        - ###########_#####_######         ########### ##### ######
        - ######_##########_######         ###### ########## ######
        - ###########_##########_######    ########### ########## ######


    ###### ## ###########:  ##(####### ####)||###(#######)||<####### ##### ##>||<#########>||<####.########_####_###########_##>

    ####### ##.#
    ##.#.#.#    ##.##.####   ### #####    ####### ####
	##.#.#.#    ##.##.####   ##### #####  ###### ## ########## ## ########_####, ######_#####_###### ### ###########_#####_######
	####### ##
	##.#.#      ##.##.####   ######       ######## #### ######## ### #### ###########
    ##.#.#      ##.##.####   ### #####    ###-##### #### ########## ###
    ####### ##.#
    ##.#.#    ##.##.####   ### #####    ###-##### ######## ######## ###### ######
    ####### ##
    ##.#.#    ##.##.####   ##### ######   ###-##### : ######### #######
    ##.#.#    ##.##.####   ### #####      ###-##### / ###-##### ########## #####
    ##.#.#    ##.##.####   ### #####      ###-##### ####### #### ### ######## ########
    ####### ##.#
    ##.#.#    ##.##.####   ### #####      ###-##### ##### #### ##### ### ######-#########-####-##
    ####### ##.#
    ##.#.#    ##.##.####   ### #####      ###-##### ####### #### ### ####
    ##.#.#    ##.##.####   ### #####      ###-##### ######## #####
*******************************************************************************/

SELECT
    column_354,
    column_1117,
    column_2468,
    column_19251,
    column_19252,
    column_1056,
    column_3114,
    column_7075,
    column_7076,
    column_19253,
    column_19254,
    NULL AS column_7079,
    column_19255,
    NULL AS column_19256,
    NULL AS column_5704,
    column_2329,
    column_7082,
    column_7083,
    column_532,
    NULL AS column_19257,
    column_1477,
    column_989,
    column_1064,
    column_19258,
    column_19259,
    NULL AS column_7103,
    column_19260,
    column_19261,
    column_19262,
    column_19263                 
FROM (
    WITH dataset_949                            as (
            select /*+ ########### */ column_76     
                FROM dataset_951                      dataset_950
                    ,dataset_15 dataset_104
                WHERE column_2345 = 
                       and dataset_104.column_354=
                      and DECODE(dataset_950.column_753, '*', dataset_104.column_753, dataset_950.column_753) = dataset_104.column_753),    
    dataset_260      AS (
        SELECT  /*+ ########### */ column_2346 AS column_76,
               column_2347      AS column_2348       
          FROM dataset_954            
          WHERE column_2349 = '###_#######'
            AND column_354 = '###_#########'
            AND column_2350 = '######+'
            AND column_2351 = '###_########_######'
            AND column_221 = '#######_######'
            AND column_2352 = '*'),
    dataset_6755    AS (
        SELECT DISTINCT
               dataset_230.column_527                  as column_527,
               dataset_230.column_528                  as column_528,
               dataset_230.column_532                  as column_532,
               dataset_230.column_724                  as column_724,
               dataset_230.column_533                  as column_533  
          FROM dataset_231          dataset_230
         WHERE column_533 = '######'),
    dataset_957   as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_####:####_####:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_####:####_####:#######',
                                            argument_42             => '#######_######'))as column_2344 
                        FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354=), 
            
     dataset_958    as (SELECT /*+ ########### */ dataset_945.column_530  as column_591,dataset_899.column_354 as column_354,
                                nvl(package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_####:###_######:'||dataset_945.column_530 ,
                                            argument_42             => '#######_######'),
                                    package_11.package_function_04(
                                            argument_01             => '#####',
                                            argument_40             => '##############',
                                            argument_18             => dataset_899.column_354,
                                            argument_41             => '#######_####:###_######:#######',
                                            argument_42             => '#######_######'))as column_2344 
                          FROM dataset_946  dataset_945, dataset_15 dataset_899 where dataset_899.column_354=)
    SELECT
        dataset_104.column_354                                                                                AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                          AS column_1117,
        '#'                                                                                         AS column_2468,
        package_131.package_function_134(DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2400), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2401), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2396), dataset_7094.column_2344)             AS column_19251,
        package_131.package_function_134(DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2400), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2401) , DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2396), dataset_7095.column_2344)               AS column_19252,
        TO_CHAR(dataset_1573.column_899, '##/##/####')                                                      AS column_1056,
        CASE WHEN dataset_1573.column_1058 = '####-######-####-##'
             THEN TO_CHAR(max(dataset_1585.column_1056), '##/##/####')
             ELSE TO_CHAR(dataset_1573.column_2434, '##/##/####')
        END                                                                                         AS column_3114,
         CASE
            -- #######-##
            WHEN dataset_1573.column_1058 = '#######-##'
                AND max(column_5216) = '######' THEN
                CASE WHEN MAX(dataset_1585.column_76) IN ('###_##', '###_##', '###_##')
                  THEN '########: #### #### ## ######## #######'
                  ELSE '########: #### ######## ## ########'
                 END
                
            WHEN dataset_1573.column_1058 = '#######-##'
                AND max(column_5216) = '###########' THEN
                CASE WHEN MAX(dataset_1585.column_76) IN ('###_##', '###_##', '###_##')
                  THEN  '#### #######:[' || max(dataset_1585.column_07) || ']'
                  ELSE  '#######:[' || max(dataset_1585.column_07) || ']'
                 END

            WHEN dataset_1573.column_1058 = '#######-##'
                AND max(column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734
            
                   
            WHEN dataset_1573.column_1058 = '#######-##' 
                AND max(column_5216) = '####' 
            THEN  '#### ########### #######'
                
            -- ###-##
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(column_5216) IN ('######', '###_######')
            THEN '########: ########## ## ###'
            
             WHEN dataset_1573.column_1058 = '###-##'
                AND max(column_5216) = '####' THEN
                 '#### ####### #######'

            WHEN dataset_1573.column_1058 = '###-##'
                AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) NOT IN ('######', '###_######'))
            THEN '#######: ## '|| dataset_1573.column_734
            
            
              --#######_#######_##
            WHEN dataset_1573.column_1058 = '#######-#######-##'
                AND max(dataset_1585.column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734
            
            WHEN dataset_1573.column_1058 = '#######-#######-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######: ## '||  max(dataset_1585.column_07)
            
            -- ####-##
            WHEN dataset_1573.column_1058 = '####-##'
            THEN '########: ########## ## ####'
            -- #######-###-##
            WHEN dataset_1573.column_1058='#######-###-##'
            THEN '########## ## ####### ###'
            -- ###-##
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
            THEN '########: ######## ## ####'
            WHEN dataset_1573.column_1058 = '###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
            THEN '########: ########## ## ####'
            
             --##########-###-##
            WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) = '########_#######'
            THEN '########: ######## ## ##########'
            WHEN dataset_1573.column_1058 = '##########-###-##'
                AND max(dataset_1585.column_1064) <> '########_#######'
            THEN '########: ########## ## ##########'
            
            -- ########-##
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '########'
            THEN '########: ########## ## ########'
            WHEN dataset_1573.column_1058 = '########-##'
                AND (max(dataset_1585.column_5216) IS NULL OR max(dataset_1585.column_5216) <> '########')
            THEN '########: ######## ## ##########'

            -- ####-##-##########
            WHEN dataset_1573.column_1058 = '####-##-##########' THEN
              CASE
                 WHEN MAX(dataset_1585.column_76) IN ('###_##', '###_##', '###_##')  
                 THEN '########: #### #### ## ######## #######'
                 ELSE '########: ## ######## #######'
               END

            -- #####-#######-##
            WHEN dataset_1573.column_1058 = '#####-#######-##' THEN 
              CASE WHEN MAX(dataset_1585.column_76) IN ('###_##', '###_##', '###_##')
                THEN '####### #### #######:[' || max(dataset_1585.column_07) || ']'
                ELSE '#######:[' || max(dataset_1585.column_07) || ']'
               END

            -- #####-########-##
            WHEN dataset_1573.column_1058 = '#####-########-##'
            THEN '#######:[' || max(dataset_1585.column_07) || ']'

            -- ########-##
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '######'
            THEN '########: ######## ## ########'

            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######:[' || max(dataset_1585.column_07) || ']'
            
            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '####'
            THEN '#### ######## #######'
            
             --####-########-####-##
            WHEN dataset_1573.column_1058 = '####-########-####-##'
                AND max(dataset_1585.column_5216) = '######'
            THEN '########: ########(#### ########) ## ########'

            WHEN dataset_1573.column_1058 = '####-########-####-##'
                AND max(dataset_1585.column_5216) = '###########'
            THEN '#######: '||max(dataset_1585.column_07)
            
            --#####-####-########-####-##
             WHEN dataset_1573.column_1058 = '#####-####-########-####-##'
            THEN '#######: '||max(dataset_1585.column_07)

            WHEN dataset_1573.column_1058 = '########-##'
                AND max(dataset_1585.column_5216) = '#######'
            THEN '#######: ## '|| dataset_1573.column_734

            -- ####-######-####-##
            WHEN dataset_1573.column_1058 = '####-######-####-##'
            THEN '#### ##: ###### ######'
            
            -- ########-############-##
            WHEN dataset_1573.column_1058 = '########-############-##'
            THEN '######## : ## #########'
            
            --######-##
            WHEN dataset_1573.column_1058 = '######-##'
                    AND MAX(dataset_1585.column_76) IN ('###_##', '###_##', '###_##') 
            THEN '#### ########: ###### #### #######'

            --#####-##
            WHEN dataset_1573.column_1058 = '#####-##'
            THEN '######## : #### ##### #### ## #########'
            
            WHEN dataset_1573.column_1058 = '##-###-##'
            THEN '########: ########## ## ## ###'
            
            WHEN dataset_1573.column_1058  in('###-###-###########-##','###-###########-###########-##')
            THEN '########: ######## ## ######## ###'
            
             --##-######-##
            WHEN dataset_1573.column_1058 = '##-######-##'
            THEN '#### ######## : ## #### ## ## #### #######'
                    
            ELSE dataset_1053.column_742 
        END                                                                                         AS column_7075,
        TO_CHAR(dataset_1573.column_2427)                                                  AS column_7076,
        package_131.package_function_134(DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1318), DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1319), DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1320), dataset_7096.column_2344)   AS column_19253,
        package_131.package_function_134(DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1318),DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1319),DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1320), dataset_7097.column_2344)       AS column_19254,
        '#'                                                                                         AS column_19255,
        dataset_104.column_122                                                                                AS column_2329,
        TO_CHAR(dataset_1573.column_2427)                                                  AS column_7082,
        '#####'                                                                                     AS column_7083,
        dataset_1573.column_532                                                                             AS column_532,
        dataset_1573.column_735                                                                                 AS column_1477,
        dataset_1573.column_989                                                                             AS column_989,
        dataset_1573.column_1058                                                                            AS column_1064,
        CASE WHEN dataset_1573.column_530  <> '#####_#####'
             THEN package_381.package_function_413(
                                argument_01             => '#####',
                                argument_552                => '####_######',
                                argument_650            => dataset_1573.column_1058,
                                argument_161            => max(dataset_1585.column_1064),
                                argument_680            => max(dataset_1585.column_5216),
                                argument_679            => dataset_6758.column_533,
                                argument_73             => dataset_6759.column_76)
             ELSE NULL
        END                                                                                          AS column_19258,
        CASE WHEN dataset_1573.column_2440            <> '#####_#####'
             THEN package_381.package_function_413(
                                argument_01             => '#####',
                                argument_552                => '####_####',
                                argument_650            => dataset_1573.column_1058,
                                argument_161            => max(dataset_1585.column_1064),
                                argument_680            => max(dataset_1585.column_5216),
                                argument_679            => dataset_6758.column_533,
                                argument_73             => NVL(dataset_2733.column_76, dataset_6759.column_76))

             ELSE NULL
        END                                                                                          AS column_19259,
        DECODE(dataset_1573.column_530, '#####_#####', NULL, dataset_6759.column_2348)                        AS column_19260,
        DECODE(dataset_1573.column_2440, '#####_#####', NULL,
                        NVL(dataset_2733.column_2348, dataset_6759.column_2348))                         AS column_19261,
        DECODE(dataset_1573.column_530, '#####_#####', NULL, dataset_1573.column_2442 )          AS column_19262,
        DECODE(dataset_1573.column_2440, '#####_#####', NULL, dataset_1573.column_2443)  AS column_19263                 
    FROM dataset_1057                dataset_1573,
         dataset_1060          dataset_1585,
         dataset_1054        dataset_1053,
         dataset_6755    dataset_6758,
         dataset_15 dataset_104,
         dataset_260      dataset_6759,
         dataset_260      dataset_2733,
         dataset_957   dataset_7094,
         dataset_957   dataset_7096,
         dataset_958    dataset_7095,
         dataset_958    dataset_7097,
         dataset_949                            dataset_964
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_1573.column_530 = dataset_7095.column_591
        AND dataset_1573.column_2440 = dataset_7097.column_591
        AND dataset_1573.column_530 = dataset_7094.column_591
        AND dataset_1573.column_2440 = dataset_7096.column_591
        AND dataset_104.column_354 = dataset_7095.column_354
        AND dataset_104.column_354 = dataset_7097.column_354
        AND dataset_104.column_354 = dataset_7094.column_354
        AND dataset_104.column_354 = dataset_7096.column_354
        AND dataset_104.column_354 = dataset_1573.column_354
        AND dataset_1053.column_1065 = dataset_1573.column_1058 
        AND dataset_1573.column_2427 = dataset_1585.column_2427                 
        AND dataset_1573.column_1058  NOT IN ('######_######_#####','######_####_#####', '######-#########-####-##')
        AND dataset_1573.column_2400 = dataset_6758.column_527(+)
        AND dataset_1573.column_2401     = dataset_6758.column_528(+)
        AND dataset_1573.column_532                = dataset_6758.column_532(+)
        AND dataset_1573.column_724       = dataset_6758.column_724(+)
        AND dataset_1573.column_76 = dataset_6759.column_76     
        AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
        AND dataset_6759.column_76 =dataset_964.column_76     
        AND (dataset_1573.column_2434    IS NOT NULL
             OR (dataset_1573.column_1058 = '####-######-####-##' AND
                 dataset_1573.column_1071 = '######'))

        -- ###### ###### / ####### ######
        AND dataset_1573.column_354 = 
        AND nvl(dataset_1573.column_2434,dataset_1573.column_204) >   
        AND nvl(dataset_1573.column_2434,dataset_1573.column_204) <=  
    GROUP BY
        dataset_1573.column_2427,
        dataset_104.column_122,
        dataset_104.column_354,
        dataset_1573.column_530,
        dataset_1573.column_734,
        dataset_1573.column_2440,
        dataset_1573.column_2400,
        dataset_1573.column_2401,
        dataset_1573.column_2396,
        dataset_1573.column_1318,
        dataset_1573.column_1319,
        dataset_1573.column_1320,
        dataset_1573.column_1058,
        dataset_1573.column_532,
        dataset_1573.column_735,
        dataset_1573.column_989,
        dataset_6759.column_2348,
        dataset_1573.column_2442,
        dataset_1573.column_2443,
        dataset_1573.column_2434,
        dataset_1573.column_1050,
        dataset_1573.column_899,
        dataset_1053.column_742,
        dataset_6758.column_533,
        dataset_2733.column_76,
        dataset_2733.column_2348,
        dataset_6759.column_76,
        dataset_6759.column_2348,
        dataset_7095.column_2344,
        dataset_7097.column_2344,
        dataset_7094.column_2344,
        dataset_7096.column_2344 


    UNION ALL
    SELECT
        dataset_104.column_354                                                                                 AS column_354,
        '#####'||dataset_104.column_122      ||'#'||dataset_1573.column_2427                                           AS column_1117,
        '#'                                                                                          AS column_2468,
        package_131.package_function_134(DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2400), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2401), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2396), dataset_7094.column_2344)             AS column_19251,
        package_131.package_function_134(DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2400), DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2401) , DECODE(dataset_1573.column_530,'#####_#####', NULL, dataset_1573.column_2396), dataset_7095.column_2344)               AS column_19252,
        TO_CHAR(dataset_1573.column_899, '##/##/####')                                                       AS column_1056,
        TO_CHAR(max(dataset_1585.column_1056), '##/##/####')                                             AS column_3114,
        CASE
            WHEN dataset_2733.column_76 = '###_##_###'
            THEN '##########:####### ####### #######'
            ELSE '##########:#### #######'
        END                                                                                               AS column_7075,
        dataset_1573.column_1050                                                                             AS column_7076,
        package_131.package_function_134(DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1318), DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1319), DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1320), dataset_7096.column_2344)   AS column_19253,
        package_131.package_function_134(DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1318),DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1319),DECODE(dataset_1573.column_2440,'#####_#####', NULL, dataset_1573.column_1320), dataset_7097.column_2344)       AS column_19254,
        '#'                                                                                          AS column_19255,
        dataset_104.column_122                                                                                 AS column_2329,
        dataset_1573.column_1050                                                                             AS column_7082,
        '#####'                                                                                      AS column_7083,
        dataset_1573.column_532                                                                              AS column_532,
        dataset_1573.column_735                                                                                  AS column_1477,
        '#######'                                                                                    AS column_989,
        dataset_1573.column_1058                                                                             AS column_1064,
        CASE WHEN dataset_1573.column_530  <> '#####_#####'
             THEN package_381.package_function_413(
                            argument_01             => '#####',
                            argument_552                => '####_######',
                            argument_650            => dataset_1573.column_1058,
                            argument_161            => max(dataset_1585.column_1064),
                            argument_680            => max(dataset_1585.column_5216),
                            argument_73             => dataset_6759.column_76)
             ELSE NULL
        END                                                                                          AS column_19258,
        CASE WHEN dataset_1573.column_2440            <> '#####_#####'
             THEN package_381.package_function_413(
                            argument_01             => '#####',
                            argument_552                => '####_####',
                            argument_650            => dataset_1573.column_1058,
                            argument_161            => max(dataset_1585.column_1064),
                            argument_680            => max(dataset_1585.column_5216),
                            argument_73             => NVL(dataset_2733.column_76, dataset_6759.column_76))

             ELSE NULL
        END                                                                                          AS column_19259,
        DECODE (dataset_1573.column_530, '#####_#####', NULL,  dataset_6759.column_2348)                      AS column_19260,
        DECODE (dataset_1573.column_2440, '#####_#####', NULL,
                        NVL(dataset_2733.column_2348, dataset_6759.column_2348))                         AS column_19261,
        DECODE(dataset_1573.column_530, '#####_#####', NULL, dataset_1573.column_2442 )          AS column_19262,
        DECODE(dataset_1573.column_2440, '#####_#####', NULL, dataset_1573.column_2443)  AS column_19263                 
    FROM dataset_1057                dataset_1573,
         dataset_1060          dataset_1585,
         dataset_1054        dataset_1053,
         dataset_1579              dataset_1578,
         dataset_15 dataset_104,
         dataset_260      dataset_6759,
         dataset_260      dataset_2733,
         dataset_957   dataset_7094,
         dataset_957   dataset_7096,
         dataset_958    dataset_7095,
         dataset_958    dataset_7097,
         dataset_949                            dataset_964
    WHERE 1 = 1
        -- ##### ##### / ##########
        AND dataset_1573.column_530 = dataset_7095.column_591
        AND dataset_1573.column_2440 = dataset_7097.column_591
        AND dataset_1573.column_530 = dataset_7094.column_591
        AND dataset_1573.column_2440 = dataset_7096.column_591
        AND dataset_104.column_354 = dataset_7095.column_354
        AND dataset_104.column_354 = dataset_7097.column_354
        AND dataset_104.column_354 = dataset_7094.column_354
        AND dataset_104.column_354 = dataset_7096.column_354
        AND dataset_104.column_354 = dataset_1573.column_354
        AND dataset_1053.column_1065 = dataset_1573.column_1058 
        AND dataset_1573.column_2427 = dataset_1585.column_2427                 
        AND dataset_1573.column_1058 = '######-#########-####-##'
        AND dataset_1573.column_76 = dataset_6759.column_76     
        AND dataset_1573.column_2444 = dataset_2733.column_76 (+)
        AND dataset_6759.column_76 = dataset_964.column_76     
        AND dataset_1578.column_148 = dataset_1585.column_148          
        AND dataset_1578.column_567 = dataset_1585.column_899
        AND dataset_1578.column_1058 = '##########'
        AND dataset_1578.column_684               IN ('####', '####', '####')
        AND dataset_1578.column_10 = '####'


        -- ###### ###### / ####### ######
        AND dataset_1573.column_354 = 
        AND nvl(dataset_1573.column_2434,dataset_1573.column_204) >   
        AND nvl(dataset_1573.column_2434,dataset_1573.column_204) <=  
    GROUP BY
        dataset_1573.column_2427,
        dataset_104.column_122,
        dataset_104.column_354,
        dataset_1573.column_530,
        dataset_1573.column_2440,
        dataset_1573.column_2400,
        dataset_1573.column_2401,
        dataset_1573.column_2396,
        dataset_1573.column_1318,
        dataset_1573.column_1319,
        dataset_1573.column_1320,
        dataset_1573.column_1058,
        dataset_1573.column_532,
        dataset_1573.column_735,
        dataset_1573.column_989,
        dataset_6759.column_2348,
        dataset_1573.column_2442,
        dataset_1573.column_2443,
        dataset_1573.column_2434,
        dataset_1573.column_1050,
        dataset_1573.column_899,
        dataset_1053.column_742,
        dataset_2733.column_76,
        dataset_2733.column_2348,
        dataset_6759.column_76,
        dataset_6759.column_2348,
        dataset_7095.column_2344,
        dataset_7097.column_2344,
        dataset_7094.column_2344,
        dataset_7096.column_2344
)