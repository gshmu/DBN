--### /********************************************************************
--###
--###
--###  ######### (#) #### ###, ### ##
--###
--###  #### ####     : #####_###_#######.###
--###
--###  ####### ####        ###             ########
--### *********************************************************************
--###  ####### ##
--###  ##.#.#  ##.##.####  ########        ########
--###  ##.#.#  ##.##.####  ########        ###-##### - ##### #####
--### *********************************************************************/






--###    -- ##### ### ### ########## ### # ########## ### ####### #### #### ####

begin
execute immediate '#### ############ #### ###_#######';
exception
when others then null;
end;
/

begin
execute immediate '#### ##### ###_####### #####';
exception
when others then null;
end;
/

CREATE MATERIALIZED VIEW materialized_view_09
TABLESPACE tablespace_03    
BUILD DEFERRED
USING INDEX TABLESPACE tablespace_03    
REFRESH FORCE ON DEMAND
WITH PRIMARY KEY
AS 
SELECT column_960
      ,column_13351
      ,column_13352
      ,column_13353
      ,column_13354
      ,column_13355
      ,column_13356
      ,column_1328
      ,column_13357
      ,column_13358
      ,column_13359
      ,column_13360
      ,column_13361
      ,column_962
      ,column_963
      ,column_6893
      ,column_4142
      ,column_964
      ,column_973
      ,column_974
      ,column_976
      ,column_977  
  FROM dataset_5077@dblink_02.EQ
/

COMMIT
/

COMMENT ON MATERIALIZED VIEW materialized_view_09 IS '######## ##### ### ######## ###_######_####.###_#######'
/

CREATE INDEX index_71      
  ON table_282 (column_13354,column_13355)
  TABLESPACE tablespace_03
/
       





