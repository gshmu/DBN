WITH
    dataset_258
    AS
        (SELECT /*+ ########### */
                dataset_1573.column_2427,
                dataset_1573.column_11084,
                dataset_1585.column_148               AS column_148,
                dataset_1585.column_718,
                dataset_1585.column_07,
                dataset_1585.column_2559,
                dataset_1585.column_1064,
                dataset_1585.column_1065,
                dataset_1585.column_532,
                dataset_1585.column_735,
                dataset_1585.column_1056,
                dataset_1585.column_899,
                dataset_1585.column_1318,
                dataset_1585.column_1319,
                dataset_1585.column_1320,
                dataset_1585.column_1092,
                dataset_1585.column_1084,
                dataset_1585.column_2406,
                dataset_1585.column_1050,
                dataset_1573.column_10,
                dataset_1573.column_2434,
                dataset_1585.column_2556,
                dataset_1585.column_2471                 
           FROM dataset_5488                   dataset_1585,
                dataset_5489                   dataset_1573,
                dataset_15                      dataset_3346
          WHERE     dataset_1585.column_2427 =
                    dataset_1573.column_2427                 
                AND dataset_1585.column_1065 = dataset_1573.column_1058 
                AND dataset_1585.column_1061 = '###'
                AND column_1065   IN ('#######',
                                      '####-########',
                                      '####-###',
                                      '###_###_#######',
                                      '#####_########',
                                      '#####_#######',
                                      '#######-#####',
                                      '###-#####',
                                      '####_####',
                                      '####-######',
                                      '###_###_####_#######',
                                      '#####-###-#####',
                                      '#####-######',
                                      '#####-###',
                                      '#######-##',
                                      '########-##',
                                      '###-##',
                                      '######-##',
                                      '#####-########-##',
                                      '#####-#######-##',
                                      '#####-######-##',
                                      '#####-###-##')
                AND dataset_1585.column_899 BETWEEN NVL (
                                               ,
                                               TO_DATE ('##/##/####',
                                                        '##/##/####'))
                                       AND NVL ( , (SYSDATE + 10))
                AND dataset_1585.column_354 = dataset_3346.column_354),
    dataset_7690
    AS
        (SELECT /*+ ########### */
                dataset_7691.column_07,
                dataset_7692.column_3876       AS column_19393,
                dataset_7692.column_11670     AS column_21233    
           FROM dataset_1273               dataset_7691
                INNER JOIN dataset_1559            dataset_7692
                    ON (    dataset_7692.column_3873 = dataset_7691.column_3873
                        AND dataset_7692.column_3060 = dataset_7691.column_3060)
          WHERE dataset_7691.column_3873 = '#####_######'),
    dataset_5490
    AS
        (SELECT /*+ ########### */
                *
           FROM (SELECT /*+ ####### (## # ## ## ) #### (##) ####(#) ####(##) ####(##) */
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                         AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        CASE
                            WHEN dataset_46.column_2471 = '#'
                            THEN
                                NULL
                            WHEN dataset_665.column_734 = '########'
                            THEN
                                dataset_45.column_734
                            ELSE
                                dataset_665.column_734
                        END                         AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                        AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434              AS column_14394,
                        dataset_46.column_2556,
                        dataset_312.column_3147              AS column_3147,
                        dataset_312.column_3149              AS column_3149,
                        '###########'               AS column_1425,
                        dataset_312.column_3151,
                        dataset_7693.column_19393                column_19393,
                        dataset_7693.column_21233             column_21233    
                   FROM dataset_258                    dataset_46,
                        dataset_667            dataset_665,
                        dataset_50             dataset_45,
                        dataset_311            dataset_312,
                        dataset_7690           dataset_7693
                  WHERE     dataset_46.column_1065   IN ('#######', '#######-##')
                        AND dataset_46.column_148 = dataset_665.column_148          
                        AND dataset_46.column_718 = dataset_665.column_718        
                        AND dataset_46.column_07 = dataset_45.column_07     
                        AND dataset_665.column_148 = dataset_312.column_148          
                        AND NOT (    dataset_312.column_3147 = '#'
                                 AND dataset_312.column_3149 = '#')
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) ####(##) ####(##) ####(##) */
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                         AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        CASE
                            WHEN dataset_665.column_734 = '########'
                            THEN
                                dataset_737.column_734
                            ELSE
                                dataset_665.column_734
                        END                         AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                        AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434              AS column_14394,
                        dataset_46.column_2556,
                        dataset_312.column_3147              AS column_3147,
                        dataset_312.column_3149              AS column_3149,
                        '###########'               AS column_1425,
                        dataset_312.column_3151,
                        dataset_7693.column_19393                column_19393,
                        dataset_7693.column_21233             column_21233    
                   FROM dataset_258                    dataset_46,
                        dataset_667            dataset_665,
                        dataset_1369           dataset_747,
                        (  SELECT dataset_1156.column_734,
                                  dataset_1156.column_148,
                                  dataset_1156.column_718,
                                  dataset_1156.column_2257            AS column_532,
                                  dataset_1156.column_2480               
                             FROM dataset_1157            dataset_1156
                            WHERE 1 = 1
                         GROUP BY dataset_1156.column_734,
                                  dataset_1156.column_148,
                                  dataset_1156.column_718,
                                  dataset_1156.column_2257,
                                  dataset_1156.column_2480) dataset_737,
                        dataset_50             dataset_45,
                        dataset_311            dataset_312,
                        dataset_7690           dataset_7693
                  WHERE     dataset_46.column_1065   IN ('####-###', '###-##')
                        AND dataset_46.column_148 = dataset_665.column_148          
                        AND dataset_46.column_718 = dataset_665.column_718        
                        AND dataset_747.column_148 = dataset_46.column_148          
                        AND dataset_747.column_718 = dataset_46.column_718        
                        AND dataset_747.column_1065 = dataset_46.column_1065  
                        AND dataset_747.column_2406 =
                            dataset_46.column_2406            
                        AND dataset_747.column_735 = dataset_46.column_735
                        AND dataset_665.column_148 =
                            dataset_737.column_148(+)
                        AND dataset_665.column_718 = dataset_737.column_718(+)
                        AND (   dataset_665.column_734 <> '########'
                             OR (dataset_747.column_2480 =
                                 dataset_737.column_2480))
                        AND dataset_46.column_07 = dataset_45.column_07     
                        AND dataset_665.column_148 = dataset_312.column_148          
                        AND NOT (    dataset_312.column_3147 = '#'
                                 AND dataset_312.column_3149 = '#')
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                   SELECT /*+ #### (##) ####(#) ####(##) ####(##)*/
                          dataset_46.column_2427,
                          dataset_46.column_11084,
                          ' '                     AS column_14393,
                          dataset_46.column_148,
                          dataset_46.column_07,
                          dataset_45.column_165,
                          dataset_45.column_74,
                          dataset_45.column_75,
                          dataset_1248.column_734,
                          dataset_46.column_1064,
                          dataset_46.column_1065,
                          NULL                    AS column_533,
                          dataset_46.column_532,
                          dataset_46.column_735,
                          dataset_46.column_1056,
                          dataset_46.column_899,
                          dataset_46.column_1318,
                          dataset_46.column_1319,
                          dataset_46.column_1320,
                          dataset_46.column_1092,
                          dataset_46.column_1084,
                          dataset_46.column_2406,
                          dataset_46.column_1050,
                          dataset_46.column_10,
                          dataset_46.column_2434          AS column_14394,
                          dataset_46.column_2556,
                          NULL                    AS column_3147,
                          NULL                    AS column_3149,
                          NULL                    AS column_1425,
                          dataset_2821.column_3151,
                          dataset_7693.column_19393            column_19393,
                          dataset_7693.column_21233         column_21233    
                     FROM dataset_258                  dataset_46,
                          dataset_2822          dataset_2821,
                          dataset_1247          dataset_1248,
                          dataset_50           dataset_45,
                          dataset_7690         dataset_7693
                    WHERE     dataset_46.column_1065   IN
                                  ('####-########', '########-##')
                          AND (   dataset_46.column_2556 =
                                  dataset_1248.column_2556            
                               OR dataset_46.column_2556 =
                                  dataset_2821.column_7385)
                          AND dataset_2821.column_2556 =
                              dataset_1248.column_2556            
                          AND dataset_46.column_07 = dataset_45.column_07     
                          AND dataset_7693.column_07(+) = dataset_45.column_07     
                 GROUP BY dataset_46.column_2427,
                          dataset_46.column_11084,
                          dataset_46.column_148,
                          dataset_46.column_07,
                          dataset_45.column_165,
                          dataset_45.column_74,
                          dataset_45.column_75,
                          dataset_1248.column_734,
                          dataset_46.column_1064,
                          dataset_46.column_1065,
                          dataset_46.column_532,
                          dataset_46.column_735,
                          dataset_46.column_1056,
                          dataset_46.column_899,
                          dataset_46.column_1318,
                          dataset_46.column_1319,
                          dataset_46.column_1320,
                          dataset_46.column_1092,
                          dataset_46.column_1084,
                          dataset_46.column_2406,
                          dataset_46.column_1050,
                          dataset_46.column_10,
                          dataset_46.column_2434,
                          dataset_46.column_2556,
                          NULL,
                          NULL,
                          NULL,
                          dataset_2821.column_3151,
                          dataset_7693.column_19393,
                          dataset_7693.column_21233    
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) */
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                     AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        NULL                    AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                    AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434          AS column_14394,
                        dataset_46.column_2556,
                        NULL                    AS column_3147,
                        NULL                    AS column_3149,
                        NULL                    AS column_1425,
                        NULL                    AS column_3151,
                        dataset_7693.column_19393            column_19393,
                        dataset_7693.column_21233         column_21233    
                   FROM dataset_258 dataset_46, dataset_50   dataset_45, dataset_7690 dataset_7693
                  WHERE     dataset_46.column_1065   IN
                                ('###_###_#######',
                                 '#####_########',
                                 '#####-########-##')
                        AND dataset_46.column_07 = dataset_45.column_07(+)
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) ####(###) ####(###) ####(##)*/
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '
                            AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        DECODE (dataset_46.column_1065,
                                '#######-#####', dataset_346.column_734,
                                dataset_737.column_734)
                            column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL
                            AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434   
                            AS column_14394,
                        dataset_46.column_2556,
                        dataset_346.column_3147     
                            AS column_3147,
                        dataset_346.column_3149          
                            AS column_3149,
                        '#####'
                            AS column_1425,
                        dataset_346.column_3151,
                        dataset_7693.column_19393
                            column_19393,
                        dataset_7693.column_21233    
                            column_21233    
                   FROM dataset_258                    dataset_46,
                        dataset_1231           dataset_1230,
                        dataset_345            dataset_346,
                        dataset_1369           dataset_747,
                        (  SELECT dataset_1156.column_734,
                                  dataset_1156.column_148,
                                  dataset_1156.column_718,
                                  dataset_1156.column_2257            AS column_532,
                                  dataset_1156.column_2480               
                             FROM dataset_1157            dataset_1156
                            WHERE 1 = 1
                         GROUP BY dataset_1156.column_734,
                                  dataset_1156.column_148,
                                  dataset_1156.column_718,
                                  dataset_1156.column_2257,
                                  dataset_1156.column_2480) dataset_737,
                        dataset_50             dataset_45,
                        dataset_7690           dataset_7693
                  WHERE     dataset_46.column_1065   IN
                                ('#######-#####', '###-#####')
                        AND dataset_346.column_731 = dataset_46.column_148          
                        AND dataset_346.column_731 = dataset_1230.column_731    
                        AND dataset_46.column_07 = dataset_45.column_07     
                        AND dataset_747.column_148 = dataset_46.column_148          
                        AND dataset_747.column_718 = dataset_46.column_718        
                        AND dataset_747.column_1065 = dataset_46.column_1065  
                        AND dataset_747.column_2406 =
                            dataset_46.column_2406            
                        AND dataset_747.column_735 = dataset_46.column_735
                        AND dataset_747.column_148 =
                            dataset_737.column_148(+)
                        AND dataset_747.column_718 = dataset_737.column_718(+)
                        AND dataset_747.column_2480 =
                            dataset_737.column_2480(+)
                        AND NOT (    dataset_346.column_3147 = '#'
                                 AND dataset_346.column_3149 = '#')
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) ####(###)*/
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                    AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        CASE
                            WHEN NVL (dataset_46.column_2471, '#') =
                                 '#'
                            THEN
                                dataset_2783.column_734
                            ELSE
                                NULL
                        END                    AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                   AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434         AS column_14394,
                        dataset_46.column_2556,
                        NULL                   AS column_3147,
                        NULL                   AS column_3149,
                        NULL                   AS column_1425,
                        NULL                   AS column_3151,
                        dataset_7693.column_19393           column_19393,
                        dataset_7693.column_21233        column_21233    
                   FROM dataset_258                        dataset_46,
                        dataset_2782               dataset_2783,
                        dataset_50                 dataset_45,
                        dataset_7690               dataset_7693
                  WHERE     dataset_46.column_1065 = ('####_####')
                        AND dataset_46.column_2556 =
                            dataset_2783.column_5442         
                        AND dataset_46.column_07 = dataset_45.column_07     
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) */
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                     AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        NULL                    AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                    AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434          AS column_14394,
                        dataset_46.column_2556,
                        NULL                    AS column_3147,
                        NULL                    AS column_3149,
                        NULL                    AS column_1425,
                        NULL                    AS column_3151,
                        dataset_7693.column_19393            column_19393,
                        dataset_7693.column_21233         column_21233    
                   FROM dataset_258 dataset_46, dataset_50   dataset_45, dataset_7690 dataset_7693
                  WHERE     dataset_46.column_1065   IN ('###_###_####_#######',
                                                 '#####-###-#####',
                                                 '#####-######',
                                                 '#####-###',
                                                 '#####-###-##',
                                                 '#####-######-##')
                        AND dataset_46.column_07 = dataset_45.column_07(+)
                        AND dataset_7693.column_07(+) = dataset_45.column_07     
                 UNION ALL
                 SELECT /*+ #### (##) ####(#) ####(##) ####(##)*/
                        dataset_46.column_2427,
                        dataset_46.column_11084,
                        ' '                         AS column_14393,
                        dataset_46.column_148,
                        dataset_46.column_07,
                        dataset_45.column_165,
                        dataset_45.column_74,
                        dataset_45.column_75,
                        NULL                        AS column_734,
                        dataset_46.column_1064,
                        dataset_46.column_1065,
                        NULL                        AS column_533,
                        dataset_46.column_532,
                        dataset_46.column_735,
                        dataset_46.column_1056,
                        dataset_46.column_899,
                        dataset_46.column_1318,
                        dataset_46.column_1319,
                        dataset_46.column_1320,
                        dataset_46.column_1092,
                        dataset_46.column_1084,
                        dataset_46.column_2406,
                        dataset_46.column_1050,
                        dataset_46.column_10,
                        dataset_46.column_2434              AS column_14394,
                        dataset_46.column_2556,
                        dataset_312.column_3147              AS column_3147,
                        dataset_312.column_3149              AS column_3149,
                        '###########'               AS column_1425,
                        dataset_312.column_3151,
                        dataset_7693.column_19393                column_19393,
                        dataset_7693.column_21233             column_21233    
                   FROM dataset_258                    dataset_46,
                        dataset_50             dataset_45,
                        dataset_667            dataset_665,
                        dataset_311            dataset_312,
                        dataset_7690           dataset_7693
                  WHERE     dataset_46.column_1065   IN ('####-######',
                                                 '#####_#######',
                                                 '######-##',
                                                 '#####-#######-##')
                        AND dataset_46.column_07 = dataset_45.column_07(+)
                        AND dataset_46.column_148 = dataset_665.column_148          
                        AND dataset_46.column_718 = dataset_665.column_718        
                        AND dataset_665.column_148 = dataset_312.column_148          
                        AND NOT (    dataset_312.column_3147 = '#'
                                 AND dataset_312.column_3149 = '#')
                        AND dataset_7693.column_07(+) = dataset_45.column_07))
  SELECT /*+ ####(##) ####(##) ####(##) */
         dataset_5490.column_2427,
         dataset_5490.column_11084,
         dataset_5490.column_14393,
         NVL (dataset_5490.column_148,
              dataset_5490.column_2556),
         dataset_5490.column_07,
         dataset_5490.column_165,
         dataset_5490.column_74,
         dataset_5490.column_75,
         dataset_5490.column_734,
         dataset_799.column_14395,
         dataset_5490.column_1064,
         dataset_5490.column_1065,
         NULL
             AS column_533,
         dataset_5490.column_532,
         dataset_5490.column_735,
         dataset_5490.column_1056,
         dataset_5490.column_899,
         dataset_5490.column_1318,
         dataset_5490.column_1319,
         dataset_5490.column_1320,
         dataset_5490.column_1092,
         dataset_5490.column_1084,
         dataset_5490.column_2406,
         dataset_5490.column_1050,
         dataset_5490.column_10,
         dataset_5490.column_14394,
         CASE
             WHEN dataset_5490.column_148           IS NOT NULL
             THEN
                 NVL (
                     (SELECT '#'
                        FROM dataset_345  dataset_403
                       WHERE     dataset_403.column_2986 =
                                 dataset_5490.column_148          
                             AND dataset_403.column_1064      NOT IN
                                     ('##########', '####_##########')
                             AND ROWNUM = 1),
                     '#')
             ELSE
                 '#'
         END
             AS column_12387,
         dataset_5490.column_3147,
         dataset_5490.column_3149,
         dataset_5490.column_1425,
         dataset_5490.column_3151,
         column_19393
             column_19393,
         column_21233    
             column_21233    
    FROM dataset_5490, dataset_478      dataset_799
   WHERE     dataset_5490.column_734 = dataset_799.column_734(+)
         AND (   EXISTS
                     (SELECT 1
                        FROM dataset_1217      dataset_1218
                       WHERE     dataset_1218.column_2349 = '###########'
                             AND dataset_1218.column_221 = '#######_##'
                             AND dataset_1218.column_2881 = 
                             AND dataset_1218.column_179 = dataset_5490.column_734)
              OR EXISTS
                     (SELECT 1
                        FROM dataset_1217      dataset_1218
                       WHERE     dataset_1218.column_2349 = '###########'
                             AND dataset_1218.column_221 = '####'
                             AND dataset_1218.column_2881 = 
                             AND dataset_1218.column_179 =
                                    dataset_5490.column_3151            
                                 || '-'
                                 || dataset_5490.column_2406)
              OR EXISTS
                     (SELECT 1
                        FROM dataset_2253          
                       WHERE column_2880 = ))
         AND (   (  = '###')
              OR (NVL (dataset_5490.column_734,
                       dataset_5490.column_3151)
                      IS NOT NULL))
ORDER BY column_899 DESC,
         column_148,
         column_2427,
         column_1065  